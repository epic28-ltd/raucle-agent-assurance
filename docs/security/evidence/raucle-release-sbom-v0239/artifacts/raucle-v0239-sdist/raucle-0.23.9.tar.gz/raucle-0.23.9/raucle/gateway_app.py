"""Admin panel + gateway API FastAPI application.

This module provides:
  - Gateway API on port 8080: POST /gate (agent tool calls)
  - Admin panel on port 8081: policy management, stats, receipts, config
"""

from __future__ import annotations

import base64 as _base64
import hashlib as _hashlib
import json
import logging
import re as _re
import secrets
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from pydantic import BaseModel, Field

from raucle.admin_session import SESSION_TOKEN_PREFIX, AdminSessionManager, SessionAuthError
from raucle.demo_findings import build_demo_findings
from raucle.gateway import (
    GatewayUser,
    RaucleGateway,
    UserManager,
)

logger = logging.getLogger(__name__)

_BEARER_PREFIX = "Bearer "

# D11: honest labelling for the offline-verification cameo. The verifier is
# the gateway's real offline chain verifier; the receipt material it checks
# is what the demo's simulated traffic produced.
OFFLINE_VERIFY_NOTE = (
    "Simulated demo receipts, verified by the gateway's real offline "
    "verifier. The demo runs on simulated traffic with the same "
    "enforcement code paths as a live deployment."
)
# RED-032: operator-supplied admin keys carry a floor; prefer the server
# minting one (``POST /api/users`` with no api_key).
_MIN_ADMIN_KEY_CHARS = 24

# RED-013: a request-size bound enforced pre-gate. An oversized payload
# is REJECTED (HTTP 413) before any verdict processing — it never reaches
# the policy layer, emits no receipt and costs no gate latency. Override
# for large-args deployments with RAUCLE_GATE_MAX_PAYLOAD_CHARS.
_MAX_GATE_PAYLOAD_CHARS = 1_000_000

# Q15 (RED-037 round two): rate limiting is mandatory on the SERVING path.
# When slowapi is absent a serving boot refuses with a named error; this
# variable is the deliberate opt-out (the null limiter stands in and the
# boot still logs the warning).
ENV_RATE_LIMIT_DISABLE = "RAUCLE_DISABLE_RATE_LIMIT"


def _gate_payload_limit() -> int:
    import os

    raw = os.environ.get("RAUCLE_GATE_MAX_PAYLOAD_CHARS")
    if raw:
        try:
            value = int(raw)
        except ValueError:
            logger.warning(
                "RAUCLE_GATE_MAX_PAYLOAD_CHARS=%r is not an integer; keeping the default %d",
                raw,
                _MAX_GATE_PAYLOAD_CHARS,
            )
            return _MAX_GATE_PAYLOAD_CHARS
        if value <= 0:
            logger.warning(
                "RAUCLE_GATE_MAX_PAYLOAD_CHARS=%r is not a positive integer; keeping the default %d",
                raw,
                _MAX_GATE_PAYLOAD_CHARS,
            )
            return _MAX_GATE_PAYLOAD_CHARS
        return value
    return _MAX_GATE_PAYLOAD_CHARS


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class DeployAcceptRequest(BaseModel):
    """One external policy-deployment push: portal receipt + artefact."""

    jws: str = Field(..., description="Portal-issued JWS deployment receipt")
    artefact: str = Field(..., description="Canonical policy artefact the receipt binds")


class GateRequest(BaseModel):
    """A tool call from an AI agent to be gated."""

    tool: str = Field(..., description="Tool name to call")
    args: dict[str, Any] = Field(default_factory=dict, description="Tool call arguments")
    agent_id: str = Field(default="", description="Agent identity (optional, defaults to policy)")
    acting_for: str = Field(
        default="", description="The user the agent acts for (B1 pair principal)"
    )
    source: str = Field(default="", description="Inbound source (agent name, IP, or service ID)")
    destination: str = Field(
        default="", description="Outbound destination (API endpoint, service, or tool target)"
    )
    destination_class: str = Field(
        default="",
        description=(
            "Class of the outbound destination (data-flow rules evaluate against this; "
            "an unknown class fails closed when a deny_from_chain_taint rule is active)"
        ),
    )
    session_id: str = Field(
        default="",
        description=(
            "Optional client-declared behavioural session key (EPIC Q). An "
            "identifier, never content: bound verbatim into the signed gate "
            "receipt and the receipt index. When absent, NO session_id is "
            "recorded - no fabricated continuity, no trace_id fallback."
        ),
    )


# Session continuity (EPIC Q lane Q-1): the same bounded-identifier
# discipline as every other caller-controlled field - a length cap and a
# safe charset, validated fail-closed at the HTTP edge before any policy
# evaluation. The value is a correlation key: no filesystem, shell or URL
# characters, so it can be bound into receipts, indexes and logs verbatim.
# Receipts v1.2 (lane K3): the scoped-identifier colon joins the charset
# so a behavioural session may be named the way every other raucle id is
# ("session:sess-1", the same form agent:svc uses). It is still not a
# path separator, a quote or shell metacharacter.
_SESSION_ID_PATTERN = _re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")


def _validate_session_id(session_id: str) -> str:
    if not session_id:  # absent by design: no continuity is declared
        return ""
    if not _re.fullmatch(_SESSION_ID_PATTERN, session_id):
        raise HTTPException(
            status_code=400,
            detail=(
                "session_id must be 1-128 characters from "
                "[A-Za-z0-9._:-] starting alphanumeric (EPIC Q bounded identifier)"
            ),
        )
    return session_id


def _gate_deny_response(req: GateRequest, reason: str) -> dict[str, Any]:
    """Pre-gate deny: the static response shape for failures that occur
    before the receipted gate path (bad token JSON, unauthenticated
    caller). The gateway receipt trail starts at check_tool_call; these
    early failures deny with the caller-declared context echoed back."""
    return {
        "decision": "deny",
        "reason": reason,
        "tool": req.tool,
        "agent_id": req.agent_id,
        "source": req.source,
        "destination": req.destination,
        "policy": None,
        "args_hash": "",
        "receipt_id": None,
        "latency_us": 0,
        "timestamp": "",
    }


class PolicyUpdateRequest(BaseModel):
    """A policy file update from the admin panel."""

    content: str = Field(..., description="YAML policy content")


class ApprovalDecisionRequest(BaseModel):
    """A human decision on an escalated call (PR-E approval workflow)."""

    approved: bool = Field(..., description="Approve or deny the request")
    note: str = Field(default="", description="Optional decision note")


class SuspendRequest(BaseModel):
    """Kill-switch request body: why an agent is being suspended.

    Receipts v1.2 (lane K3): ``kind``/``reason_class`` carry the v1.2
    revocation-receipt request (also the body of /revoke-chains). Left
    empty, the shipped v1.0 block shape is minted.
    """

    reason: str = Field(..., description="Why the agent is being suspended")
    kind: str = Field(
        default="",
        description=(
            "Receipts v1.2: requested revocation receipt kind "
            "(capability, lease or receipt; empty = the shipped v1.0 block)"
        ),
    )
    reason_class: str = Field(
        default="",
        description=(
            "Receipts v1.2: closed reason class "
            "(compromise, owner_departure, scope_correction, policy_change, operational)"
        ),
    )


class RevokeRequest(BaseModel):
    """A3: cascade-revocation request body.

    Receipts v1.2 (lane K3): ``kind``/``reason_class`` request the
    versioned v1.2 block; left empty the shipped v1.0 shape is minted
    (byte-compat with the 30 October emitter).
    """

    token_id: str = Field(
        ..., description="The capability id to revoke (its whole subtree cascades)"
    )
    reason: str = Field(..., description="Why the authority is being revoked")
    kind: str = Field(
        default="",
        description=(
            "Receipts v1.2: requested revocation receipt kind "
            "(capability, lease or receipt; empty = the shipped v1.0 block)"
        ),
    )
    reason_class: str = Field(
        default="",
        description=(
            "Receipts v1.2: closed reason class "
            "(compromise, owner_departure, scope_correction, policy_change, operational)"
        ),
    )


class PolicySimulateRequest(BaseModel):
    """X6: simulate a candidate policy over a historical window.

    Exactly one of ``candidate_policy_yaml`` / ``policy_ref``.
    ``window_ref`` points at a receipt-chain JSONL (the historical
    window); ``input_store_ref`` at the replay input store alongside
    it. Bounded disclosure: the result carries decisions and hashes,
    never arg values or denial reasons.
    """

    candidate_policy_yaml: str | None = Field(
        default=None, description="Candidate policy YAML bytes (policy bytes)"
    )
    policy_ref: str | None = Field(
        default=None, description="Server-side path of the candidate policy"
    )
    window_ref: str | None = Field(
        default=None, description="Historical window: receipt-chain JSONL path"
    )
    input_store_ref: str | None = Field(
        default=None, description="Input store JSONL (recorded call args) for the window"
    )


class PolicySimulateApplyRequest(BaseModel):
    """X6: the named flip path for a signed simulation result.

    The simulation receipt must verify and the submitted candidate
    policy must hash-match the one the simulation signed.
    """

    simulation_receipt: str = Field(..., description="The jws of the signed simulation receipt")
    candidate_policy_yaml: str = Field(..., description="Candidate policy YAML bytes to land")


class UserCreateRequest(BaseModel):
    """Create a new admin panel user.

    ``api_key`` is optional (RED-032): when omitted the server mints a
    256-bit key and returns it exactly once. An operator-supplied key must
    carry at least ``_MIN_ADMIN_KEY_CHARS`` characters.
    """

    api_key: str = Field(
        default="", description="Optional caller-supplied key; omit to have one generated"
    )
    role: str = Field(..., description="admin, operator, or auditor")
    name: str = Field(default="")


class ConfigUpdateRequest(BaseModel):
    """Update gateway configuration fields."""

    host: str | None = None
    port: int | None = None
    admin_port: int | None = None
    signer_backend: str | None = None
    kms_key_id: str | None = None
    kms_region: str | None = None
    policy_file: str | None = None
    policy_dir: str | None = None
    policy_seal_file: str | None = None
    policy_ledger_path: str | None = None
    # Receipts v1.2 (lane K3): the alternative ruleset that mints the
    # signed counterfactual block. It feeds evidence, so it is guarded
    # like every other evidence path (EVIDENCE_PATH_FIELDS).
    counterfactual_ruleset_file: str | None = None
    tool_schema_manifest: str | None = None
    receipt_store: str | None = None
    receipt_store_dir: str | None = None
    receipt_index_path: str | None = None
    audit_chain: str | None = None
    revocations_file: str | None = None
    delegations_file: str | None = None
    signer_key_path: str | None = None
    audit_persist: bool | None = None
    audit_log_file: str | None = None
    siem_enabled: bool | None = None
    siem_backend: str | None = None
    siem_url: str | None = None
    siem_token: str | None = None
    compliance_framework: str | None = None
    registry_path: str | None = None
    gate_auth: str | None = None
    health_check_token: str | None = None
    # Session behavioural windows (EPIC Q lane Q-2): the bounded knobs the
    # gateway reads (TTL, live key cap, per-key entry cap).
    session_window_ttl_seconds: int | None = None
    session_window_max_keys: int | None = None
    session_window_max_entries: int | None = None


class SIEMConfigRequest(BaseModel):
    """Update SIEM forwarding configuration."""

    enabled: bool = False
    backend: str = Field(default="", description="splunk, elastic, sentinel")
    url: str = ""
    token: str = ""


# ---------------------------------------------------------------------------
# Gateway API (port 8080)
# ---------------------------------------------------------------------------


def _live_pulse_payload(gateway: RaucleGateway) -> dict[str, Any]:
    """Public aggregate pulse for the login field: rates and totals only.

    Deliberately holds no per-agent, per-tool or payload data:
    the response is sized by the same information the demo dashboard
    already publishes, minus its detail. State lives on the shared
    gateway object so both apps in the process report the gate traffic.
    """
    import math
    import time as _time

    now = _time.time()
    stats = gateway.get_stats()
    total = int(stats.get("total_requests", 0))
    state = getattr(gateway, "_pulse_state", None)
    if state is None or state["total"] > total:  # fresh process or stats reset
        state = {"t": now, "total": total, "rpm": 0.0, "t0": now}
        gateway._pulse_state = state  # noqa: SLF001 - deliberate shared state
    elapsed = now - state["t"]
    if elapsed >= 1.0:
        inst = (total - state["total"]) / elapsed * 60.0
        alpha = 1.0 if state["rpm"] <= 0.5 else min(0.5, elapsed / 2.0)
        state["rpm"] = max(0.0, state["rpm"] + alpha * (inst - state["rpm"]))
        state["t"] = now
        state["total"] = total
    if math.isnan(state["rpm"]):
        state["rpm"] = 0.0
    payload = {
        "live": state["rpm"] > 0.5,
        "rpm_1m": int(round(state["rpm"])),
        "uptime_s": int(now - state["t0"]),
        "totals": {
            "requests": total,
            "allowed": int(stats.get("allowed", 0)),
            "denied": int(stats.get("denied", 0)),
            "escalated": int(stats.get("escalated", 0)),
        },
    }
    avg = stats.get("avg_latency_us")
    if avg is not None:
        payload["avg_latency_us"] = avg
    return payload


def _build_intent_hint(
    req: GateRequest, token_intent: dict[str, Any] | None
) -> dict[str, Any] | None:
    """Build the receipt intent hint for a capability-token intent.

    Invariant: the hint binds the task intent plus a BOUNDED disclosure -
    only the field names the intent constrains (keys inside constraint
    entries), never the constraint kinds themselves - so a third party
    re-checks the action against the approved purpose offline.
    """
    if token_intent is None:
        return None
    c = token_intent.get("constraints") or {}
    fields: set[str] = set()
    for kind in (
        "allowed_values",
        "forbidden_values",
        "starts_with",
        "max_value",
        "min_value",
    ):
        fields |= set(c.get(kind, {}) or {})
    fields |= set(c.get("required_present", []) or [])
    return {
        "intent": token_intent,
        "intent_check": {
            "tool": req.tool,
            "satisfied_fields": {f: req.args[f] for f in fields if f in req.args},
        },
    }


def _demo_dlp_advisory_scan(
    gateway: RaucleGateway,
    req: GateRequest,
    agent_id: str,
    trace_id: str,
    response: dict[str, Any],
) -> None:
    """D2: run the OSS advisory redaction engine over one demo gate call.

    Demo-plane only. When ``RAUCLE_DEMO_MODE`` is on, the gate route runs
    the call's arguments through the real advisory redaction middleware
    (``raucle.middleware``, wired pattern classes) and mints an
    ``x_dlp`` receipt citing the gate receipt for the decision. The
    scanned values are the canned synthetic patterns the demo agents
    generate; production gate traffic is never content-scanned here
    (the ``x_dlp`` emitter surface belongs to the enterprise content
    proxy, per docs/spec/provenance/v1.2/content-dlp.md). Advisory and
    fail-open by contract: this layer never changes the already-made
    decision and never raises into the gate path.
    """
    receipt_id = str(response.get("receipt_id") or "")
    if not receipt_id:
        # No receipted decision to cite: the offline verifier refuses
        # uncited findings, so nothing is minted. Never fabricate.
        return
    from raucle.demo_session import _demo_mode_on, run_demo_dlp_scan

    if not _demo_mode_on():
        return
    try:
        run_demo_dlp_scan(
            gateway,
            tool=req.tool,
            args=req.args,
            agent_id=agent_id,
            destination=str(req.destination or ""),
            session_id=_validate_session_id(req.session_id),
            trace_id=trace_id,
            gate_receipt_id=receipt_id,
            gate_decision=str(response.get("decision") or ""),
        )
    except Exception:
        logger.warning(
            "demo DLP advisory scan failed open (advisory layer, the gate decision is unchanged)",
            exc_info=True,
        )


def _handle_gate_tool_call(
    gateway: RaucleGateway,
    _request: Request,  # kept for call-site symmetry; unused (S1172)
    req: GateRequest,
    x_api_key: str | None,
    x_capability_token: str | None,
    x_trace_id: str | None,
    x_approval_id: str | None,
) -> dict[str, Any]:
    """Gate a tool call. Returns allow/deny/escalate decision.

    Authentication (RAUCLE_GATE_AUTH): "off" trusts the declared
    agent_id (internal networks only); "apikey" requires X-Api-Key;
    "token" requires X-Capability-Token (verified against the trust
    registry).

    Denial semantics: an UNAUTHENTICATED caller (no verifiable
    identity) is denied pre-gate with the reason - decision + reason
    echoed, no receipt, because there is no trustworthy chain to
    bind. An ATTRIBUTABLE denial - a validly-signed token whose call
    exceeds the delegated authority (wrong tool, constraint
    violation) - is denied WITH a receipt binding the delegated-
    authority chain: who tried what is evidence, not noise.
    """
    import json as _json

    if len(_json.dumps(req.args, ensure_ascii=False)) > _gate_payload_limit():
        raise HTTPException(
            status_code=413,
            detail=(
                f"request payload exceeds {_gate_payload_limit()} "
                "canonical-argument characters (RED-013 size bound)"
            ),
        )

    token_dict = None
    if x_capability_token:
        try:
            token_dict = _json.loads(x_capability_token)
        except _json.JSONDecodeError:
            return _gate_deny_response(req, "X-Capability-Token is not valid JSON")
    import uuid as _uuid

    trace_id = x_trace_id or _uuid.uuid4().hex
    agent_id, auth_reason, token_decision = gateway.authenticate_caller(
        api_key=x_api_key,
        capability_token=token_dict,
        tool=req.tool,
        args=req.args,
        declared_agent_id=req.agent_id,
        acting_for=req.acting_for,
    )
    if agent_id is None:
        return _gate_deny_response(req, f"unauthenticated: {auth_reason}")
    # Receipts v1.1: bind the delegated-authority chain into the receipt
    from raucle.provenance import authorization_block as _authorization_block

    authorization = _authorization_block(token_dict) if token_dict else None
    # Receipts v1.2: bind the task intent + a bounded disclosure (only the
    # fields the intent constrains) so a third party re-checks the action
    # against the approved purpose offline.
    intent_hint = _build_intent_hint(req, (token_dict or {}).get("intent"))
    response = gateway.check_tool_call(
        req.tool,
        req.args,
        agent_id,
        req.source,
        req.destination,
        trace_id=trace_id,
        approval_id=x_approval_id or "",
        destination_class=req.destination_class,
        _authorization_hint=authorization,
        _token_decision=token_decision,
        _intent_hint=intent_hint,
        _acting_for=req.acting_for,
        session_id=_validate_session_id(req.session_id),
    )
    # Internal bookkeeping fields never leave the process boundary
    response.pop("_trace_id", None)
    response.pop("_args", None)
    response.pop("_authorization_hint", None)
    # D2: the demo plane's advisory redaction scan. Runs only in demo
    # mode, only for receipted decisions, and never touches the
    # response already computed for the caller.
    _demo_dlp_advisory_scan(gateway, req, agent_id, trace_id, response)
    return response


# ---------------------------------------------------------------------------
# Security headers
# ---------------------------------------------------------------------------


def _panel_script_hashes() -> list[str]:
    """SHA-256 CSP hashes of every inline script block the panel/topology
    pages ship. ``script-src`` is hash-pinned (no ``unsafe-inline``), so a
    modified script block stops executing - the CI script-hash test turns
    that stale-hash failure into a red build instead of a dead panel."""

    out: list[str] = []
    for html in (ADMIN_PANEL_HTML, TOPOLOGY_HTML):
        for m in _re.finditer(r"<script[^>]*>(.*?)</script>", html, _re.S):
            body = m.group(1)
            if body.strip():
                digest = _hashlib.sha256(body.encode()).digest()
                out.append("'sha256-" + _base64.b64encode(digest).decode() + "'")
    return out


def _panel_csp() -> str:
    """Content-Security-Policy for the admin panel and topology pages.

    Inline scripts are hash-pinned; inline event handlers are gone (all
    dispatch runs through the delegated data-hi listener), so ``script-src``
    no longer accepts ``unsafe-inline``. ``style-src 'unsafe-inline'`` stays:
    the single-string panel ships its stylesheet inline.
    """

    return (
        "default-src 'none'; script-src " + " ".join(_panel_script_hashes()) + "; "
        "style-src 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; "
        "form-action 'none'; frame-ancestors 'none'; base-uri 'none'"
    )


class _NullLimiter:
    """Stand-in limiter so route decorators are unconditional.

    slowapi is an optional dependency. When it is absent the gateway logs a
    warning and this object makes ``@_limiter.limit(...)`` a no-op, rather than
    the route definition branching on whether the library imported.

    Q15: reaching this stand-in on the serving path requires an explicit
    ``RAUCLE_DISABLE_RATE_LIMIT=1`` opt-out - without it the app factory
    refuses the boot (nothing serves unlimited silently).
    """

    def limit(self, *_args: Any, **_kwargs: Any) -> Any:
        def _decorator(func: Any) -> Any:
            return func

        return _decorator


def _client_key(request: Request) -> str:
    """Rate-limit key for the caller, proxy-aware.

    Behind a TLS-terminating proxy every request's socket peer is the proxy, so
    a plain remote-address key becomes one global bucket. The left-most
    X-Forwarded-For entry is trusted ONLY when RAUCLE_TRUST_PROXY is set, the
    same convention raucle/server.py uses for its token bucket (RED-037).
    """
    import os

    if os.environ.get("RAUCLE_TRUST_PROXY", "").lower() in ("1", "true", "yes"):
        forwarded = request.headers.get("x-forwarded-for", "")
        if forwarded:
            return forwarded.split(",")[0].strip() or "unknown"
    client = getattr(request, "client", None)
    return client.host if client and client.host else "unknown"


def _install_security_headers(app: FastAPI) -> None:
    """Add the response headers both apps should always carry (RED-033,
    T-S6).

    ``script-src`` is hash-pinned: inline event handlers were removed from
    the panel markup (dispatch runs through the delegated ``data-hi``
    listener), so ``unsafe-inline`` is no longer needed in script-src and a
    hostile inline script cannot execute on the panel pages.
    """

    @app.middleware("http")
    async def _security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers.setdefault("Content-Security-Policy", _panel_csp())
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        return response


def create_gateway_app(gateway: RaucleGateway) -> FastAPI:
    """Create the gateway API app (agent-facing)."""
    app = FastAPI(
        title="Raucle Gateway",
        description="AI agent governance gateway",
        version="0.1.0",
    )
    _limiter: Any = _NullLimiter()
    try:
        import os

        from slowapi import Limiter
        from slowapi.errors import RateLimitExceeded
        from slowapi.middleware import SlowAPIMiddleware

        _limit_default = os.environ.get("RAUCLE_GATE_RATE_LIMIT", "1000/minute")
        _limiter = Limiter(key_func=_client_key, default_limits=[_limit_default])
        app.state.limiter = _limiter
        app.add_exception_handler(
            RateLimitExceeded,
            lambda req, exc: JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded", "retry_after": "60"},
            ),
        )
        app.add_middleware(SlowAPIMiddleware)
    except ImportError as _import_error:
        _limiter = _NullLimiter()
        # RED-037: silently running without a rate limit is the failure mode
        # worth shouting about, because the deployment believes it has one.
        logger.warning(
            "slowapi is not installed: the gateway is running WITHOUT rate limiting. "
            'Install the "server" extra (pip install "raucle[server]") to enable it.'
        )
        # Q15 (RED-037 round two): creating the gateway app IS serving mode,
        # so a serving boot without the limiter refuses by name unless the
        # operator explicitly opts out. Local dev/CLI paths never construct
        # this app, so they are unaffected.
        import os as _os

        if _os.environ.get(ENV_RATE_LIMIT_DISABLE, "").lower() not in ("1", "true", "yes"):
            from raucle.errors import ConfigurationError

            raise ConfigurationError(
                "serving the gateway without a rate limiter is refused: slowapi is "
                "not installed. Install the [server] extra "
                '(pip install "raucle[server]"), or set '
                "RAUCLE_DISABLE_RATE_LIMIT=1 to serve without limiting deliberately."
            ) from _import_error

    _install_security_headers(app)

    @app.get("/api/live-pulse", response_class=None)
    def live_pulse() -> JSONResponse:  # type: ignore[name-defined]
        """Public aggregate pulse for the login field (aggregates only)."""
        return JSONResponse(_live_pulse_payload(gateway))  # type: ignore[name-defined]

    @app.post("/gate", responses={413: {"description": "payload exceeds canonical size bound"}})
    @_limiter.limit(os.environ.get("RAUCLE_GATE_ROUTE_LIMIT", "200/minute"))
    def gate_tool_call(
        request: Request,
        req: GateRequest,
        x_api_key: str | None = Header(None, alias="X-Api-Key"),
        x_capability_token: str | None = Header(None, alias="X-Capability-Token"),
        x_trace_id: str | None = Header(None, alias="X-Trace-Id"),
        x_approval_id: str | None = Header(None, alias="X-Approval-Id"),
    ) -> dict[str, Any]:
        """Gate a tool call. Returns allow/deny/escalate decision."""
        return _handle_gate_tool_call(
            gateway,
            request,
            req,
            x_api_key,
            x_capability_token,
            x_trace_id,
            x_approval_id,
        )

    @app.get(
        "/health",
        responses={"401": {"description": "Health token required but missing/incorrect"}},
    )
    def health(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        if gateway.config.health_check_token:
            key = authorization or ""
            if key.startswith(_BEARER_PREFIX):
                key = key[len(_BEARER_PREFIX) :]
            import hmac as _hmac

            if not _hmac.compare_digest(key, gateway.config.health_check_token):
                raise HTTPException(status_code=401, detail="Health check unauthorized")
        return _health_payload(gateway)

    @app.get("/livez")
    def livez() -> dict[str, str]:
        """Liveness probe (Q9 review, container healthcheck): process-up only.

        Deliberately no auth and no admin-plane dependency, unlike /health
        (aggregate payload, honours health_check_token): the container
        healthcheck polls THIS route on the agent-facing gateway port, so a
        deployment that token-gates /health, or that runs without the admin
        plane bound, still reports live. Aggregate detail stays on /health.
        """
        return {"status": "live"}

    @app.post(
        "/api/revoke",
        responses={
            "401": {"description": "Admin API key missing, incorrect, or not configured"},
        },
    )
    def revoke(
        req: RevokeRequest,
        authorization: str | None = Header(None),
    ) -> dict[str, Any]:
        """Receipts v1.2 (lane K3): programmatic revocation on the
        agent-facing surface, receipted.

        Fail-closed against the configured admin API key (constant-time
        comparison, the health-check pattern): a gateway with no
        admin_api_key refuses every caller rather than serving the
        revocation surface unauthenticated. There is no admin users
        manager on this port, so the key IS the authority and the
        receipt records the operator as actor="admin".
        """
        key = authorization or ""
        if key.startswith(_BEARER_PREFIX):
            key = key[len(_BEARER_PREFIX) :]
        import hmac as _hmac

        if not gateway.config.admin_api_key or not _hmac.compare_digest(
            key, gateway.config.admin_api_key
        ):
            raise HTTPException(
                status_code=401,
                detail="Admin API key required (Authorization: Bearer <admin_api_key>)",
            )
        return gateway.revoke_capability(
            req.token_id,
            reason=req.reason,
            actor="admin",
            kind=req.kind,
            reason_class=req.reason_class,
        )

    _register_deployment_intake_routes(app, gateway)

    @app.get(
        "/.well-known/raucle-conformance",
        responses={
            503: {
                "description": "Service Unavailable: conformance data not built "
                "(run scripts/gen_conformance_data.py)",
            },
        },
    )
    def raucle_conformance() -> JSONResponse:
        """Serve the build-pinned standards/ vector conformance record.

        The response is the committed file ``docs/spec/conformance/conformance.json``
        verbatim (generated by ``scripts/gen_conformance_data.py``, which CI
        re-runs and compares byte-for-byte). 503 when the artifact is absent —
        a deployment that was never built with it has nothing to claim.
        """
        data_path = (
            Path(__file__).resolve().parent.parent
            / "docs"
            / "spec"
            / "conformance"
            / "conformance.json"
        )
        if not data_path.is_file():
            raise HTTPException(
                status_code=503,
                detail="conformance data not built; run scripts/gen_conformance_data.py",
            )
        payload = json.loads(data_path.read_text())
        return JSONResponse(
            payload,
            headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
        )

    return app


def _register_deployment_intake_routes(app: FastAPI, gateway: RaucleGateway) -> None:
    """POST /api/deployments/accept (H1 phase 5).

    Registered ONLY when ``deployment_trust`` is configured: the default
    posture keeps the endpoint absent (404), so an unconfigured gate
    refuses external deployments by not hearing about them at all.
    """
    from raucle.deployment_intake import (
        DeploymentIntakeError,
        accept_deployment,
        resolve_deployment_trust,
    )

    if resolve_deployment_trust(getattr(gateway.config, "deployment_trust", None)) is None:
        return

    @app.post(
        "/api/deployments/accept",
        responses={
            "400": {"description": "Artefact malformed or digest mismatch"},
            "401": {"description": "JWS signature does not verify against the pinned root"},
            "403": {"description": "Untrusted issuer, malformed receipt, or replayed nonce"},
            "503": {"description": "Pinned trust root or nonce cache unavailable (fail-closed)"},
        },
    )
    def accept_deployment_endpoint(
        req: DeployAcceptRequest,
    ) -> dict[str, Any]:
        """Accept a portal-signed policy deployment artefact.

        Verify against the gate's PINNED portal trust root, apply the
        artefact atomically, append the bound deployment to the gate's
        hash-chained audit chain under the gate's own signer. Unverified
        pushes fail closed: never applied, and the rejection is audited.
        """
        try:
            status, body = accept_deployment(gateway, jws=req.jws, artefact=req.artefact)
        except DeploymentIntakeError as exc:
            raise HTTPException(
                status_code=exc.status_code, detail={"code": exc.code, "detail": exc.detail}
            ) from exc
        if status != 200:
            raise HTTPException(status_code=status, detail=body)
        return body


# ---------------------------------------------------------------------------
# Admin Panel API (port 8081)
# ---------------------------------------------------------------------------


def _validate_policy_content(content: str) -> dict[str, Any]:
    """Parse and validate policy YAML content.

    Returns ``{"valid": True}`` when the content is a well-formed policy
    document, ``{"valid": False, "error": ...}`` otherwise. Used as the
    sanitiser for user-supplied policy content before it is written to
    disk (taint-flow break for S2083).
    """
    try:
        import yaml

        from raucle.policy import PolicyFile

        data = yaml.safe_load(content)
        PolicyFile.from_dict(data)
        return {"valid": True}
    except Exception as exc:
        return {"valid": False, "error": str(exc)}


# Fields that decide WHERE evidence lands. Redirecting one changes the audit
# story, so an operator may not move it and the target must sit inside the
# data root (RED-035). Receipts v1.2 (lane K3): the counterfactual ruleset
# names the alternative policy the signed block speaks about, so it is
# guarded like the rest: it decides what the evidence can claim.
EVIDENCE_PATH_FIELDS = (
    "policy_file",
    "policy_dir",
    "receipt_store",
    "receipt_store_dir",
    "receipt_index_path",
    "audit_chain",
    "audit_log_file",
    "registry_path",
    "revocations_file",
    "delegations_file",
    "policy_seal_file",
    "policy_ledger_path",
    "signer_key_path",
    "counterfactual_ruleset_file",
    # EPIC W lane W2: the manifest the definition digest binds against
    # feeds evidence exactly as the counterfactual ruleset does.
    "tool_schema_manifest",
)


def _evidence_root(config: Any) -> Path:
    """The directory evidence files must stay inside."""
    root = getattr(config, "data_root", "") or ""
    if root:
        return Path(root).resolve()
    return Path(config.receipt_store).resolve().parent


def _validate_evidence_paths(config: Any, fields: tuple[str, ...] | list[str]) -> list[str]:
    """Absolute paths contained by the data root, or named refusals.

    Only the fields being changed are checked: an existing deployment may
    legitimately hold evidence files outside the root, and a change to one
    path must not be refused because of the value of another.

    ``raucle._paths.validate_path`` only resolves and checks existence, so it
    is not a containment barrier; this comparison is.
    """
    root = _evidence_root(config)
    errors: list[str] = []
    for field in fields:
        value = getattr(config, field, "") or ""
        if not value:
            continue
        path = Path(value)
        if not path.is_absolute():
            errors.append(f"{field} must be an absolute path")
            continue
        try:
            path.resolve().relative_to(root)
        except ValueError:
            errors.append(f"{field} must sit inside the data root {root}")
    return errors


def _check_auth(
    users: UserManager,
    authorization: str | None,
    x_totp: str | None,
    sessions: AdminSessionManager | None = None,
) -> GatewayUser:
    """Extract and validate the API key and optional TOTP code.

    Routes that call this helper directly (rather than declaring it as a
    dependency) pass the FastAPI ``Header`` default object, not ``None``.
    Coerce anything that is not a string to ``None`` so a missing optional
    header behaves as missing instead of reaching the comparators.

    X3 slice 1: an ``rst_``-prefixed bearer token is an admin SESSION
    token (T-S3). It resolves to the session's user with NO TOTP re-check
    - the code was verified once at session open - and the session's own
    expiry governs. An unknown/expired session is a plain 403, the same
    shape as an invalid key, with zero disclosure about which failed.
    """
    if not isinstance(authorization, str):
        authorization = None
    if not isinstance(x_totp, str) or not x_totp.strip():
        x_totp = None
    if authorization is None:
        raise HTTPException(status_code=401, detail="Missing Authorization header")
    key = authorization
    if key.startswith(_BEARER_PREFIX):
        key = key[len(_BEARER_PREFIX) :]
    if key.startswith(SESSION_TOKEN_PREFIX):
        return _session_token_user(sessions, key)
    user = users.get_user(key)
    if user is None:
        raise HTTPException(status_code=403, detail="Invalid API key")
    _require_totp_gate(users, user, x_totp)
    return user


def _session_token_user(sessions: AdminSessionManager | None, key: str) -> GatewayUser:
    """Resolve an ``rst_`` session token to its user, failing closed."""
    if sessions is None:
        # Session tokens exist but no manager is wired: refuse, never
        # fall through to key comparison.
        raise HTTPException(status_code=401, detail="Session tokens not enabled")
    user = sessions.resolve(key)
    if user is None:
        raise HTTPException(status_code=403, detail="Invalid or expired session")
    return user


def _require_totp_gate(users: UserManager, user: GatewayUser, x_totp: str | None) -> None:
    """401/403 unless the user's TOTP requirement is satisfied."""
    if not user.requires_mfa():
        return
    if not x_totp:
        raise HTTPException(
            status_code=401,
            detail="MFA required: provide X-TOTP header with 6-digit code",
        )
    if not users.verify_totp(user, x_totp):
        raise HTTPException(status_code=403, detail="Invalid TOTP code")


def _check_access(users: UserManager, user: GatewayUser, resource: str) -> None:
    """Raise 403 unless the user's role may access *resource*."""
    if not users.can_access(user.user_id, resource):
        raise HTTPException(
            status_code=403, detail=f"Role '{user.role}' cannot access '{resource}'"
        )


def create_admin_app(gateway: RaucleGateway, users: UserManager) -> FastAPI:
    """Create the admin panel app (operator-facing).

    Thin composition root: auth closures over *users*, then endpoint
    groups are registered by dedicated module-level functions.
    """

    def check_auth(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> GatewayUser:
        return _check_auth(users, authorization, x_totp, sessions)

    def check_access(user: GatewayUser, resource: str) -> None:
        _check_access(users, user, resource)

    # X3 slice 1 (T-S3): receipted admin sessions, shared by the key and
    # OIDC login paths. Receipts ride the gateway signer only when receipt
    # emission is configured; the manager degrades to receipt-less sessions
    # otherwise (the composition root logs that gap, never silently).
    sessions = AdminSessionManager(
        users,
        ttl_seconds=getattr(gateway.config, "admin_session_ttl", 3600),
        max_sessions=getattr(gateway.config, "admin_sessions_max", 64),
        receipt_emitter=gateway._emit_admin_session_receipt,
    )

    # OIDC federation is OFF by default: an enabled config fetches the
    # discovery document HERE, fail-closed - an unreachable or malformed
    # issuer refuses the admin app construction, exactly the boot banner
    # plus refusal the operator chose when enabling.
    oidc_federation = None
    if getattr(gateway.config, "oidc_enabled", False):
        from raucle import admin_oidc

        cfg = gateway.config
        provider = admin_oidc.OIDCProviderConfig(
            cfg.oidc_issuer,
            cfg.oidc_client_id,
            redirect_uri=cfg.oidc_redirect_uri,
            scope=cfg.oidc_scope,
        )
        federation = admin_oidc.OIDCFederation(
            provider,
            admin_oidc.client_secret_from_env(),
        )
        federation.start()
        oidc_federation = federation
        logger.warning(
            "X3 boot banner: OIDC federation ENABLED for admin plane; "
            "provider issuer %s (client_id %s). Sessions after OIDC login "
            "carry receipted lifecycle semantics (open + close).",
            cfg.oidc_issuer,
            cfg.oidc_client_id,
        )

    app = FastAPI(
        title="Raucle Gateway Admin",
        description="Enterprise admin panel for policy, stats, and config",
        version="0.1.0",
    )

    _install_security_headers(app)

    # Q9 review (admin exposure): the admin plane is rate limited IN APP,
    # because the digest-pinned stock Caddy image ships no rate-limit module
    # (verified against caddy 2.11.9-alpine: caddy list-modules). Default is
    # 120 requests per minute per client, comfortably above the panel's
    # bounded polling; operators override with RAUCLE_ADMIN_RATE_LIMIT. Same
    # shape as the gateway app's limiter: slowapi when installed, a loud
    # warning when not (the deployment must not believe it has a limit).
    try:
        import os

        from slowapi import Limiter
        from slowapi.errors import RateLimitExceeded
        from slowapi.middleware import SlowAPIMiddleware

        _admin_limit_default = os.environ.get("RAUCLE_ADMIN_RATE_LIMIT", "120/minute")
        app.state.limiter = Limiter(key_func=_client_key, default_limits=[_admin_limit_default])
        app.add_exception_handler(
            RateLimitExceeded,
            lambda req, exc: JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded", "retry_after": "60"},
            ),
        )
        app.add_middleware(SlowAPIMiddleware)
    except ImportError:
        logger.warning(
            "slowapi is not installed: the admin panel is running WITHOUT rate "
            'limiting. Install the "server" extra (pip install "raucle[server]") '
            "to enable it."
        )

    _register_health_routes(app, gateway)
    _register_stats_routes(app, gateway, check_auth, check_access)
    _register_demo_findings_routes(app, check_auth, check_access)
    _register_learn_routes(app, gateway, check_auth, check_access)
    _register_policy_routes(app, gateway, check_auth, check_access)
    _register_simulate_routes(app, gateway, users, check_access)
    _register_authority_routes(app, gateway, check_auth, check_access)
    _register_receipt_routes(app, gateway, check_auth, check_access)
    _register_siem_routes(app, gateway, check_auth, check_access)
    _register_user_routes(app, users, check_auth, check_access)
    _register_session_routes(app, users, sessions, oidc_federation)
    _register_config_routes(app, gateway, check_auth, check_access)
    # D5: demo-mode MCP manifest scanning, backed by the real scanner
    from raucle.demo_scenarios import register_demo_mcp_routes

    register_demo_mcp_routes(app, check_auth, check_access)
    # D9: read-only emergency authority stop screen (demo plane)
    from raucle.demo_stop import register_demo_stop_routes

    register_demo_stop_routes(app, check_auth, check_access)
    # D10: guided policy-simulate showpiece (demo plane, no apply route)
    from raucle.demo_policy_sim import register_demo_policy_sim_routes

    register_demo_policy_sim_routes(app, check_auth, check_access)
    # E1: demo-mode capability-token inspection, backed by the real
    # capability machinery (issuer mint/attenuate + CapabilityGate.check)
    from raucle.demo_capabilities import register_demo_capability_routes

    register_demo_capability_routes(app, check_auth, check_access, lambda: gateway)
    # G4/G6: cross-organisation receipt verification and
    # conformance-without-disclosure screens (demo plane, read-only)
    from raucle.demo_cross_org import register_demo_cross_org_routes

    register_demo_cross_org_routes(app, check_auth, check_access)
    # G3: the demo assurance packet - the real audit-pack builder and
    # offline verifier over this deployment's own receipt chain (read-only)
    from raucle.demo_assurance_packet import register_demo_assurance_packet_routes

    register_demo_assurance_packet_routes(app, check_auth, check_access, lambda: gateway)
    # G5: the demo key model - the live signer configuration, enrolment
    # checks and rotation story (read-only)
    from raucle.demo_key_model import register_demo_key_model_routes

    register_demo_key_model_routes(app, check_auth, check_access, lambda: gateway)
    # Demo operational surfaces: the Users / SIEM / Config tabs render
    # read-only demo views (simulated roster, real+simulated SIEM view,
    # read-only config profile) instead of the operator edit forms.
    from raucle.demo_ops import register_demo_ops_routes

    register_demo_ops_routes(app, gateway, check_auth, check_access)
    # G-coverage: the receipted-share metric view over this deployment's own
    # receipt stream (Route A demo plane; the OSS coverage engine itself
    # lives in the raucle-agent-assurance correlation service).
    from raucle.demo_coverage import register_demo_coverage_routes

    register_demo_coverage_routes(app, gateway, check_auth, check_access)
    # D16: the session behaviour views - live session-rules configuration,
    # per-session windows from the real receipt index (v3), and the
    # session-monitor findings with their cited gate receipts (read-only).
    from raucle.demo_session import register_demo_session_routes

    register_demo_session_routes(app, gateway, check_auth, check_access)
    _register_ui_routes(app)

    return app


def _register_health_routes(app: FastAPI, gateway: RaucleGateway) -> None:
    """Health endpoint (optional auth via health_check_token)."""

    @app.get(
        "/health",
        responses={"401": {"description": "Health token required but missing/incorrect"}},
    )
    def admin_health(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        if gateway.config.health_check_token:
            key = authorization or ""
            if key.startswith(_BEARER_PREFIX):
                key = key[len(_BEARER_PREFIX) :]
            import hmac as _hmac

            if not _hmac.compare_digest(key, gateway.config.health_check_token):
                raise HTTPException(status_code=401, detail="Health check unauthorized")
        return _health_payload(gateway)

    @app.get(
        "/api/demo-key",
        responses={
            "200": {"description": "Public read-only demo key"},
            "404": {"description": "Demo mode not configured"},
        },
    )
    def demo_key() -> dict[str, str]:
        """Public endpoint exposing the read-only demo key (RAUCLE_DEMO_KEY).

        The key this returns holds the auditor role only: dashboard, connections
        and receipts, all read-only. It exists so the admin panel's View Demo
        button can enter demo mode without the visitor needing credentials.
        Never returns an admin or operator key.
        """
        import os

        dk = os.environ.get("RAUCLE_DEMO_KEY", "")
        if not dk or os.environ.get("RAUCLE_DEMO_MODE", "").lower() not in ("1", "true", "yes"):
            # A demo key on a production instance would publish read access to
            # the receipt chain, so it is served only when demo mode is on.
            raise HTTPException(404, "demo mode not configured")
        return {"demo_key": dk}


def _register_stats_routes(
    app: FastAPI, gateway: RaucleGateway, check_auth: Any, check_access: Any
) -> None:
    """Dashboard stats and the live connection log."""

    @app.get("/api/live-pulse", response_class=None)
    def live_pulse_admin() -> JSONResponse:  # type: ignore[name-defined]
        """Public aggregate pulse for the login field (aggregates only)."""
        return JSONResponse(_live_pulse_payload(gateway))  # type: ignore[name-defined]

    @app.get(
        "/api/stats",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def get_stats(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "stats")
        return gateway.get_stats()

    @app.get(
        "/api/faults",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def get_faults(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Query the persisted fault counter + the last boot self-test (X4)."""
        user = check_auth(authorization, x_totp)
        check_access(user, "stats")
        counts = gateway.fault_counts()
        boot = getattr(gateway, "boot_selftest_result", None)
        return {"faults": counts, "boot_selftest": boot}

    @app.get(
        "/api/connections",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def get_connections(
        limit: int = 100,
        tool: str = "",
        decision: str = "",
        source: str = "",
        destination: str = "",
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Return recent connections, optionally filtered."""
        user = check_auth(authorization, x_totp)
        check_access(user, "stats")
        connections = gateway.get_connections(limit=500)
        # Apply filters
        if tool:
            connections = [c for c in connections if tool.lower() in c.get("tool", "").lower()]
        if decision:
            connections = [
                c for c in connections if decision.lower() in c.get("decision", "").lower()
            ]
        if source:
            connections = [c for c in connections if source.lower() in c.get("source", "").lower()]
        if destination:
            connections = [
                c for c in connections if destination.lower() in c.get("destination", "").lower()
            ]
        return {"connections": connections[:limit], "count": len(connections)}


def _register_demo_findings_routes(app: FastAPI, check_auth: Any, check_access: Any) -> None:
    """Read-only demo findings plane backing the EPIC D demo screens.

    The demo key (auditor role) may read findings; the resource gate is the
    same read-only stats plane the connections log uses. Everything the
    endpoint returns is computed at request time by the real pattern and
    classifier engines over the simulated demo traffic packs in
    :mod:`raucle.demo_findings`. Nothing from real traffic is included.
    """

    @app.get(
        "/api/demo-findings",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "400": {"description": "Unknown demo scenario"},
        },
    )
    def get_demo_findings(
        scenario: str = "all",
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "stats")
        try:
            return build_demo_findings(scenario=scenario or "all")
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc


def _register_learn_routes(
    app: FastAPI, gateway: RaucleGateway, check_auth: Any, check_access: Any
) -> None:
    """Learn mode: observe unmatched traffic, draft policies from it.

    Fail-closed by design: learn mode never authorises traffic. The gate
    records unmatched calls only when RAUCLE_LEARN_MODE is enabled, and
    the endpoints below expose counts and a draft policy for human review.
    The draft is never deployed automatically: the operator copies it
    into the policy editor, edits, saves, and reloads.
    """

    @app.get(
        "/api/learn/summary",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Insufficient role"},
        },
    )
    def learn_summary(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "policies")
        return gateway.learn_summary()

    @app.get(
        "/api/learn/draft",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Insufficient role"},
            "200": {"description": "Draft policy YAML (empty string if nothing learned)"},
        },
    )
    def learn_draft(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "policies")
        return {"yaml": gateway.draft_policy()}

    @app.post(
        "/api/learn/clear",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Insufficient role"},
        },
    )
    def learn_clear(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "policies")
        gateway._learn_clear()
        return {"status": "cleared"}


def _policy_dir_response(
    policy_dir: str,
    validate_path: Any,
    file: str,
) -> dict[str, Any]:
    """Build the directory-mode response for GET /api/policies.

    SECURITY: never touches a user-supplied path. The requested file is
    matched by basename against the files enumerated from the policy
    directory via glob (server-controlled list), making path traversal
    structurally impossible.
    """
    pdir = validate_path(policy_dir, must_exist=False)
    if not pdir.is_dir():
        return {"content": "", "files": [], "mode": "dir", "path": str(pdir)}
    files = sorted(pdir.glob("*.yaml"))
    file_list = [{"name": f.name, "path": str(f), "size": f.stat().st_size} for f in files]
    if file:
        target = next((f for f in files if f.name == Path(file).name), None)
        if target is None:
            raise HTTPException(404, "File not found in policy directory")
        content = target.read_text(encoding="utf-8")
    elif files:
        content = files[0].read_text(encoding="utf-8")
    else:
        content = ""
    return {"content": content, "files": file_list, "mode": "dir", "path": str(pdir)}


def _register_policy_routes(
    app: FastAPI, gateway: RaucleGateway, check_auth: Any, check_access: Any
) -> None:
    """Policy file management (view, edit, validate, reload)."""

    @app.get(
        "/api/policies",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "404": {"description": "File not found"},
        },
    )
    def get_policies(
        file: str = "",
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Get policy file content. If policy_dir is set, list all files."""
        from raucle._paths import validate_path

        user = check_auth(authorization, x_totp)
        check_access(user, "policies")
        if gateway.config.policy_dir:
            return _policy_dir_response(gateway.config.policy_dir, validate_path, file)
        policy_path = validate_path(gateway.config.policy_file, must_exist=False)
        content = policy_path.read_text() if policy_path.exists() else ""
        return {
            "content": content,
            "files": [{"name": policy_path.name, "path": str(policy_path)}],
            "mode": "single",
            "path": str(policy_path),
        }

    @app.put(
        "/api/policies",
        responses={
            "400": {"description": "Invalid policy YAML content"},
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def update_policies(
        req: PolicyUpdateRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "policies")
        # SECURITY: validate user-supplied YAML before writing to disk,
        # then write the CANONICALLY RE-SERIALISED document (not the raw
        # request string). This breaks the request-to-disk taint flow:
        # what lands on disk is parser output, not raw user input.
        import yaml as _yaml

        from raucle._paths import validate_path
        from raucle.policy import PolicyFile as _PolicyFile

        try:
            parsed = _yaml.safe_load(req.content)
            _PolicyFile.from_dict(parsed)
        except Exception as exc:
            raise HTTPException(400, f"Invalid policy content: {exc}") from exc
        safe_content = _yaml.dump(parsed, default_flow_style=False, sort_keys=False)

        policy_path = validate_path(gateway.config.policy_file, must_exist=False)
        policy_path.write_text(safe_content, encoding="utf-8")
        # Policy change ledger (PR-E): every admin panel write is
        # hash-chained with actor + content hash. Failure to ledger
        # degrades attribution, not the write itself.
        try:
            gateway._append_policy_ledger(
                action="policy_updated",
                file=str(policy_path),
                content=safe_content,
                actor=user.name or user.role,
            )
        except Exception:
            logger = logging.getLogger(__name__)
            logger.warning("policy ledger append failed", exc_info=True)
        result = gateway.reload_policies()
        return result

    @app.post(
        "/api/policies/reload",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def reload_policies(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "policies")
        return gateway.reload_policies()

    @app.post(
        "/api/tool-schemas/reload",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def reload_tool_schemas(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """EPIC W lane W2: re-read the configured tool schema manifest and
        receipt every observed definition drift (the same operator plane
        as the policy reload)."""
        user = check_auth(authorization, x_totp)
        check_access(user, "policies")
        return gateway.reload_tool_schemas()

    @app.post(
        "/api/policies/validate",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def validate_policy(
        req: PolicyUpdateRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "policies")
        return _validate_policy_content(req.content)


def _sim_ref_roots(gateway: RaucleGateway) -> list:
    """Allow roots for caller-supplied simulate file references.

    The references arrive from an HTTP request body, so they are
    confined to the gateway's own policy/data directories plus any
    operator-configured extras (``GatewayConfig.simulate_ref_roots``).
    """
    from pathlib import Path as _Path

    cfg = gateway.config
    roots: set = set()
    roots.update(_Path(r) for r in getattr(cfg, "simulate_ref_roots", ()) if r)
    for attr in (
        "policy_file",
        "receipt_store",
        "audit_chain",
        "registry_path",
        "agent_credentials_file",
    ):
        value = getattr(cfg, attr, "")
        if value:
            roots.add(_Path(value).resolve().parent)
    return sorted(roots, key=str)


def _register_simulate_routes(
    app: FastAPI,
    gateway: RaucleGateway,
    users: UserManager,
    check_access: Any,
) -> None:
    """X6 slice 1: deterministic, signed, flippable policy simulation.

    Operator-plane only: the simulate/apply pair lives behind the admin
    plane's key + role auth. Agent-plane keys (X-Api-Key credentials
    issued by :class:`raucle.agent_credentials.AgentCredentialStore` for
    gate calls) are DENY-BY-DEFAULT here: they authenticate gate
    traffic, never policy control, and the refusal is named
    (``agent_plane_key_denied``) so a leaked agent key probing this
    surface is visible in the audit trail rather than a silent 403.
    """
    from raucle.policy_simulate import SimulateError

    @app.post(
        "/api/policy/simulate",
        responses={
            "400": {"description": "Named simulate refusal (invalid candidate, unknown window)"},
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Agent-plane key or insufficient role"},
        },
    )
    def simulate(
        req: PolicySimulateRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = _check_simulate_plane(gateway, users, authorization, x_totp)
        check_access(user, "policies")
        try:
            from raucle.policy_simulate import simulate_policy

            outcome = simulate_policy(
                gateway,
                candidate_policy_yaml=req.candidate_policy_yaml,
                policy_ref=req.policy_ref,
                window_ref=req.window_ref,
                input_store_ref=req.input_store_ref,
                ref_roots=_sim_ref_roots(gateway),
            )
        except SimulateError as exc:
            raise HTTPException(exc.status_code, f"{exc.reason}: {exc.message}") from exc
        return {
            "result": outcome["result"],
            "receipt_hash": outcome["receipt_hash"],
            "jws": outcome["jws"],
        }

    @app.post(
        "/api/policy/simulate/apply",
        responses={
            "400": {"description": "Named apply refusal (bad receipt, candidate hash mismatch)"},
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Agent-plane key or insufficient role"},
        },
    )
    def simulate_apply(
        req: PolicySimulateApplyRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = _check_simulate_plane(gateway, users, authorization, x_totp)
        check_access(user, "policies")
        try:
            from raucle.policy_simulate import apply_simulated_policy

            return apply_simulated_policy(
                gateway,
                simulation_receipt=req.simulation_receipt,
                candidate_policy_yaml=req.candidate_policy_yaml,
                actor=user.name or user.role,
            )
        except SimulateError as exc:
            raise HTTPException(exc.status_code, f"{exc.reason}: {exc.message}") from exc


def _check_simulate_plane(
    gateway: RaucleGateway,
    users: UserManager,
    authorization: Any,
    x_totp: str | None,
) -> GatewayUser:
    """Deny-by-default agent-plane check, then the standard operator auth.

    A key that verifies against the agent credential store is an
    agent-plane secret: refuse it NAMED before any other check, so it
    can never authenticate (or even be mistaken for) an operator-plane
    caller on the policy simulation surface.
    """
    creds = getattr(gateway, "_agent_creds", None)
    if isinstance(authorization, str) and authorization.startswith(_BEARER_PREFIX):
        presented = authorization[len(_BEARER_PREFIX) :]
    elif isinstance(authorization, str):
        presented = authorization
    else:
        presented = ""
    if presented and creds is not None and creds.verify(presented) is not None:
        raise HTTPException(
            status_code=403,
            detail="agent_plane_key_denied: agent-plane credentials may not call this endpoint",
        )
    return _check_auth(users, authorization, x_totp)


def _register_authority_routes(
    app: FastAPI,
    gateway: RaucleGateway,
    check_auth: Any,
    check_access: Any,
) -> None:
    """Authority attribution endpoints (PR-E): human approval workflow,
    policy change ledger, authority envelopes and the kill switch.

    These are the admin-facing legs of "the authority it held and what
    it could use": every endpoint either records a human decision as a
    signed receipt or serves verifiable evidence.
    """

    @app.get(
        "/api/approvals",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def list_approvals(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "receipts")
        approvals = gateway._approvals.pending()
        return {"count": len(approvals), "approvals": approvals}

    @app.post(
        "/api/approvals/{request_id}/decision",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "404": {"description": "Unknown or expired request"},
            "409": {"description": "Request is not pending"},
        },
    )
    def decide_approval(
        request_id: str,
        req: ApprovalDecisionRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "policies")
        from raucle.approvals import ApprovalError

        try:
            result = gateway.decide_approval(
                request_id,
                approved=req.approved,
                approver=user.name or user.role,
            )
        except ApprovalError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc
        return result

    @app.get(
        "/api/activation-requests",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def list_activation_requests(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """P1.6c: pending policy-activation requests with their blast-radius
        delta summary, so the activate path shows the delta before
        confirmation."""
        user = check_auth(authorization, x_totp)
        check_access(user, "receipts")
        rows = gateway._activations.pending()
        return {"count": len(rows), "activation_requests": rows}

    @app.post(
        "/api/activation-requests/{request_id}/decision",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "404": {"description": "Unknown or expired request"},
            "409": {"description": "Request is not pending"},
        },
    )
    def decide_activation_request(
        request_id: str,
        req: ApprovalDecisionRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Receipted decision on an activation request carrying the delta."""
        user = check_auth(authorization, x_totp)
        check_access(user, "policies")
        from raucle.activation import ActivationError

        try:
            result = gateway.decide_activation(
                request_id,
                approved=req.approved,
                approver=user.name or user.role,
            )
        except ActivationError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc
        return result

    @app.get(
        "/api/policy-ledger",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def policy_ledger(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "receipts")
        entries = gateway.get_policy_ledger()
        integrity = gateway.verify_policy_ledger()
        return {"count": len(entries), "entries": entries, "integrity": integrity}

    @app.get(
        "/api/agents/{agent_id}/authority",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def authority_envelope(
        agent_id: str,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "receipts")
        envelope, jws = gateway.build_authority_envelope(agent_id)
        return {"envelope": envelope, "jws": jws}

    @app.post(
        "/api/agents/{agent_id}/suspend",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def suspend_agent(
        agent_id: str,
        req: SuspendRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        # Admin only: suspending an agent is the kill switch
        check_access(user, "users")
        return gateway.suspend_agent(agent_id, reason=req.reason, actor=user.name or user.role)

    @app.post(
        "/api/revocations",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def revoke_capability(
        req: RevokeRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """A3: revoke a capability and its whole subtree, receipted.

        Receipts v1.2 (lane K3): ``kind``/``reason_class`` pass through
        to the receipted revocation (validated fail-closed by the
        emitter; empty keeps the shipped v1.0 block).
        """
        user = check_auth(authorization, x_totp)
        check_access(user, "users")
        return gateway.revoke_capability(
            req.token_id,
            reason=req.reason,
            actor=user.name or user.role,
            kind=req.kind,
            reason_class=req.reason_class,
        )

    @app.post(
        "/api/agents/{agent_id}/revoke-chains",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def revoke_agent_chains(
        agent_id: str,
        req: SuspendRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """A3 owner-departure: revoke every delegated chain of an identity in
        one receipted operation (the lifecycle audit trail).

        Receipts v1.2 (lane K3): ``kind``/``reason_class`` pass through
        to the receipted revocation (validated fail-closed by the
        emitter; empty keeps the shipped v1.0 block).
        """
        user = check_auth(authorization, x_totp)
        check_access(user, "users")
        return gateway.revoke_agent_chains(
            agent_id,
            reason=req.reason,
            actor=user.name or user.role,
            kind=req.kind,
            reason_class=req.reason_class,
        )


def _line_iat(line: str) -> int | None:
    """Extract the receipt iat from a JSONL envelope line (None if absent)."""
    import base64 as _b64
    import json as _json

    try:
        rec = _json.loads(line)
        parts = rec.get("jws", "").split(".")
        if len(parts) < 2:
            return None
        padded = parts[1] + "=" * ((4 - len(parts[1]) % 4) % 4)
        payload = _json.loads(_b64.urlsafe_b64decode(padded))
        return int(payload.get("iat", 0))
    except Exception:
        return None


def _receipt_page_via_index(
    gateway: RaucleGateway,
    *,
    agent_id: str | None,
    tool: str | None,
    decision: str | None,
    trace_id: str | None,
    since: int | None,
    until: int | None,
    limit: int,
    cursor: str | None,
) -> dict[str, Any]:
    """Receipt query page from the SQLite index (PR-C path)."""
    rows = gateway._receipt_index.query(
        agent_id=agent_id,
        tool=tool,
        decision=decision,
        trace_id=trace_id,
        since=since,
        until=until,
        limit=limit,
        cursor=cursor,
    )
    full_page = len(rows) == max(1, min(limit, 1000))
    return {
        "receipts": rows,
        "count": len(rows),
        "total": gateway._receipt_index.count(),
        "next_cursor": gateway._receipt_index.cursor_for(rows[-1]) if full_page and rows else None,
    }


def _receipt_page_via_store(gateway: RaucleGateway, *, limit: int) -> dict[str, Any]:
    """Receipt query page from the segmented store (no index configured)."""
    recent = gateway._receipt_store.recent(limit=limit)
    return {
        "receipts": recent,
        "count": len(recent),
        "total": gateway._receipt_store.total_receipt_count(),
        "next_cursor": None,
    }


def _receipt_page_via_flat_file(gateway: RaucleGateway, *, limit: int) -> dict[str, Any]:
    """Receipt query page from the legacy flat JSONL file."""
    from raucle._paths import validate_path

    path = validate_path(gateway.config.receipt_store, must_exist=False)
    if not path.exists():
        return {"receipts": [], "count": 0, "total": 0, "next_cursor": None}
    lines = path.read_text(encoding="utf-8").strip().splitlines()
    recent_lines = lines[-limit:] if len(lines) > limit else lines
    receipts = []
    import contextlib

    for line in recent_lines:
        with contextlib.suppress(json.JSONDecodeError):
            receipts.append(json.loads(line))
    return {
        "receipts": receipts,
        "count": len(receipts),
        "total": len(lines),
        "next_cursor": None,
    }


def _envelope_signing_family(jws: str) -> str | None:
    """Read a receipt envelope's actual signing family from its JWS bytes.

    classical Ed25519 vs quantum-ready hybrid: the label is what the real
    signing path wrote. The pq1 profile pins the profile in the header
    ``crit`` set and splits the signature slot into Ed25519 and ML-DSA-65
    halves (raucle/pq). Anything the parser cannot confirm yields None -
    a badge is a claim about signed bytes, so unknown material gets no badge.
    """
    if not isinstance(jws, str) or not jws:
        return None
    parts = jws.split(".")
    if len(parts) == 2 or len(parts) >= 5:
        return None
    import base64 as _b64

    try:
        padded = parts[0] + "=" * ((4 - len(parts[0]) % 4) % 4)
        header = json.loads(_b64.urlsafe_b64decode(padded))
    except Exception:
        return None
    from raucle.pq import header_is_pq1

    if header_is_pq1(header):
        # pq1 receipts come in both slot shapes during the deprecation
        # window: the current 3-segment Compact emission and the legacy
        # 4-segment dot-form receipts.
        return "pq1-hybrid" if len(parts) in (3, 4) else None
    if header.get("alg") == "EdDSA" and len(parts) == 3:
        return "classical-ed25519"
    return None


def _attach_signing_families(gateway: RaucleGateway, page: dict[str, Any]) -> dict[str, Any]:
    """Stamp each receipt row's signing family from its own signed bytes.

    Index rows carry no JWS column, so the family is resolved through the
    envelope store for those; rows whose material cannot be confirmed are
    left without a family (no badge is drawn from unverified bytes).
    """
    for row in page.get("receipts", []):
        family = _envelope_signing_family(row.get("jws", ""))
        if family is None:
            envelope = _find_receipt_envelope(gateway, row.get("receipt_hash", ""))
            if envelope is not None:
                family = _envelope_signing_family(envelope.get("jws", ""))
        row["signing_family"] = family
    return page


def _observed_signing_families(gateway: RaucleGateway, limit: int = 200) -> dict[str, int]:
    """Count signing families over a bounded recent slice of the store."""
    counts = {"classical-ed25519": 0, "pq1-hybrid": 0, "other": 0}
    envelopes: list[dict[str, Any]] = []
    if gateway._receipt_store is not None:
        envelopes = gateway._receipt_store.recent(limit=limit)
    else:
        for path in _export_paths(gateway):
            try:
                with open(path, encoding="utf-8") as fh:
                    envelopes.extend(fh.readlines()[-limit:])
            except OSError:
                continue
    for envelope in envelopes:
        if isinstance(envelope, str):
            import contextlib

            with contextlib.suppress(json.JSONDecodeError):
                envelope = json.loads(envelope)
        family = _envelope_signing_family(envelope.get("jws", ""))
        counts[family or "other"] = counts.get(family or "other", 0) + 1
    return counts


def _register_receipt_routes(
    app: FastAPI, gateway: RaucleGateway, check_auth: Any, check_access: Any
) -> None:
    """Provenance receipt browsing."""

    @app.get(
        "/api/receipts",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def get_receipts(
        limit: int = 50,
        agent_id: str | None = None,
        tool: str | None = None,
        decision: str | None = None,
        trace_id: str | None = None,
        since: int | None = None,
        until: int | None = None,
        cursor: str | None = None,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Query receipts newest-first with filters + cursor pagination.

        Backed by the receipt index when configured (PR-C); falls back to
        the segmented store's bounded-memory recent() when not. No params =
        newest-first, same shape as before.
        """
        return _receipt_page_response(
            gateway,
            check_auth(authorization, x_totp),
            check_access,
            agent_id=agent_id,
            tool=tool,
            decision=decision,
            trace_id=trace_id,
            since=since,
            until=until,
            limit=limit,
            cursor=cursor,
        )

    @app.get(
        "/api/receipts/{receipt_hash}/ancestors",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "501": {"description": "Receipt index not configured"},
        },
    )
    def get_receipt_ancestors(
        receipt_hash: str,
        max_depth: int = 50,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Walk a receipt's full causal ancestry (parents DAG).

        The incident-responder question: everything upstream of this
        decision. Index-backed; cycle-safe; depth-capped.
        """
        user = check_auth(authorization, x_totp)
        check_access(user, "receipts")
        if gateway._receipt_index is None:
            raise HTTPException(
                status_code=501,
                detail="ancestry requires the receipt index (set RAUCLE_RECEIPT_STORE_DIR)",
            )
        _refuse_unready_index(gateway)
        return gateway._receipt_index.ancestry(receipt_hash, max_depth=max_depth)

    @app.get(
        "/api/chains/{receipt_hash}",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "404": {"description": "Unknown receipt hash"},
        },
    )
    def get_chain_graph(
        receipt_hash: str,
        depth: int = 5,
        breadth: int = 200,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Resolve the complete authority graph for one decision receipt.

        Originating authority, delegation hops, the policy binding and
        inline lease/revocation events, bounded by depth/breadth (work
        is capped server-side). Derived only from verified receipt
        links; unverifiable material is an explicit node state, never
        silently resolved.
        """
        return _chain_graph_response(
            gateway,
            check_auth(authorization, x_totp),
            check_access,
            receipt_hash=receipt_hash,
            depth=depth,
            breadth=breadth,
        )

    @app.get(
        "/api/receipts/export",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def export_receipts(
        since: int | None = None,
        until: int | None = None,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> Any:
        """Bulk egress: stream receipts as JSONL for the caller's own data
        platform (C4). The chain of record stays ours; the copy is theirs.

        Streams from the segmented store's segments (bounded memory), or
        the legacy flat file. Bounded to a time range to keep responses
        finite; the audit pack remains the regulator path. A client
        disconnect mid-stream is recorded by the export sink (T-B3).
        """
        user = check_auth(authorization, x_totp)
        check_access(user, "receipts")

        from fastapi.responses import StreamingResponse

        from raucle.export import StreamedExportSink

        sink = StreamedExportSink(source="receipts")
        return StreamingResponse(
            sink.stream(_iter_export_lines(gateway, since=since, until=until)),
            media_type="application/x-ndjson",
            headers={"Content-Disposition": 'attachment; filename="receipts.jsonl"'},
        )

    @app.get(
        "/api/receipts/key-family",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def receipt_key_family(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """The deployment's REAL receipt-signing key family.

        Everything here is read from the live machinery, not a label: the
        configured signer backend, the key id of the key that actually
        signs receipts, the key type of that key material, and the
        signature families observed on the stored receipts (bounded
        recent slice). No cryptographic claims are made: quantum-ready
        hybrid (pq1) receipts only exist where a signing path produced
        them.
        """
        user = check_auth(authorization, x_totp)
        check_access(user, "receipts")
        from cryptography.hazmat.primitives import serialization

        pem = gateway.gate_identity.public_key_pem()
        key = serialization.load_pem_public_key(pem)
        key_family = type(key).__name__
        from raucle.pq import pq_available

        return {
            "signer_backend": gateway.config.signer_backend,
            "key_id": gateway.gate_identity.key_id,
            "issuer_key_type": key_family,
            "pq_available": bool(pq_available()),
            "observed_families": _observed_signing_families(gateway),
        }

    @app.post(
        "/api/receipts/{receipt_hash}/offline-verify",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "404": {"description": "Unknown receipt hash"},
            "422": {"description": "Offline verification failed (verdict returned in detail)"},
            "501": {"description": "Receipt store not configured"},
        },
    )
    def offline_verify_receipt(
        receipt_hash: str,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Verify one receipt with the gateway's REAL offline verifier.

        No network, no operator contact: the receipt's JWS signature is
        checked against the gate identity's public key and the stored
        receipt hash is recomputed from the JWS bytes by
        :class:`raucle.provenance.ProvenanceVerifier` (the same verifier
        an auditor runs on an exported chain). The demo receipts are
        signed with the demo deployment's real key, so the result is the
        real verification result for receipt material the demo itself
        produced (simulated demo traffic).
        """
        return _offline_verify_response(
            gateway, check_auth(authorization, x_totp), check_access, receipt_hash
        )


def _offline_verify_response(
    gateway: RaucleGateway,
    user: GatewayUser,
    check_access: Any,
    receipt_hash: str,
) -> dict[str, Any]:
    """The REAL offline verification of one receipt (single-record chain)."""
    check_access(user, "receipts")
    envelope = _find_receipt_envelope(gateway, receipt_hash)
    if envelope is None:
        raise HTTPException(status_code=404, detail="unknown receipt hash")

    from raucle.provenance import ProvenanceVerifier, _sha256_hex

    gate = gateway.gate_identity
    verifier = ProvenanceVerifier(public_keys={gate.key_id: gate.public_key_pem()})
    # Scope the real verifier to the selected receipt's own envelope
    # line (single-record chain: signature check, hash recomputation
    # and parent resolution on exactly what an auditor carries away).
    import json as _json
    import tempfile as _tempfile
    from pathlib import Path as _Path

    report = None
    with _tempfile.TemporaryDirectory() as td:
        chain_file = _Path(td) / "receipt.jsonl"
        chain_file.write_text(_json.dumps(envelope, ensure_ascii=False) + "\n", encoding="utf-8")
        report = verifier.verify_chain(chain_file)

    receipt_hash_recomputed = "sha256:" + _sha256_hex(envelope.get("jws", "").encode("ascii"))
    verified = bool(report.valid) and receipt_hash_recomputed == receipt_hash
    errors = list(report.errors or [])
    if not verified and not errors:
        errors.append("stored receipt hash does not match a recomputation from the JWS bytes")
    # A failing verdict must fail the response, not just the panel.
    if not verified:
        raise HTTPException(
            status_code=422,
            detail={
                "receipt_hash": receipt_hash,
                "verdict": "failed",
                "signature_check": "failed"
                if report.signature_failures
                else "not checked to completion",
                "hash_linkage": {"recomputed_matches": False},
                "errors": errors[:10],
                "offline": (
                    "This verification ran entirely offline. No operator network call was made."
                ),
                "note": OFFLINE_VERIFY_NOTE,
            },
        )
    return {
        "receipt_hash": receipt_hash,
        "verdict": "verified",
        "signature_check": "ok",
        "hash_linkage": {
            "recomputed_matches": True,
            "recomputed_sha256_prefix": receipt_hash_recomputed[:24],
            "parent_links": 0,
        },
        "receipt_count": report.receipt_count,
        "offline": (
            "Verified without contacting the operator. The signature "
            "and hash checks run locally on the receipt itself."
        ),
        "note": OFFLINE_VERIFY_NOTE,
    }


def _chain_graph_response(
    gateway: RaucleGateway,
    user: GatewayUser,
    check_access: Any,
    *,
    receipt_hash: str,
    depth: int,
    breadth: int,
) -> dict[str, Any]:
    """The full authority graph for one decision receipt."""
    check_access(user, "receipts")
    from raucle.chain_graph import _MAX_BREADTH, _MAX_DEPTH, resolve_chain_graph_for_gateway

    graph = resolve_chain_graph_for_gateway(
        gateway,
        receipt_hash,
        depth=min(max(int(depth), 0), _MAX_DEPTH),
        breadth=min(max(int(breadth), 1), _MAX_BREADTH),
    )
    root_node = graph.get("root")
    if isinstance(root_node, dict) and root_node.get("state") == "unknown":
        raise HTTPException(status_code=404, detail="unknown receipt hash")
    return graph


def _health_payload(gateway: RaucleGateway) -> dict[str, Any]:
    """The shipped liveness contract plus the L1 readiness block (spec
    3.6). Nothing about existing probes changes: ``status`` stays "ok"
    at boot and mid-build; readiness is additive and machine-readable,
    per surface (gate, session continuity, chain scan, receipt index).
    """
    payload: dict[str, Any] = {"status": "ok"}
    readiness = getattr(gateway, "boot_readiness", None)
    if readiness is not None:
        payload["readiness"] = readiness.snapshot()
    return payload


def _refuse_unready_index(gateway: RaucleGateway) -> None:
    """L1 readiness honesty (AC3): an index-backed query surface that is
    not ready refuses with a named, machine-readable error and its
    progress, never an empty 200 that looks complete. Partial answers
    are a named v0.2 extension, gated on the bench numbers."""
    readiness = getattr(gateway, "boot_readiness", None)
    if readiness is None or gateway._receipt_index is None:
        return
    state_block = readiness.snapshot()["receipt_index"]
    state = state_block["state"]
    if state in ("building", "pending"):
        raise HTTPException(
            status_code=503,
            detail={
                "error": "receipt_index_building",
                "state": state,
                "progress": state_block["progress"],
            },
        )
    if state == "refused":
        raise HTTPException(
            status_code=503,
            detail={
                "error": "receipt_index_refused",
                "reason": state_block.get("error", ""),
            },
        )


def _receipt_page_response(
    gateway: RaucleGateway,
    user: GatewayUser,
    check_access: Any,
    *,
    agent_id: str | None,
    tool: str | None,
    decision: str | None,
    trace_id: str | None,
    since: int | None,
    until: int | None,
    limit: int,
    cursor: str | None,
) -> dict[str, Any]:
    """Receipts page: the index projection, or the store/flat-file fallbacks."""
    check_access(user, "receipts")
    _refuse_unready_index(gateway)
    if gateway._receipt_index is not None:
        page = _receipt_page_via_index(
            gateway,
            agent_id=agent_id,
            tool=tool,
            decision=decision,
            trace_id=trace_id,
            since=since,
            until=until,
            limit=limit,
            cursor=cursor,
        )
        return _attach_signing_families(gateway, page)
    if gateway._receipt_store is not None:
        return _attach_signing_families(gateway, _receipt_page_via_store(gateway, limit=limit))
    return _attach_signing_families(gateway, _receipt_page_via_flat_file(gateway, limit=limit))


def _find_receipt_envelope(gateway: RaucleGateway, receipt_hash: str) -> dict[str, Any] | None:
    """Locate one receipt envelope by hash (segmented store or flat file)."""
    if gateway._receipt_store is not None:
        return gateway._receipt_store.find_by_hash(receipt_hash)
    from raucle._paths import validate_path

    path = validate_path(gateway.config.receipt_store, must_exist=False)
    if not path.exists():
        return None
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if rec.get("receipt_hash") == receipt_hash:
                return rec
    return None


def _export_paths(gateway: RaucleGateway) -> list[Path]:
    """The chain files an export reads: segments, or the legacy flat file."""
    if gateway._receipt_store is not None:
        return list(gateway._receipt_store.segments())
    from raucle._paths import validate_path

    path = validate_path(gateway.config.receipt_store, must_exist=False)
    return [path] if path.exists() else []


def _iter_export_lines(gateway: RaucleGateway, *, since: int | None, until: int | None) -> Any:
    """Yield the time-bounded JSONL export one line at a time.

    RED-036: the previous implementation buffered the whole chain in a
    StringIO and sent it as one chunk, so an export of a multi-gigabyte chain
    held it in memory in the gateway process. Malformed lines are skipped:
    egress carries verifiable records only.
    """
    count = 0
    for path in _export_paths(gateway):
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line or not _line_in_range(line, since, until):
                    continue
                count += 1
                yield line + "\n"
    logger.debug("receipt export streamed %d records", count)


def _line_in_range(line: str, since: int | None, until: int | None) -> bool:
    """True when the envelope line's iat falls inside [since, until].
    Unparseable iat passes the filter (the line stays exportable)."""
    iat = _line_iat(line)
    if since is not None and iat is not None and iat < since:
        return False
    return not (until is not None and iat is not None and iat > until)


def _register_siem_routes(
    app: FastAPI, gateway: RaucleGateway, check_auth: Any, check_access: Any
) -> None:
    """SIEM forwarding configuration."""

    @app.get(
        "/api/siem",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def get_siem_config(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "config")
        return {
            "enabled": gateway.siem.enabled,
            "backend": gateway.siem.backend,
            "url": gateway.siem.url,
            "token_configured": bool(gateway.siem.token),
            "buffered_events": len(gateway.siem.buffered_events()),
        }

    @app.put(
        "/api/siem",
        responses={
            "400": {"description": "SIEM URL outside the allowed address space"},
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def update_siem_config(
        req: SIEMConfigRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "config")
        from raucle.gateway import siem_target_allowed

        if req.url and not siem_target_allowed(req.url):
            raise HTTPException(
                400,
                "siem url must be an http(s) destination outside loopback, "
                "link-local and private address space (set RAUCLE_SIEM_ALLOW_PRIVATE=1 "
                "for an internal collector)",
            )
        gateway.config.siem_enabled = req.enabled
        gateway.config.siem_backend = req.backend
        gateway.config.siem_url = req.url
        gateway.config.siem_token = req.token
        gateway.siem.enabled = req.enabled
        gateway.siem.backend = req.backend
        gateway.siem.url = req.url
        gateway.siem.token = req.token
        return {"status": "ok"}


def _register_user_routes(
    app: FastAPI, users: UserManager, check_auth: Any, check_access: Any
) -> None:
    """User management and TOTP MFA administration."""

    @app.get(
        "/api/users",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
        },
    )
    def list_users(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "users")
        return {
            "users": [
                {
                    "user_id": u.user_id,
                    "api_key_label": u.key_label,
                    "role": u.role,
                    "name": u.name,
                    "mfa_enabled": u.mfa_enabled,
                    "expires_at": u.expires_at,
                }
                for u in users.list_users()
            ]
        }

    @app.post(
        "/api/users",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "400": {"description": "Invalid role"},
        },
    )
    def create_user(
        req: UserCreateRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        return _create_user_response(users, check_auth(authorization, x_totp), check_access, req)

    @app.delete(
        "/api/users/{api_key}",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "404": {"description": "User not found"},
        },
    )
    def delete_user(
        api_key: str,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "users")
        if users.remove_user(api_key):
            return {"status": "ok"}
        raise HTTPException(404, "user not found")

    @app.post(
        "/api/users/{api_key}/mfa/setup",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "404": {"description": "User not found"},
        },
    )
    def setup_mfa(
        api_key: str,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Generate a TOTP secret and provisioning URI for a user.

        Returns the secret and otpauth:// URI. The user must scan the
        QR code with their authenticator app and then call /mfa/verify
        with the first 6-digit code to confirm MFA setup.
        """
        user = check_auth(authorization, x_totp)
        check_access(user, "users")
        result = users.setup_mfa(api_key)
        if result is None:
            raise HTTPException(404, "user not found or pyotp not installed")
        return {
            "status": "ok",
            "secret": result["secret"],
            "uri": result["uri"],
            "qr_instructions": "Scan this URI with Google Authenticator, Authy, or 1Password. Then call /mfa/verify with the 6-digit code.",
        }

    @app.post(
        "/api/users/{api_key}/mfa/verify",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "400": {"description": "Invalid or missing code"},
            "404": {"description": "User not found"},
        },
    )
    def verify_mfa_setup(
        api_key: str,
        code: str = "",
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Verify the first TOTP code and enable MFA for the user."""
        return _verify_mfa_response(
            users, check_auth(authorization, x_totp), check_access, api_key, code
        )

    @app.post(
        "/api/users/{api_key}/mfa/disable",
        responses={
            "401": {"description": "MFA required or missing Authorization header"},
            "403": {"description": "Invalid API key or insufficient role"},
            "404": {"description": "User not found"},
        },
    )
    def disable_mfa(
        api_key: str,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Disable MFA for a user. Requires admin role."""
        user = check_auth(authorization, x_totp)
        check_access(user, "users")
        if users.disable_mfa(api_key):
            return {"status": "ok", "mfa_enabled": False}
        raise HTTPException(404, "user not found")


def _create_user_response(
    users: UserManager, user: GatewayUser, check_access: Any, req: UserCreateRequest
) -> dict[str, Any]:
    """Validate and create an admin user; the plaintext key returns once."""
    check_access(user, "users")
    if req.role not in ("admin", "operator", "auditor"):
        raise HTTPException(400, "role must be admin, operator, or auditor")
    supplied = (req.api_key or "").strip()
    if supplied and len(supplied) < _MIN_ADMIN_KEY_CHARS:
        raise HTTPException(
            400,
            f"api_key must be at least {_MIN_ADMIN_KEY_CHARS} characters, "
            "or omit it to have one generated",
        )
    api_key = supplied or ("adm_" + secrets.token_hex(32))
    new_user = users.add_user(api_key, req.role, req.name)
    # The plaintext key is returned exactly once; only its digest is stored.
    return {
        "status": "ok",
        "user_id": new_user.user_id,
        "api_key": api_key,
        "role": new_user.role,
    }


def _verify_mfa_response(
    users: UserManager, user: GatewayUser, check_access: Any, api_key: str, code: str
) -> dict[str, Any]:
    """Verify the first TOTP code and enable MFA (400 on any bad code)."""
    check_access(user, "users")
    if not code:
        raise HTTPException(400, "code parameter is required")
    if users.verify_mfa(api_key, code):
        return {"status": "ok", "mfa_enabled": True}
    raise HTTPException(400, "Invalid TOTP code")


def _no_change_response() -> dict[str, Any]:
    """Response body for a config update with no effective changes."""
    return {
        "status": "ok",
        "changed": [],
        "restart_needed": False,
        "message": "No changes detected",
    }


def _apply_secret_updates(gateway: RaucleGateway, req: ConfigUpdateRequest) -> list[str]:
    """Apply secret fields excluded from update_from_dict. Returns changed names."""
    applied: list[str] = []
    if req.siem_token is not None:
        gateway.config.siem_token = req.siem_token
        gateway.siem.token = req.siem_token
        applied.append("siem_token")
    if req.health_check_token is not None:
        gateway.config.health_check_token = req.health_check_token
        applied.append("health_check_token")
    return applied


def _apply_runtime_siem(gateway: RaucleGateway, changed: list[str]) -> None:
    """Push SIEM fields that can take effect without a restart."""
    siem_fields = {
        "siem_enabled": "enabled",
        "siem_backend": "backend",
        "siem_url": "url",
    }
    for cfg_field, siem_field in siem_fields.items():
        if cfg_field in changed:
            setattr(gateway.siem, siem_field, getattr(gateway.config, cfg_field))


class _SessionLoginRequest(BaseModel):
    """Body for POST /api/session/login (the key+code -> bearer exchange)."""

    api_key: str = Field(..., description="Admin API key (verified once, never stored)")
    totp: str = Field("", description="6-digit TOTP code when MFA is enabled")


class _OIDCCallbackRequest(BaseModel):
    """Body for POST /api/oidc/callback: the provider redirect parameters."""

    code: str = ""
    state: str = ""
    error: str = ""
    error_description: str = ""


# Single-use pending OIDC logins live at most this long before the caller
# must restart the flow (state/nonce/PKCE verifier are all single-use).
_OIDC_PENDING_TTL_SECONDS = 300


def _oidc_login_response(
    oidc_federation: Any, pending_states: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    """Build the provider authorization URL and park the single-use PKCE state."""
    if oidc_federation is None:
        raise HTTPException(503, "OIDC federation is not enabled on this gateway")
    from raucle import admin_oidc

    state = "oidc_" + _hashlib.sha256(secrets.token_bytes(32)).hexdigest()[:32]
    nonce = "n_" + secrets.token_hex(16)
    verifier, challenge = admin_oidc.make_pkce_pair()
    now = time.time()
    stale = [
        s
        for s, rec in pending_states.items()
        if rec["created_at"] + _OIDC_PENDING_TTL_SECONDS < now
    ]
    for s in stale:
        pending_states.pop(s, None)
    pending_states[state] = {
        "nonce": nonce,
        "code_verifier": verifier,
        "created_at": now,
    }
    url = oidc_federation.authorization_url(
        oidc_federation.config.redirect_uri,
        state=state,
        nonce=nonce,
        code_challenge=challenge,
    )
    return {"authorization_url": url, "state": state}


def _oidc_callback_response(
    req: Any,
    oidc_federation: Any,
    pending_states: dict[str, dict[str, Any]],
    users: UserManager,
    sessions: AdminSessionManager,
) -> dict[str, Any]:
    """Code+verifier exchange, subject mapping, receipted session open."""
    if oidc_federation is None:
        raise HTTPException(503, "OIDC federation is not enabled on this gateway")
    if req.error:
        raise HTTPException(401, f"provider refused the login: {req.error}")
    from raucle import admin_oidc

    pending = pending_states.pop(req.state or "", None)
    if pending is None or pending["created_at"] + _OIDC_PENDING_TTL_SECONDS < time.time():
        raise HTTPException(401, f"{admin_oidc.EXCHANGE_ERROR}: unknown or replayed state")
    claims, token_digest = oidc_federation.exchange_code_with_digest(
        req.code,
        pending["code_verifier"],
        redirect_uri=oidc_federation.config.redirect_uri,
        expected_nonce=pending["nonce"],
    )
    user = oidc_federation.map_user(users, claims)
    # X3 slice 2: the sign-in receipt cites the subject and the VERIFIED
    # id-token digest; the token content itself never enters evidence.
    opened = sessions.open_with_user(
        user, subject=claims.get("sub", ""), id_token_digest=token_digest
    )
    return {
        "session_token": opened["token"],
        "expires_at": opened["expires_at"],
        "user_id": user.user_id,
        "subject": claims.get("sub", ""),
        "auth_method": "oidc",
    }


def _register_session_routes(
    app: FastAPI,
    users: UserManager,
    sessions: AdminSessionManager,
    oidc_federation: Any,
) -> None:
    """Admin session lifecycle (T-S3) + optional OIDC federation (X3).

    GET  /api/session/config   - is OIDC enabled; never discloses secrets
    POST /api/session/login    - api key (+TOTP) -> receipted bearer session
    POST /api/session/logout   - closes the presented session, receipted
    GET  /api/oidc/login       - builds provider authorization URL (PKCE)
    POST /api/oidc/callback    - code+verifier exchange, mapping, session
    """
    # state -> {nonce, code_verifier, created_at}; single-use, bounded.
    _pending_oidc: dict[str, dict[str, Any]] = {}

    @app.get("/api/session/config")
    def session_config() -> dict[str, Any]:
        return {
            "oidc_enabled": oidc_federation is not None,
            "provider_issuer": (
                oidc_federation.config.issuer_url if oidc_federation is not None else ""
            ),
            "session_ttl_seconds": sessions._ttl,
        }

    @app.post(
        "/api/session/login",
        responses={
            "401": {"description": "MFA required or bad credentials"},
            "403": {"description": "Invalid API key or TOTP"},
            "503": {"description": "Session limit reached"},
        },
    )
    def session_login(req: _SessionLoginRequest) -> dict[str, Any]:
        try:
            opened = sessions.open_with_key(req.api_key, req.totp or None)
        except SessionAuthError as exc:
            raise HTTPException(exc.status, exc.reason) from exc
        user = opened["user"]
        return {
            "session_token": opened["token"],
            "expires_at": opened["expires_at"],
            "user_id": user.user_id,
            "mfa": user.mfa_enabled,
        }

    @app.post(
        "/api/session/logout",
        responses={
            "401": {"description": "Missing Authorization header"},
            "403": {"description": "Invalid session"},
        },
    )
    def session_logout(authorization: str | None = Header(None)) -> dict[str, Any]:
        if not isinstance(authorization, str):
            raise HTTPException(401, "Missing Authorization header")
        token = authorization
        if token.startswith(_BEARER_PREFIX):
            token = token[len(_BEARER_PREFIX) :]
        if not sessions.close(token):
            raise HTTPException(403, "Invalid or expired session")
        return {"status": "closed"}

    @app.get("/api/oidc/login", responses={"503": {"description": "OIDC not enabled"}})
    def oidc_login() -> dict[str, Any]:
        return _oidc_login_response(oidc_federation, _pending_oidc)

    @app.post(
        "/api/oidc/callback",
        responses={
            "401": {"description": "Provider refused the login or replayed state"},
            "503": {"description": "OIDC not enabled"},
        },
    )
    def oidc_callback(req: _OIDCCallbackRequest) -> dict[str, Any]:
        return _oidc_callback_response(req, oidc_federation, _pending_oidc, users, sessions)


def _apply_config_update(
    gateway: RaucleGateway,
    req: ConfigUpdateRequest,
    updates: dict[str, Any],
    user: Any,
) -> dict[str, Any]:
    """Validate and apply a config update to the running gateway.

    Body of PUT /api/config (after the auth checks and the no-change
    short-circuit): raises HTTPException on validation failures, rolls the
    in-memory config back when an evidence path fails validation, then
    persists to YAML and reports change/restart status.
    """
    touched = [f for f in EVIDENCE_PATH_FIELDS if f in updates]
    if "gate_auth" in updates and updates["gate_auth"] not in ("off", "apikey", "token"):
        raise HTTPException(400, "gate_auth must be one of: off, apikey, token")

    if updates.get("siem_url"):
        from raucle.gateway import siem_target_allowed

        if not siem_target_allowed(updates["siem_url"]):
            raise HTTPException(
                400,
                "siem_url must be an http(s) destination outside loopback, "
                "link-local and private address space (set "
                "RAUCLE_SIEM_ALLOW_PRIVATE=1 for an internal collector)",
            )

    if touched and user.role != "admin":
        raise HTTPException(
            403,
            "moving evidence paths (policy, receipts, audit chain, registries, keys) "
            "requires the admin role",
        )

    snapshot = {f: getattr(gateway.config, f, "") for f in EVIDENCE_PATH_FIELDS}
    changed = gateway.config.update_from_dict(updates)
    errors = _validate_evidence_paths(gateway.config, touched)
    if errors:
        _restore_config_snapshot(gateway, snapshot)
        raise HTTPException(status_code=400, detail={"code": "bad_evidence_path", "errors": errors})
    changed += _apply_secret_updates(gateway, req)

    try:
        gateway.config.save_to_yaml()
    except Exception as exc:
        return {
            "status": "partial",
            "changed": changed,
            "restart_needed": False,
            "warning": f"Config updated in memory but failed to persist: {exc}",
        }

    _apply_runtime_siem(gateway, changed)

    restart_needed = any(
        f in changed for f in ("host", "port", "admin_port", "signer_backend", "kms_key_id")
    )
    return {
        "status": "ok",
        "changed": changed,
        "restart_needed": restart_needed,
        "message": f"Config saved to {gateway.config.config_file}"
        if changed
        else "No changes detected",
    }


def _restore_config_snapshot(gateway: RaucleGateway, snapshot: dict[str, Any]) -> None:
    """Roll back in-memory config fields to their pre-update values.

    Used when a change introduces an invalid evidence path: the mutated
    in-memory config must be left exactly as it was before the request.
    """
    for field, value in snapshot.items():
        setattr(gateway.config, field, value)


def _register_config_routes(
    app: FastAPI, gateway: RaucleGateway, check_auth: Any, check_access: Any
) -> None:
    """Gateway configuration view and update."""

    @app.get("/api/config")
    def get_config(
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        user = check_auth(authorization, x_totp)
        check_access(user, "config")
        c = gateway.config
        return {
            "host": c.host,
            "port": c.port,
            "admin_port": c.admin_port,
            "signer_backend": c.signer_backend,
            "kms_key_id": c.kms_key_id,
            "kms_region": c.kms_region,
            "policy_file": c.policy_file,
            "policy_dir": c.policy_dir,
            "receipt_store": c.receipt_store,
            "audit_chain": c.audit_chain,
            "audit_persist": c.audit_persist,
            "audit_log_file": c.audit_log_file,
            "siem_enabled": c.siem_enabled,
            "siem_backend": c.siem_backend,
            "siem_url": c.siem_url,
            "siem_token_configured": bool(c.siem_token),
            "compliance_framework": c.compliance_framework,
            "registry_path": c.registry_path,
            "gate_auth": c.gate_auth,
            "health_check_token_set": bool(c.health_check_token),
            "config_file": c.config_file,
        }

    @app.put(
        "/api/config",
        responses={
            "400": {"description": "Invalid gate_auth value or bad evidence path"},
            "403": {"description": "Evidence path move requires the admin role"},
        },
    )
    def update_config(
        req: ConfigUpdateRequest,
        authorization: str | None = Header(None),
        x_totp: str | None = Header(None, alias="X-TOTP"),
    ) -> dict[str, Any]:
        """Update gateway configuration. Writes to YAML config file.

        Accepts a JSON body with any GatewayConfig fields (except admin_api_key).
        Changes are applied to the running gateway and persisted to disk.
        Some changes (ports, host, signer) require a restart to take effect.
        """
        user = check_auth(authorization, x_totp)
        check_access(user, "config")

        updates = {k: v for k, v in req.model_dump().items() if v is not None}
        if not updates:
            return _no_change_response()

        return _apply_config_update(gateway, req, updates, user)


def _register_ui_routes(app: FastAPI) -> None:
    """Admin panel and topology HTML pages."""

    @app.get("/", response_class=HTMLResponse)
    def admin_panel() -> str:
        return ADMIN_PANEL_HTML

    @app.get("/topology", response_class=HTMLResponse)
    def topology_view() -> str:
        return TOPOLOGY_HTML

    @app.get("/assets/login-bg.jpg", response_class=None)
    def login_background() -> FileResponse:
        """The engraved artwork behind the demo sign-in card."""
        return FileResponse(Path(__file__).with_name("demo_login_bg.jpg"), media_type="image/jpeg")

    @app.get("/assets/logo-mark.png")
    def logo_mark() -> FileResponse:
        """The engraved brand mark in the panel identity bar."""
        return FileResponse(
            Path(__file__).with_name("assets") / "logo-mark.png", media_type="image/png"
        )

    return app


# ---------------------------------------------------------------------------
# Admin Panel HTML (inline, no build step required)
# ---------------------------------------------------------------------------


ADMIN_PANEL_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Raucle Enterprise console</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
    background: #fff; color: #171717; }
  :root { --rc-navy: #14143C; --rc-blue: #7C8FF0; --rc-blue-deep: #5E6FE0; --rc-blue-line: #DDE2FF;
    --rc-blue-soft: #C9CEF2; --rc-header-h: 52px; --active-green: #22c55e; --border: #e5e7ec; }
  .header { display: flex; align-items: center; justify-content: space-between; gap: 12px;
    padding: 8px 20px; border-bottom: 1px solid #f0f0f0; position: sticky; top: 0; background: #fff; z-index: 40; }
  .header-left { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
  .logo-mark { width: 30px; height: 34px; object-fit: cover; border-radius: 50%; background: #fff;
    border: 1px solid var(--rc-blue-line); display: block; }
  .logo { font-size: 18px; font-weight: 600; letter-spacing: -0.025em; }
  .badge { font-size: 11px; padding: 2px 8px; border-radius: 999px; background: #f5f5f5; color: #737373; font-weight: 500; }
  /* === G9: LEFT SIDE NAVIGATION ============================================= */
  /* Corporate blue from the raucle.com home palette (engraved hero blue and
     deep navy) carries the nav chrome only: never a decision colour. */
  .layout { display: flex; align-items: stretch; }
  /* The navy column is viewport-anchored via a fixed layer: it always spans
     top to screen bottom and never changes height with tab content. */
  .layout::before { content: ""; position: fixed; top: 0; bottom: 0; left: 0; width: 220px; background: var(--rc-navy); }
  .layout > .content { flex: 1; min-width: 0; position: relative; }
  .sidenav { flex: 0 0 220px; width: 220px; position: sticky; top: var(--rc-header-h);
    max-height: calc(100vh - var(--rc-header-h)); overflow-y: auto; overflow-x: hidden;
    scrollbar-width: thin; scrollbar-color: var(--rc-blue-deep) transparent;
    background: transparent;
    border-right: 1px solid var(--rc-blue-deep); padding: 12px 8px 24px; box-sizing: border-box; }
  .nav-heading { font-size: 10px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;
    color: var(--rc-blue); padding: 10px 12px 6px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .nav-group + .nav-group { margin-top: 12px; border-top: 1px solid rgba(124,143,240,0.28); padding-top: 4px; }
  .sidenav .tab { display: block; padding: 7px 12px; cursor: pointer; color: var(--rc-blue-soft);
    font-size: 13.5px; border-radius: 8px; border-left: 3px solid transparent; transition: all 0.15s;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .sidenav .tab:hover { color: #fff; background: rgba(124,143,240,0.10); }
  .sidenav .tab.active { color: #fff; background: rgba(124,143,240,0.18); border-left-color: var(--rc-blue); }
  .sidenav .tab:focus-visible { outline: 2px solid var(--rc-blue); outline-offset: -2px; color: #fff; }
  /* === D14: truth-class badges + the persistent honesty banner ======== */
  .truth-badge { display: inline-block; font-size: 10px; font-weight: 600; letter-spacing: 0.02em;
    padding: 2px 8px; border-radius: 999px; margin-left: 8px; vertical-align: middle; white-space: nowrap; }
  .truth-oss-live { background: #eaf7ee; color: #14532d; border: 1px solid #b7e4c0; }
  .truth-oss-machinery { background: #eef1fd; color: #26317d; border: 1px solid #ccd5f8; }
  .truth-ee-only { background: #fdf3e7; color: #7c4a03; border: 1px solid #f3d9b3; }
  .honesty-banner { display: flex; align-items: center; gap: 10px; margin: 0 0 16px;
    padding: 10px 16px; font-size: 0.82rem; color: #26317d;
    background: #eef1fd; border: 1px solid #ccd5f8; border-radius: 12px; }
  .honesty-banner .honesty-mark { flex: 0 0 auto; width: 8px; height: 8px; border-radius: 50%;
    background: var(--rc-blue); }
  /* === D15: the enterprise overview capability grid =================== */
  .ov-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 12px; }
  .ov-card { border: 1px solid #e5e7ec; border-radius: 12px; padding: 16px;
    display: flex; flex-direction: column; gap: 8px; background: #fff; }
  .ov-title { font-size: 14px; font-weight: 600; color: #171717; }
  .ov-desc { font-size: 0.8rem; color: #525252; line-height: 1.45; flex: 1; }
  .ov-card .btn { align-self: flex-start; padding: 4px 12px; font-size: 11px; }
  #demoBanner { display: none; align-items: center; gap: 10px; flex-wrap: wrap; margin-left: auto;
    padding: 6px 14px; background: #f8f9fb; border: 1px solid #e5e7ec; border-radius: 12px; }
  body.demo #demoBanner { display: flex; }
  .content { max-width: 1400px; margin: 0 auto; padding: 24px; }
  .card { background: #fff; border: 1px solid #f0f0f0; border-radius: 12px; padding: 24px; margin-bottom: 16px; }
  .card-title { font-size: 13px; font-weight: 600; color: #737373; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 16px; }
  .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; }
  .stat { text-align: center; padding: 16px 0; }
  .stat-value { font-size: 36px; font-weight: 700; letter-spacing: -0.03em; }
  .stat-label { font-size: 12px; color: #a3a3a3; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.05em; }
  table { width: 100%; border-collapse: collapse; }
  th { text-align: left; padding: 8px 12px; font-size: 12px; font-weight: 600; color: #a3a3a3; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 1px solid #f0f0f0; }
  td { padding: 10px 12px; font-size: 13px; border-bottom: 1px solid #f7f7f7; }
  tr:hover td { background: #fafafa; }
  .badge-allow { background: #171717; color: #fff; padding: 2px 10px; border-radius: 999px; font-size: 11px; font-weight: 500; }
  .badge-deny { background: #f5f5f5; color: #525252; padding: 2px 10px; border-radius: 999px; font-size: 11px; font-weight: 500; }
  .badge-escalate { background: #f5f5f5; color: #737373; padding: 2px 10px; border-radius: 999px; font-size: 11px; font-weight: 500; border: 1px solid #e5e5e5; }
  .btn { background: #171717; color: #fff; border: none; padding: 8px 20px; border-radius: 999px; cursor: pointer; font-size: 14px; font-weight: 500; }
  .btn:hover { background: #000; }
  .btn-secondary { background: #f5f5f5; color: #171717; }
  .btn-secondary:hover { background: #ebebeb; }
  .input { padding: 8px 14px; background: #fff; border: 1px solid #e5e5e5; border-radius: 999px; font-size: 14px; font-family: inherit; color: #171717; outline: none; }
  .input:focus { border-color: #171717; }
  textarea.input { border-radius: 12px; }
  .editor { width: 100%; height: 400px; background: #fafafa; color: #171717; border: 1px solid #e5e5e5; border-radius: 12px; padding: 16px; font-family: ui-monospace, "SF Mono", Menlo, monospace; font-size: 13px; resize: vertical; }
  .editor:focus { outline: none; border-color: #171717; }
  .actions { display: flex; gap: 8px; margin-top: 16px; }
  .login { max-width: 360px; margin: 80px auto; }
  .login .input { width: 100%; margin-bottom: 12px; }
  .hidden { display: none; }
  pre { background: #fafafa; padding: 16px; border-radius: 12px; border: 1px solid #f0f0f0; overflow-x: auto; font-size: 13px; font-family: ui-monospace, "SF Mono", Menlo, monospace; }
  .toggle { display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 14px; color: #525252; }
  .toggle input { width: 16px; height: 16px; accent-color: #171717; }
  .live-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #22c55e; margin-right: 6px; animation: pulse 2s infinite; }
  @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
  .file-list { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 12px; }
  .file-chip { padding: 4px 12px; border-radius: 999px; background: #f5f5f5; font-size: 12px; color: #525252; cursor: pointer; }
  .file-chip:hover { background: #ebebeb; }
  .file-chip.active { background: #171717; color: #fff; }
  .filter-bar { display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; align-items: center; }
  .dir-toggle { display: inline-flex; background: #f5f5f5; border-radius: 8px; padding: 2px; gap: 2px; }
  .dir-toggle button { border: none; background: transparent; padding: 6px 14px; font-size: 13px; border-radius: 6px; cursor: pointer; color: #737373; font-family: inherit; }
  .dir-toggle button.active { background: #fff; color: #171717; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }

  /* === TRAFFIC FLOW GRAPH (Netbird-style) === */
  .flow-graph { position: relative; min-height: 500px; overflow: hidden; }
  .flow-svg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 1; }
  .flow-cols { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 0; position: relative; z-index: 2; }
  .flow-col { display: flex; flex-direction: column; }
  .flow-col-mid { border-left: 1px solid #f0f0f0; border-right: 1px solid #f0f0f0; background: #fafafa; }
  .flow-col-header { padding: 10px 16px; font-size: 12px; font-weight: 600; color: #737373; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: space-between; }
  .flow-col-header .count { font-size: 11px; color: #a3a3a3; font-weight: 400; }
  .flow-col-filter { padding: 8px 12px; border-bottom: 1px solid #f0f0f0; }
  .flow-col-filter input { width: 100%; font-size: 12px; padding: 6px 10px; border: 1px solid #e5e5e5; border-radius: 8px; }
  .flow-col-body { flex: 1; overflow-y: auto; max-height: 400px; }
  .flow-item { padding: 10px 16px; border-bottom: 1px solid #f7f7f7; cursor: pointer; transition: all 0.15s; position: relative; }
  .flow-item:hover { background: #f5f5f5; }
  .flow-item.active { background: #f0f0f0; border-left: 3px solid #171717; }
  .flow-item.highlighted { background: #f0fdf4; }
  .flow-item-name { font-size: 13px; font-weight: 500; color: #171717; }
  .flow-item-meta { font-size: 11px; color: #a3a3a3; margin-top: 2px; }
  .flow-item-bar { height: 3px; border-radius: 2px; margin-top: 6px; background: #f0f0f0; overflow: hidden; }
  .flow-item-bar-fill { height: 100%; border-radius: 2px; transition: width 0.3s; }
  .flow-item-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; margin-right: 6px; vertical-align: middle; }
  .dot-allow { background: #22c55e; }
  .dot-deny { background: #ef4444; }
  .dot-escalate { background: #f59e0b; }
  .flow-empty { text-align: center; padding: 40px 16px; color: #a3a3a3; font-size: 13px; }
  .protocol-tag { font-size: 10px; padding: 1px 6px; border-radius: 4px; background: #f0f0f0; color: #737373; margin-left: 4px; font-family: ui-monospace, monospace; }

  /* Connection log */
  .conn-table { max-height: 400px; overflow-y: auto; }
  .conn-row { cursor: pointer; }
  .conn-row.selected td { background: #f5f5f5; }

/* ===== Embedded live topology (hero-styled, light) ===== */
.topo-canvas{
  position:relative;width:100%;height:720px;border-radius:10px;overflow:hidden;
  background-color:#f8f9fb;
  background-image:radial-gradient(rgba(17,18,24,0.10) 1px,transparent 1px);
  background-size:24px 24px;
  cursor:grab;user-select:none;
}
.topo-canvas.panning{cursor:grabbing}
.topo-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:1}
.topo-content{position:absolute;top:0;left:0;width:100%;height:100%;z-index:2;transform-origin:0 0}
.topo-node{
  position:absolute;width:190px;padding:10px 12px;border-radius:10px;
  background:#ffffff;border:1px solid #e5e7ec;
  box-shadow:0 2px 10px rgba(17,18,24,0.06);
  cursor:pointer;transition:opacity .25s,box-shadow .2s,border-color .2s,transform .2s;
}
.topo-node:hover{border-color:#171717;transform:translateY(-1px);box-shadow:0 6px 18px rgba(17,18,24,0.10)}
.topo-node.selected{border-color:#22c55e;box-shadow:0 0 0 3px rgba(34,197,94,0.18),0 4px 14px rgba(17,18,24,0.10)}
.topo-node.dimmed{opacity:0.18}
.topo-node-src{border-left:3px solid #171717}
.topo-node-dst{border-left:3px solid #22c55e}
.topo-node-hdr{display:flex;align-items:center;gap:7px;margin-bottom:2px}
.topo-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0;animation:topo-pulse 2s infinite}
.topo-dot.allow{background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,0.7)}
.topo-dot.deny{background:#dd6b78;box-shadow:0 0 6px rgba(221,107,120,0.7)}
.topo-dot.escalate{background:#e5b85c;box-shadow:0 0 6px rgba(229,184,92,0.7)}
@keyframes topo-pulse{0%,100%{opacity:1}50%{opacity:0.45}}
.topo-name{font-size:12px;font-weight:600;color:#171717;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.topo-sub{font-size:10px;color:#8b919e;margin-top:1px;font-family:ui-monospace,monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.topo-badge{display:inline-block;font-size:9px;padding:1px 7px;border-radius:4px;background:#f1f2f4;color:#3a3f4b;margin-top:3px}
/* Hero-style glow loops: drawn around hovered/selected nodes and deny-view nodes */
.topo-loop{pointer-events:none}
/* Topology controls (zoom/fit/fullscreen) */
.topo-controls{position:absolute;top:10px;right:10px;z-index:10;display:flex;gap:2px;background:#fff;border:1px solid #e5e7ec;border-radius:10px;padding:4px;box-shadow:0 2px 10px rgba(17,18,24,0.10)}
.topo-ctrl{width:30px;height:30px;border:none;background:transparent;border-radius:7px;cursor:pointer;font-size:15px;line-height:1;color:#3a3f4b;display:flex;align-items:center;justify-content:center}
.topo-ctrl:hover{background:#f1f2f4}
.topo-ctrl svg{width:15px;height:15px;stroke:#3a3f4b;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
#topoCanvas:fullscreen{height:100vh;border-radius:0;background-color:#f8f9fb}
/* Scenario picker buttons */
.scenario-btn{padding:6px 14px;border-radius:999px;border:1px solid #e5e7ec;background:#fff;font-size:0.78rem;font-weight:600;color:#3a3f4b;cursor:pointer}
.scenario-btn.active{background:#171717;color:#fff;border-color:#171717}
/* Demo mode: the topology jump stays privileged and every edit affordance
   is disabled; the operator-only tabs keep rendering, but as read-only
   demo views served by the /api/demo/* plane. */
body.demo [data-tab-id="topo-link"]{display:none}
body.demo #usersAddCard, body.demo #usersTableCard, body.demo #siemConfigCard, body.demo #configEditCard{display:none}
/* The read-only replacements only ever appear inside demo mode. */
body:not(.demo) #demoUsersCard, body:not(.demo) #demoSiemCard, body:not(.demo) #demoConfigCard, body:not(.demo) #rcptCoverageCard{display:none}
body.demo .btn-primary{display:none}
/* Demo-only screens: hidden outside demo mode */
body:not(.demo) [data-tab-id="dlp"], body:not(.demo) [data-tab-id="injection"], body:not(.demo) [data-tab-id="shadow"]{display:none}
body:not(.demo) [data-tab-id="session"]{display:none}
body:not(.demo) [data-tab-id="capdemo"]{display:none}
body:not(.demo) [data-tab-id="assure"]{display:none}
body:not(.demo) [data-tab-id="stop"], body:not(.demo) #simDemoCard{display:none}
/* G9: the assurance and red nav groups are demo surfaces; live operators
   still reach the receipts key-model card inside the Receipts tab. */
body:not(.demo) .nav-group[data-nav-group="assurance"], body:not(.demo) .nav-group[data-nav-group="red"]{display:none}
body.demo #policyEditorCard{display:none}
.screen-note{margin:0 0 12px;font-size:0.78rem;line-height:1.5;color:#8b919e}
.findings-label{display:inline-block;font-size:0.72rem;font-weight:600;letter-spacing:0.05em;text-transform:uppercase;color:#8b919e;background:#f4f5f7;border:1px solid #e5e7ec;border-radius:6px;padding:2px 8px;margin-bottom:10px}
/* G9 responsive fallback: under ~900px the left nav collapses to a top
   horizontal scroll strip under the sticky header. */
@media (max-width: 900px) {
  .layout { display: block; background: none; }
  .sidenav { background: var(--rc-navy); }
  .sidenav { width: auto; flex: none; top: var(--rc-header-h); height: auto; max-height: none;
    display: flex; flex-direction: row; align-items: stretch; gap: 4px; overflow-x: auto; overflow-y: hidden;
    padding: 8px 12px; border-right: none; border-bottom: 1px solid var(--rc-blue-deep); }
  .nav-group { display: inline-flex; flex-direction: row; align-items: stretch; gap: 4px; }
  .nav-group + .nav-group { margin-top: 0; border-top: none; border-left: 1px solid rgba(124,143,240,0.28); padding-left: 8px; }
  .nav-heading { display: none; }
  .sidenav .tab { display: inline-block; white-space: nowrap; border-radius: 999px; border-left: none; padding: 6px 14px; }
  .sidenav .tab.active { border-left: none; }
  #demoBanner .demo-line { display: none; }
  .header { flex-wrap: wrap; }
  .layout::before { display: none; }
}

/* Guided tour */
#tourHost{position:fixed;inset:0;pointer-events:none;z-index:9000}
.tour-spot{position:absolute;border:2px solid #171717;border-radius:12px;box-shadow:0 0 0 4000px rgba(255,255,255,0.35);pointer-events:none;}
  .tour-card{position:fixed;width:320px;background:#ffffff;background-color:#ffffff;opacity:1;mix-blend-mode:normal;border:1px solid #171717;border-radius:12px;padding:16px 18px 12px;box-shadow:0 12px 40px rgba(0,0,0,0.18);pointer-events:auto;animation:tourIn .25s ease}
@keyframes tourIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.tour-step{font-size:0.68rem;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#8b919e;margin-bottom:8px}
.tour-body{font-size:0.85rem;line-height:1.5;color:#171717;margin-bottom:14px}
.tour-actions{display:flex;justify-content:space-between;align-items:center}
.tour-skip{background:none;border:none;color:#8b919e;font-size:0.75rem;cursor:pointer;padding:6px 4px;font-family:inherit}
.tour-skip:hover{color:#171717}
.tour-next{background:#171717;color:#fff;border:none;border-radius:8px;padding:8px 18px;font-size:0.8rem;font-weight:600;cursor:pointer;font-family:inherit}
.tour-next:hover{background:#3a3a3a}
.tour-dots{display:flex;gap:5px;justify-content:center;margin-top:10px}
.tour-dots span{width:6px;height:6px;border-radius:50%;background:#e0e0e0;display:inline-block}
.tour-dots span.on{background:#171717}
.tour-replay{background:none;border:1px solid var(--border);color:#8b919e;font-size:0.72rem;padding:4px 12px;border-radius:999px;cursor:pointer;font-family:inherit;margin-left:auto}
.tour-replay:hover{border-color:#171717;color:#171717}


  #field { position: fixed; inset: 0; width: 100%; height: 100%; pointer-events: none; z-index: 0; }
  .header, #login, #main { position: relative; z-index: 10; }
  #tourHost { position: fixed; z-index: 9000; }
  body { overflow-x: hidden; }
  .login .card { position: relative; z-index: 2; border-color: #e5e5e5; box-shadow: 0 22px 60px rgba(10,10,10,.10); }
  #loginBackdrop { position: fixed; inset: 0; z-index: 1; pointer-events: none; background: url('assets/login-bg.jpg') 28% center / cover no-repeat; }
  body:has(#login:not(.hidden)) #field { display: none; }
  @media (prefers-reduced-motion: reduce) { #field { display: none; } }
</style>
</head>
<body><canvas id="field" aria-hidden="true" tabindex="-1"></canvas>
<div id="pulseHud" class="hidden" style="position:fixed;top:18px;left:20px;z-index:5;font-family:ui-monospace,'SF Mono',Menlo,monospace;font-size:10px;letter-spacing:.08em;color:#737373"><span id="pulseCount">--</span> GATED/MIN &middot; LIVE</div>
<div class="header">
  <div class="header-left">
    <img src="/assets/logo-mark.png" alt="Raucle" class="logo-mark" width="30" height="34">
    <div class="logo">Raucle</div>
    <span class="badge">Enterprise console</span>
  </div>
  <div id="demoBanner" class="hidden" style="margin:0">
    <span style="display:inline-flex;align-items:center;gap:6px;font-size:0.78rem;font-weight:600;color:#fff;background:#22c55e;padding:3px 10px;border-radius:999px">
      <span style="width:6px;height:6px;border-radius:50%;background:#fff;display:inline-block"></span>
      DEMO MODE
    </span>
    <span class="demo-line" style="font-size:0.80rem;color:#3a3f4b">Read-only view of a live deployment with simulated agent traffic.</span>
    <button class="tour-replay" style="margin-left:0" data-hi="tourRestart()">Replay tour</button>
    <div id="scenarioPicker" style="display:flex;gap:8px"></div>
    <button class="btn" style="padding:6px 14px;font-size:0.8rem" data-hi="reloadPage()">Exit Demo</button>
  </div>
</div>

<div id="login" class="content login">
  <div id="loginBackdrop" aria-hidden="true"></div>
  <div class="card">
    <div class="card-title">Sign In</div>
    <input class="input" id="apiKey" type="password" placeholder="API Key">
    <div id="totpRow" class="hidden" style="margin-top:12px">
      <input class="input" id="totpInput" placeholder="6-digit TOTP code" maxlength="6" style="width:100%">
      <button class="btn" style="width:100%;margin-top:8px" data-hi="loginWithTotp()">Verify & Sign In</button>
    </div>
    <button class="btn" style="width:100%;margin-top:12px" data-hi="login()">Sign In</button>
    <button class="btn btn-secondary hidden" style="width:100%;margin-top:12px" id="ssoLoginBtn" data-hi="ssoLogin()">Sign in with SSO</button>
    <div style="text-align:center;margin:16px 0 8px;color:#737373;font-size:0.8rem">or</div>
    <button class="btn" style="width:100%;background:#171717;color:#fff" id="enterDemoBtn" data-hi="enterDemo()">View Demo</button>
    <div style="margin-top:10px;font-size:0.75rem;color:#737373;text-align:center">
      Read-only demonstration across banking, government, health and capability scenarios.
    </div>
  </div>
</div>

<div id="main" class="hidden">
  <div id="tourHost"></div>
  <div id="honestyBanner" class="honesty-banner" role="note"><span class="honesty-mark" aria-hidden="true"></span><span>This demo shows the Enterprise Edition operator surface. Enforcement, receipts and verification run on the Apache-2.0 open-source raucle gateway beneath it. EE-only surfaces are labelled.</span></div>
  <div class="layout">
  <nav class="sidenav" id="sidenav" aria-label="Panel sections">
    <div class="nav-group" data-nav-group="trust">
      <div class="nav-heading">Raucle Agent Trust</div>
      <div class="tab active" tabindex="0" data-hi="showTab('dashboard',this)">Dashboard</div>
      <div class="tab" tabindex="0" data-hi="showTab('connections',this)">Connections</div>
      <div class="tab" tabindex="0" data-hi="showTab('policies',this)" data-tab-id="policies">Policies</div>
      <div class="tab" tabindex="0" data-hi="showTab('simulate',this)" data-tab-id="simulate">Policy simulate</div>
      <div class="tab" tabindex="0" data-hi="showTab('capdemo',this)" data-tab-id="capdemo">Capability tokens</div>
      <div class="tab" tabindex="0" data-hi="showTab('receipts',this)">Receipts</div>
      <div class="tab" tabindex="0" data-hi="showTab('learn',this)" data-tab-id="learn">Learn</div>
      <div class="tab" tabindex="0" data-hi="showTab('siem',this)" data-tab-id="siem">SIEM</div>
      <div class="tab" tabindex="0" data-hi="showTab('users',this)" data-tab-id="users">Users</div>
      <div class="tab" tabindex="0" data-hi="showTab('config',this)" data-tab-id="config">Config</div>
      <div class="tab" tabindex="0" data-hi="gotoTopology()" data-tab-id="topo-link" style="color:var(--active-green)">Topology</div>
    </div>
    <div class="nav-group" data-nav-group="assurance">
      <div class="nav-heading">Raucle Agent Assurance</div>
      <div class="tab" tabindex="0" data-hi="showTab('dlp',this)" data-tab-id="dlp">Data Protection</div>
      <div class="tab" tabindex="0" data-hi="showTab('injection',this)" data-tab-id="injection">Prompt Injection</div>
      <div class="tab" tabindex="0" data-hi="showTab('session',this)" data-tab-id="session">Session behaviour</div>
      <div class="tab" tabindex="0" data-hi="showTab('shadow',this)" data-tab-id="shadow">Shadow AI</div>
      <div class="tab" tabindex="0" data-hi="showTab('mcp',this)" data-tab-id="mcp">MCP Scanner</div>
      <div class="tab" tabindex="0" data-hi="showTab('assure',this)" data-tab-id="assure">Cross-org proof</div>
      <div class="tab" tabindex="0" data-hi="navEvidencePack()" data-tab-id="evidence">Evidence pack</div>
      <div class="tab" tabindex="0" data-hi="navKeyModel()" data-tab-id="keymodel">Key model</div>
      <div class="tab" tabindex="0" data-hi="navCoverage()" data-tab-id="coverage">Coverage</div>
    </div>
    <div class="nav-group" data-nav-group="red">
      <div class="nav-heading">Raucle Agent Red</div>
      <div class="tab" tabindex="0" data-hi="showTab('stop',this)" data-tab-id="stop">Emergency authority stop</div>
    </div>
  </nav>
  <div class="content">

    <div id="tab-dashboard" data-truth-class="OSS LIVE">
      <div class="card"><div class="card-title">Gate Decisions</div>
        <div class="stats-grid" id="statsGrid"></div>
      </div>
      <div class="card" id="enterpriseOverview"><div class="card-title">Enterprise overview <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span></div>
        <p class="screen-note">This console is the Enterprise Edition operator surface drawn over the open-source raucle gateway. Every card names its capability, its truth class, and opens the screen that demonstrates it. The cards describe; the screens demonstrate.</p>
        <div class="ov-grid" id="overviewGrid">
          <div class="ov-card" data-truth-class="OSS LIVE">
            <div class="ov-title">Decision receipts + offline verify</div>
            <div class="ov-desc">Every gate decision leaves a signed, content-addressed receipt; the offline verifier re-checks signatures and hash linkage on your machine with no operator contact.</div>
            <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span>
            <button class="btn btn-secondary" data-hi="showTab('receipts',this)">Open Receipts</button>
          </div>
          <div class="ov-card" data-truth-class="OSS LIVE">
            <div class="ov-title">Coverage: receipted share</div>
            <div class="ov-desc">The receipted_share metric computed over this gateway's own receipt stream, with the buckets the assurance service serves cross-vantage.</div>
            <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span>
            <button class="btn btn-secondary" data-hi="navCoverage()">Open Coverage</button>
          </div>
          <div class="ov-card" data-truth-class="OSS LIVE">
            <div class="ov-title">Session behavioural rules</div>
            <div class="ov-desc">Deterministic, deny-only session rules over live session windows; every catch is a signed session-monitor finding citing the gate receipt it cut off.</div>
            <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span>
            <button class="btn btn-secondary" data-hi="showTab('session',this)">Open Session behaviour</button>
          </div>
          <div class="ov-card" data-truth-class="OSS LIVE">
            <div class="ov-title">Capability tokens + PQ receipts</div>
            <div class="ov-desc">The real capability issuer mints attenuated tokens live, and receipts can carry post-quantum hybrid signing under the enrolled key model.</div>
            <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span>
            <button class="btn btn-secondary" data-hi="showTab('capdemo',this)">Open Capability tokens</button>
          </div>
          <div class="ov-card" data-truth-class="OSS LIVE">
            <div class="ov-title">Data loss prevention</div>
            <div class="ov-desc">The advisory redaction engine collars sensitive spans in live demo tool calls, and every scan lands as a signed x_dlp receipt citing the gate receipt for the call. Digests and counts only, never content.</div>
            <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span>
            <button class="btn btn-secondary" data-hi="showTab('dlp',this)">Open Data Protection</button>
          </div>
          <div class="ov-card" data-truth-class="OSS MACHINERY + EE VIEW">
            <div class="ov-title">Prompt injection detection</div>
            <div class="ov-desc">The heuristic classifier scores demo traffic in the gate's own decision bands. The EE classifier surface is simulated, labelled as such.</div>
            <span class="truth-badge truth-oss-machinery" data-truth="OSS MACHINERY + EE VIEW">OSS MACHINERY + EE VIEW</span>
            <button class="btn btn-secondary" data-hi="showTab('injection',this)">Open Prompt Injection</button>
          </div>
          <div class="ov-card" data-truth-class="OSS LIVE">
            <div class="ov-title">AI gateway</div>
            <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span>
            <div class="ov-desc">Live tool-call gating: every agent call hits the gate before execution, with connection views and live topology.</div>
            <button class="btn btn-secondary" data-hi="showTab('connections',this)">Open AI gateway</button>
          </div>
          <div class="ov-card" data-truth-class="OSS LIVE">
            <div class="ov-title">Policy editor + simulate</div>
            <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span>
            <div class="ov-desc">Inspect and edit policies, then simulate a change deterministically before deploy: the proof-status engine shows PROVEN, REFUTED or UNDECIDED per rule.</div>
            <button class="btn btn-secondary" data-hi="showTab('policies',this)">Open Policy editor</button>
          </div>
          <div class="ov-card" data-truth-class="OSS LIVE">
            <div class="ov-title">Compliance: EU AI Act pack</div>
            <div class="ov-desc">The assurance packet builder produces a sha-pinned evidence pack from this deployment's receipt chain; EU AI Act crosswalk rows map to the framework and never claim conformance.</div>
            <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span>
            <button class="btn btn-secondary" data-hi="navEvidencePack()">Open Evidence pack</button>
          </div>
          <div class="ov-card" data-truth-class="EE-ONLY">
            <div class="ov-title">Fleet + SIEM targets</div>
            <div class="ov-desc">Multi-organisation fleet views and SIEM target management are Enterprise Edition surfaces. This demo shows their shape with simulated data, labelled as such.</div>
            <span class="truth-badge truth-ee-only" data-truth="EE-ONLY">EE-ONLY</span>
            <button class="btn btn-secondary" data-hi="showTab('siem',this)">Open SIEM</button>
          </div>
          <div class="ov-card" data-truth-class="OSS LIVE">
            <div class="ov-title">Kill switch: operator stop</div>
            <div class="ov-desc">The receipted emergency authority stop story: M-of-N quorum approvals, signed transitions, byte-exact resume, produced by the real containment machinery.</div>
            <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span>
            <button class="btn btn-secondary" data-hi="showTab('stop',this)">Open Emergency authority stop</button>
          </div>
          <div class="ov-card" data-truth-class="OSS LIVE">
            <div class="ov-title">MCP tool scanner</div>
            <div class="ov-desc">The real static analysis engine runs live over seeded or pasted manifests: prompt injection, hidden instructions, planted keys, rug-pull wording and SSRF targets. Findings carry severity, location and evidence class, never payload text. Agent Red tradecraft is closed-core and not part of this demo.</div>
            <span class="truth-badge truth-oss-live" data-truth="OSS LIVE">OSS LIVE</span>
            <button class="btn btn-secondary" data-hi="showTab('mcp',this)">Open MCP Scanner</button>
          </div>
          <div class="ov-card" data-truth-class="OSS MACHINERY + EE VIEW">
            <div class="ov-title">Shadow AI discovery</div>
            <div class="ov-desc">Attempts to reach unapproved model suppliers, checked by the gateway shadow-AI path over simulated demo traffic; the discovery sensors are an EE surface and are labelled as such.</div>
            <span class="truth-badge truth-oss-machinery" data-truth="OSS MACHINERY + EE VIEW">OSS MACHINERY + EE VIEW</span>
            <button class="btn btn-secondary" data-hi="showTab('shadow',this)">Open Shadow AI</button>
          </div>
        </div>
      </div>
      <div class="card"><div class="card-title">By Tool</div>
        <table><thead><tr><th>Tool</th><th>Allowed</th><th>Denied</th><th>Escalated</th></tr></thead>
        <tbody id="toolTableBody"></tbody></table>
      </div>
    </div>

    <div id="tab-dlp" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card"><div class="card-title"><span class="live-dot"></span>Data Protection</div>
        <span class="findings-label">OSS LIVE - the advisory redaction engine over live demo traffic</span>
        <p class="screen-note">Every demo tool call is screened by the OSS advisory redaction engine: matched spans are collared with [REDACTED:class] markers, and every scan with a match lands as a signed x_dlp receipt citing the gate receipt for that call. The values are never shown: each row pairs the original content digest with the redacted digest, alongside bounded pattern classes and span counts only. The demo agents generate the canned patterns themselves (a test card number, a reserved-domain email, an example national id, an obviously-demo bearer token); nothing here is customer data.</p>
        <div class="stats-grid" id="dlpSummary"></div>
        <div class="ov-grid" style="margin-bottom:12px">
          <div class="ov-card" id="dlpFindingsCard"><div class="ov-title">Collared spans by pattern class</div><p class="screen-note" id="dlpFindingsBody" style="margin-top:8px"></p></div>
        </div>
        <table><thead><tr><th>Scan</th><th>Route</th><th>Classes (spans)</th><th>Action</th><th>Rule</th><th>Content digest</th><th>Redacted digest</th><th>Cited receipt</th><th>Receipt</th></tr></thead>
        <tbody id="dlpTableBody"></tbody></table>
        <p class="screen-note">Honest limits: the advisory engine wires a declared subset of the x_dlp vocabulary (pii_card, pii_email, pii_national_id, secret_bearer); pci_pan is deliberately not wired, because issuer-aware PAN heuristics belong to the enterprise scanner. The action is always redacted in this demo: block classes belong to the enterprise runtime and are never claimed here. The demo scan runs only when demo mode is on; production gate traffic is never content-scanned by the gateway.</p>
      </div>
    </div>

    <div id="tab-injection" data-truth-class="OSS MACHINERY + EE VIEW" class="hidden"><span class="truth-badge" data-truth="OSS MACHINERY + EE VIEW">OSS MACHINERY + EE VIEW</span>
      <div class="card"><div class="card-title"><span class="live-dot"></span>Prompt Injection</div>
        <span class="findings-label">Simulated demo traffic</span>
        <p class="screen-note">Injected payloads inside the simulated tool outputs and agent text, scored live by the heuristic classifier (with the machine learning classifier when it is active) in the same decision bands the gate uses. Each event shows its score, category, and the receipted decision with its reason.</p>
        <div class="stats-grid" id="injSummary"></div>
        <table><thead><tr><th>Agent</th><th>Tool</th><th>Where</th><th>Score</th><th>Category</th><th>Decision</th><th>Reason</th></tr></thead>
        <tbody id="injTableBody"></tbody></table>
      </div>
    </div>

        <div id="tab-session" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card"><div class="card-title"><span class="live-dot"></span>Session behaviour</div>
        <span class="findings-label">OSS LIVE - real windows, real findings</span>
        <p class="screen-note">Deterministic session rules enforced by the gateway over tool-call sequences (Q1). Calls that declare a session id are bound to signed receipts; this tab reads the live demo gateway state. Honest limits printed below.</p>
        <div class="ov-grid" style="margin-bottom:12px">
          <div class="ov-card" id="sessionRulesCard"><div class="ov-title">Shipped session rules</div><p class="screen-note" id="sessionRulesBody" style="margin-top:8px"></p></div>
          <div class="ov-card" id="sessionWindowsCard"><div class="ov-title">Live session windows</div><p class="screen-note" id="sessionWindowsBody" style="margin-top:8px"></p></div>
          <div class="ov-card" id="sessionFindingsCard"><div class="ov-title">Session-monitor findings</div><p class="screen-note" id="sessionFindingsBody" style="margin-top:8px"></p><button class="btn btn-secondary" data-hi="sessionFindingVerify(event)">Verify offline</button></div>
        </div>
        <p class="screen-note">Honest limits: deny-only in v1, a session rule can refuse a call and never widen authority. Window state is process memory, rebuilt from the receipt index on boot within the configured TTL. Replayed rows lack destination_class, so gradual_extraction can undercount after a restart: it never fabricates a deny. Coverage exists only where the caller declares a session id.</p>
      </div>
    </div>

    <div id="tab-shadow" data-truth-class="OSS MACHINERY + EE VIEW" class="hidden"><span class="truth-badge" data-truth="OSS MACHINERY + EE VIEW">OSS MACHINERY + EE VIEW</span>
      <div class="card"><div class="card-title"><span class="live-dot"></span>Shadow AI</div>
        <span class="findings-label">Simulated demo traffic</span>
        <p class="screen-note">Attempts by simulated agents to reach unapproved model suppliers: unknown model headers, endpoints outside the approved egress list, and bring-your-own-key attempts. Each finding is checked against the scenario's approved supplier policy by the gateway's shadow-AI detection path, with the policy response recorded.</p>
        <div class="stats-grid" id="shadowSummary"></div>
        <table><thead><tr><th>Agent</th><th>Tool</th><th>Finding</th><th>Detail</th><th>Policy response</th></tr></thead>
        <tbody id="shadowTableBody"></tbody></table>
      </div>
    </div>

    <!-- CAPABILITY TOKENS - real issuer minted, real gate verified (E1) -->
    <div id="tab-capdemo" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card"><div class="card-title">Capability tokens</div>
        <span class="findings-label">Simulated capability chains</span>
        <p class="screen-note">Pick a simulated capability call: the envelope below is minted live by the gateway's own capability issuer, and every verify verdict is the real capability gate deciding the call. Nothing here delegates or enforces beyond this screen.</p>
        <div class="file-list" id="capDemoList"></div>
        <pre id="capEnvelopeView" style="font-size:11px;max-height:340px;overflow:auto"></pre>
        <div class="actions">
          <button class="btn" id="capVerifyBtn" data-hi="capDemoVerify()">Verify against the real gate</button>
          <span style="font-size:0.75rem;color:#a3a3a3;align-self:center">Read-only: minting and verifying run in memory and change nothing.</span>
        </div>
      </div>
    </div>

    <!-- CONNECTIONS - Netbird-style flow graph -->
    <div id="tab-connections" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card">
        <div class="card-title"><span class="live-dot"></span>Live Topology</div>
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:10px">
          <select class="input" id="topoDecisionFilter" style="width:auto">
            <option value="">All Decisions</option>
            <option value="allow">Allow</option>
            <option value="deny">Deny</option>
            <option value="escalate">Escalate</option>
          </select>
          <label class="toggle"><input type="checkbox" id="topoMotion" checked> Animated traffic</label>
          <span style="flex:1"></span>
          <span style="font-size:0.75rem;color:#8b919e">Zoomed to the busiest nodes at first. Drag to pan, scroll to zoom, click a node to filter the table below.</span>
        </div>
        <div id="topoCanvas" class="topo-canvas">
          <svg class="topo-svg" id="topoSvg"></svg>
          <div class="topo-content" id="topoContent"></div>
          <div class="topo-controls">
            <button class="topo-ctrl" title="Zoom in" data-hi="topoZoomIn()">
              <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><line x1="16.5" y1="16.5" x2="21" y2="21"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
            </button>
            <button class="topo-ctrl" title="Zoom out" data-hi="topoZoomOut()">
              <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><line x1="16.5" y1="16.5" x2="21" y2="21"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
            </button>
            <button class="topo-ctrl" title="Fit to view" data-hi="topoFit()">
              <svg viewBox="0 0 24 24"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M16 3h3a2 2 0 0 1 2 2v3"/><path d="M8 21H5a2 2 0 0 1-2-2v-3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>
            </button>
            <button class="topo-ctrl" title="Fullscreen" data-hi="topoFullscreen()">
              <svg viewBox="0 0 24 24" id="topoFsIcon"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M16 3h3a2 2 0 0 1 2 2v3"/><path d="M8 21H5a2 2 0 0 1-2-2v-3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/><line x1="3" y1="3" x2="21" y2="21"/></svg>
            </button>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-title"><span class="live-dot"></span>Traffic Flow</div>
        <div class="filter-bar">
          <div class="dir-toggle">
            <button class="active" data-hi="setDirFilter('all',this)">All</button>
            <button data-hi="setDirFilter('inbound',this)">Inbound</button>
            <button data-hi="setDirFilter('outbound',this)">Outbound</button>
          </div>
          <select class="input" id="filterDecision">
            <option value="">All Decisions</option>
            <option value="allow">Allow</option>
            <option value="deny">Deny</option>
            <option value="escalate">Escalate</option>
          </select>
          <button class="btn btn-secondary" data-hi="demoExample()">Show example</button>
          <button class="btn btn-secondary" data-hi="loadRecent()">Load recent</button>
          <label class="toggle"><input type="checkbox" id="liveMode"> Live (off by default)</label>
        </div>
        <div class="card" id="connPathCard" style="margin:14px 0 0">
          <div class="card-title">Request path &middot; live <span class="count" id="pathCount"></span></div>
          <div id="pathPills" style="display:flex;gap:6px;margin:10px 0;flex-wrap:wrap">
            <button class="btn btn-secondary active" data-hi="setDecisionFilter('all',this)">All</button>
            <button class="btn btn-secondary" data-hi="setDecisionFilter('allow',this)">Approved</button>
            <button class="btn btn-secondary" data-hi="setDecisionFilter('deny',this)">Denied</button>
            <button class="btn btn-secondary" data-hi="setDecisionFilter('escalate',this)">Escalated</button>
          </div>
          <div id="connPath"></div>
        </div>
        <div class="flow-graph" id="flowGraph">
          <svg class="flow-svg" id="flowSvg"></svg>
          <div class="flow-cols">
            <div class="flow-col">
              <div class="flow-col-header">Inbound Sources <span class="count" id="srcCount">0</span></div>
              <div class="flow-col-filter"><input id="srcFilter" placeholder="Filter sources..."></div>
              <div class="flow-col-body" id="srcList"></div>
            </div>
            <div class="flow-col flow-col-mid">
              <div class="flow-col-header">Gate Processing <span class="count" id="midCount">0</span></div>
              <div class="flow-col-filter"><input id="midFilter" placeholder="Filter by tool..."></div>
              <div class="flow-col-body" id="midList"></div>
            </div>
            <div class="flow-col">
              <div class="flow-col-header">Outbound Destinations <span class="count" id="dstCount">0</span></div>
              <div class="flow-col-filter"><input id="dstFilter" placeholder="Filter destinations..."></div>
              <div class="flow-col-body" id="dstList"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-title">Connection Log</div>
        <div class="conn-table">
          <table><thead><tr><th>Time</th><th>Source</th><th>Tool</th><th>Policy</th><th>Decision</th><th>Destination</th><th>Reason</th><th>Latency</th></tr></thead>
          <tbody id="connBody"></tbody></table>
        </div>
      </div>
    </div>

    <div id="tab-policies" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card hidden" id="simDemoCard"><div class="card-title"><span class="live-dot"></span>Test a change before you deploy</div>
        <span class="findings-label">Simulated demo window</span>
        <p class="screen-note">Pick a demo policy tweak and the panel runs the gateway's real policy simulation over a simulated served-traffic window: the outcome is deterministic and the receipt below it is the real signed machine output. In a live deployment the operator deploys a validated change through the editor's Save &amp; Deploy path, which re-verifies the signed receipt before anything lands.</p>
        <div class="file-list" id="simPresetList"></div>
        <div class="actions">
          <button class="btn" data-hi="simRun()">Run simulation</button>
          <span style="font-size:0.75rem;color:#a3a3a3;align-self:center">Read-only: simulation has no side effects; nothing is applied.</span>
        </div>
        <div id="simOutcome" class="screen-note" style="margin-top:12px"></div>
        <table class="hidden" id="simChangesTable"><thead><tr><th>Tool</th><th>Agent</th><th>Current decision</th><th>Candidate decision</th><th>Evidence depth</th></tr></thead>
        <tbody id="simChangesBody"></tbody></table>
        <div id="simReceipt" style="font-family:ui-monospace,monospace;font-size:11px;color:#737373;word-break:break-all;margin-top:8px"></div>
      </div>
      <div class="card" id="policyEditorCard"><div class="card-title">Policy Files</div>
        <div class="file-list" id="fileList"></div>
        <textarea class="editor" id="policyEditor"></textarea>
        <div class="actions"><button class="btn" data-hi="validatePolicy()">Validate</button><button class="btn" data-hi="savePolicy()">Save & Deploy</button><button class="btn btn-secondary" data-hi="reloadPolicy()">Reload</button></div>
      </div>
    </div>
    <div id="tab-simulate" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card" id="simTabCard"><div class="card-title"><span class="live-dot"></span>Policy simulate: test a change before you deploy</div>
        <span class="findings-label">Deterministic, signed, flippable</span>
        <p class="screen-note">The operator question this screen answers: what would THIS candidate policy have done to the traffic we actually served? Pick a preset tweak and the real simulate engine replays a simulated served window; paste a candidate policy YAML and name the historical window, and it replays every recorded decision from this deployment's own store. Either way the outcome is deterministic and signed: what the candidate would have allowed and denied, and every decision that flips. The rows below stay bounded to tools, agents, decisions and hashes: never argument values, never denial reasons. The signed receipt binds the candidate policy and the window by hash. This screen applies nothing; deploying a validated change is the policy editor's Save &amp; Deploy path, which re-verifies the signed receipt before anything lands. The paste path needs an operator key: the demo key holds the auditor role, and the refusal it gets is named below, not hidden.</p>
        <div style="font-size:0.75rem;color:#a3a3a3;margin-bottom:8px">Choose a preset tweak, or paste a candidate policy YAML. Pasting simulates over this deployment's own recorded window; picking a preset runs the same real engine over the simulated window.</div>
        <div class="file-list" id="simTabPresetList"></div>
        <textarea class="editor" id="simTabCandidate" style="height:180px" spellcheck="false" placeholder="candidate policy YAML"></textarea>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;max-width:560px">
          <input class="input" id="simTabWindow" placeholder="window: receipt-chain JSONL path (operator, optional)">
          <input class="input" id="simTabStore" placeholder="input store JSONL path (operator, optional)">
        </div>
        <div class="actions">
          <button class="btn" data-hi="simTabRun()">Run simulation</button>
          <button class="btn btn-secondary" data-hi="simTabClear()">Clear</button>
          <span style="font-size:0.75rem;color:#a3a3a3;align-self:center">Read-only: one run at a time; pasted policies over 256 KiB are refused.</span>
        </div>
      </div>
      <div class="card" id="simTabResultCard" style="margin-top:14px"><div class="card-title">Simulation outcome</div>
        <div id="simTabSummary" class="screen-note">No simulation yet: choose a preset tweak or paste a candidate policy, then run. The outcome renders here.</div>
        <table class="hidden" id="simTabChangesTable"><thead><tr><th>Tool</th><th>Agent</th><th>Current</th><th>Candidate</th><th>Evidence depth</th><th>Receipt</th></tr></thead>
        <tbody id="simTabChangesBody"></tbody></table>
        <div id="simTabHashes" style="font-family:ui-monospace,monospace;font-size:11px;color:#737373;word-break:break-all;margin-top:8px"></div>
      </div>
    </div>
    <div id="tab-stop" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card">
        <div class="card-title"><span class="live-dot"></span>Emergency authority stop — the operator story</div>
        <span class="findings-label">Simulated containment state</span>
        <p class="screen-note">This is a display surface for the control operators hold in a live deployment: the stop ships OFF per deployment, arming it is itself a signed receipted transition, a global stop needs the M-of-N quorum of distinct approval receipts before the policy swap happens, and resume restores the exact pre-stop bytes. Every receipt below was produced in a disposable sandbox by the real containment machinery; this screen cannot arm, hold or resume anything.</p>
        <div id="stopQuorum" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px"></div>
        <table><thead><tr><th>Transition</th><th>Receipt verdict</th><th>Actor / operator</th><th>Reason</th><th>Receipt</th></tr></thead>
        <tbody id="stopStoryBody"></tbody></table>
      </div>
      <div class="card">
        <div class="card-title">Receipted transitions, in order</div>
        <table><thead><tr><th>Scope</th><th>Verdict</th><th>Approvers</th><th>Quorum</th></tr></thead>
        <tbody id="stopReceiptsBody"></tbody></table>
      </div>
    </div>
    <div id="tab-assure" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card">
        <div class="card-title">Cross-organisation receipt verification</div>
        <span class="findings-label">Simulated two-organisation story</span>
        <p class="screen-note">Organisation B verifies receipts that Organisation A issued, using only the public key Organisation A publishes. No contact is made with the issuing operator at any point: the verifier checks the Ed25519 signature against the pinned external key with the real offline verifier, and recomputes the receipt hash from the receipt bytes. A receipt offered under any other key is refused. Everything here was produced fresh by the real verification machinery in a disposable sandbox.</p>
        <pre id="crossOrgView" style="font-size:11px;max-height:340px;overflow:auto;background:#f8f9fb;border:1px solid #e5e7ec;border-radius:10px;padding:14px"></pre>
      </div>
      <div class="card" style="margin-top:14px">
        <div class="card-title">Conformance without disclosure</div>
        <span class="findings-label">Simulated demo traffic</span>
        <p class="screen-note">One simulated tool call is committed with the real conformance machinery (a Merkle tree over the canonical arguments). The verifier checks the policy constraint against the commitment while only the fields the constraint touches are disclosed; every other value stays hidden, and a constraint over a hidden field reads UNKNOWN rather than conformance. The Merkle root is the proof artefact identifier.</p>
        <pre id="confView" style="font-size:11px;max-height:340px;overflow:auto;background:#f8f9fb;border:1px solid #e5e7ec;border-radius:10px;padding:14px"></pre>
      </div>
      <div class="card" style="margin-top:14px">
        <div class="card-title">Assurance packet</div>
        <span class="findings-label">Real packet machinery, simulated traffic</span>
        <p class="screen-note">The packet below is assembled just before you see it, in a disposable sandbox, from this deployment's own signed receipt chain: the same build the audit-pack command runs. Every member digest, every sha-pinned manifest input and the offline verification verdict are read from the built files. The packet's index and manifest are signed with an ephemeral key generated in memory for the build and discarded; nothing is exported or persisted. Crosswalk exports over a packet are the raucle agent-assurance product's surface, not this screen's.</p>
        <button class="btn btn-secondary" data-hi="loadAssurancePacket()">Build and verify offline</button>
        <pre id="assurancePacketView" style="margin-top:10px;font-size:11px;max-height:340px;overflow:auto;background:#f8f9fb;border:1px solid #e5e7ec;border-radius:10px;padding:14px"></pre>
      </div>
    </div>
    <div id="tab-learn" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card">
        <div class="card-title">Learn Mode — draft policies from observed traffic</div>
        <p style="font-size:0.85rem;color:#8b919e;margin-bottom:14px">
          With learn mode enabled, the gate records every call it <strong>denied</strong> for
          having no matching policy. From those observations it drafts candidate rules:
          allow lists for low-cardinality string fields, bounds for numerics, and required
          fields seen in every call. The gate stays fail-closed the whole time — learning
          never authorises traffic. Review the draft, copy it into the policy editor,
          adjust, then Save & Deploy.
        </p>
        <div class="actions" style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn" data-hi="loadLearn()">Refresh</button>
          <button class="btn" data-hi="copyDraftToEditor()">Copy into Policy Editor</button>
          <button class="btn" data-hi="clearLearn()">Clear Observations</button>
        </div>
        <div id="learnSummary" style="margin-top:14px;font-size:0.85rem"></div>
        <pre id="learnDraft" style="margin-top:10px;max-height:420px;overflow:auto;background:#f8f9fb;border:1px solid #e5e7ec;border-radius:10px;padding:14px;font-size:0.78rem">No observations yet.</pre>
      </div>
    </div>
    <div id="tab-receipts" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card"><div class="card-title">Receipts</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
          <input id="rcpt-filter-tool" class="input" style="width:150px" placeholder="tool">
          <input id="rcpt-filter-agent" class="input" style="width:150px" placeholder="agent_id">
          <select id="rcpt-filter-decision" class="input" style="width:110px">
            <option value="">any decision</option><option>allow</option><option>deny</option><option>escalate</option>
          </select>
          <input id="rcpt-filter-trace" class="input" style="width:150px" placeholder="trace_id">
          <button class="btn" data-hi="loadReceipts()">Filter</button>
          <button class="btn" data-hi="clearRcptFilters()">Clear</button>
          <button class="btn" data-hi="exportReceipts()">Export JSONL</button>
        </div>
        <div style="overflow-x:auto">
          <table id="rcptTable" style="width:100%;border-collapse:collapse;font-size:12px">
            <thead><tr>
              <th style="text-align:left;padding:6px 10px;border-bottom:1px solid #e5e7ec">time</th>
              <th style="text-align:left;padding:6px 10px;border-bottom:1px solid #e5e7ec">tool</th>
              <th style="text-align:left;padding:6px 10px;border-bottom:1px solid #e5e7ec">agent</th>
              <th style="text-align:left;padding:6px 10px;border-bottom:1px solid #e5e7ec">decision</th>
              <th style="text-align:left;padding:6px 10px;border-bottom:1px solid #e5e7ec">trace</th>
              <th style="text-align:left;padding:6px 10px;border-bottom:1px solid #e5e7ec"></th>
            </tr></thead>
            <tbody id="rcptRows"></tbody>
          </table>
        </div>
        <div style="display:flex;gap:10px;margin-top:12px;align-items:center">
          <button class="btn" id="rcpt-prev" data-hi="rcptPage(false)">Newer</button>
          <button class="btn" id="rcpt-next" data-hi="rcptPage(true)">Older</button>
          <span id="rcpt-count" style="font-size:12px;color:#737373"></span>
        </div>
      </div>
      <div id="rcpt-ancestry" class="card" style="display:none;margin-top:14px">
        <div class="card-title">Ancestry</div>
        <pre id="ancestryView" style="font-size:11px;max-height:260px;overflow:auto"></pre>
      </div>
      <div id="rcpt-offline" class="card" style="display:none;margin-top:14px">
        <div class="card-title">Offline verification</div>
        <span class="findings-label">Simulated demo receipts</span>
        <p class="screen-note">What an auditor sees without contacting the operator: the JWS signature check against the gate's public key, and the receipt hash linkage, recomputed from the receipt bytes. The verification runs on this machine with the gateway's real offline verifier; the receipt material is what the demo's simulated traffic produced.</p>
        <pre id="offlineView" style="font-size:11px;max-height:260px;overflow:auto"></pre>
      </div>
      <div id="rcpt-keyfamily" class="card" style="display:none;margin-top:14px">
        <div class="card-title">Signing key families</div>
        <span class="findings-label">Real signing configuration</span>
        <p class="screen-note">Which key family actually signs this deployment's receipts: the configured signer backend, the key id in force, the type of the key material, and the signature families observed on the stored receipts. The badge on a receipt row comes from that receipt's own signed header, never a fixed label.</p>
        <pre id="keyFamilyView" style="font-size:11px;max-height:200px;overflow:auto"></pre>
      </div>
      <div id="rcpt-keymodel" class="card" style="display:none;margin-top:14px">
        <div class="card-title">Key model: enrolled, never exported</div>
        <span class="findings-label">Read-only, driven by the live signer configuration</span>
        <p class="screen-note">The same real signer configuration as the key-family card above, plus what this deployment's code can prove about the key: the enrolment properties the gate re-checks on every identity, and the rotation paths actually implemented in the registry, credential store, agent registry and boot machinery. No private key material appears on this screen or in any panel response.</p>
        <pre id="keyModelView" style="font-size:11px;max-height:260px;overflow:auto"></pre>
      </div>
      <div class="card hidden" id="rcptCoverageCard">
        <div class="card-title">Coverage: the receipted-share metric</div>
        <span class="findings-label">Simulated demo data</span>
        <p class="screen-note" id="demoCoverageUnavailable" style="color:#a3a3a3"></p>
        <p class="screen-note" id="demoCoverageBasis"></p>
        <p class="screen-note">The unit of account is this deployment's own attributable gate receipt, counted via its bound trace id: in a single-demo-org the gate's receipts are the correlated ground truth of the receipted-share metric. A demo surface for the metric contract the assurance service serves cross-vantage as GET /coverage/{org}.</p>
        <pre id="demoCoverageSummary" style="font-size:11px;max-height:180px;overflow:auto"></pre>
        <p class="screen-note" style="margin-top:10px">Per-tool rollup over the demo receipt stream:</p>
        <div style="overflow-x:auto">
          <table><thead><tr><th>Tool</th><th>Receipted</th><th>Out of gate</th><th>Pending</th><th>Total</th><th>Share</th></tr></thead>
          <tbody id="demoCoverageTools"></tbody></table>
        </div>
        <p class="screen-note" style="margin-top:10px">Per-agent rollup over the same stream:</p>
        <div style="overflow-x:auto">
          <table><thead><tr><th>Agent</th><th>Receipted</th><th>Out of gate</th><th>Pending</th><th>Total</th><th>Share</th></tr></thead>
          <tbody id="demoCoverageAgents"></tbody></table>
        </div>
        <p class="screen-note" style="margin-top:10px">Metric-contract legend (read-only):</p>
        <pre id="demoCoverageLegend" style="font-size:11px;max-height:220px;overflow:auto"></pre>
        <p class="screen-note" style="margin-top:6px;white-space:pre-line" id="demoCoverageFlagsNote"></p>
      </div>
    </div>
    <div id="tab-mcp" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card">
        <div class="card-title">MCP Tool Scanner</div>
        <p style="font-size:0.85rem;color:#8b919e;margin-bottom:14px">
          Static analysis of MCP tool manifests for prompt injection, hidden
          instructions, exposed credentials, rug-pull wording and SSRF targets.
          Pick a seeded demo manifest or paste your own manifest JSON: either
          way the scan runs the gateway's real scanner engine live, and every
          finding below is its genuine output. A static scan does not cross
          the gate's decision path, so it mints no receipt and enters nothing
          into the receipt chain; findings carry the rule, its location and
          the evidence class, never the payload text. The demo manifests are
          simulated samples, labelled as such.
        </p>
        <div style="font-size:0.75rem;color:#a3a3a3;margin-bottom:8px">Choose a simulated demo manifest, or paste your own manifest JSON below.</div>
        <div class="file-list" id="mcpManifestList"></div>
        <textarea class="editor" id="mcpManifestText" style="height:220px" spellcheck="false"></textarea>
        <div class="actions">
          <button class="btn" data-hi="mcpScan()">Scan manifest</button>
          <button class="btn btn-secondary" data-hi="mcpClear()">Clear</button>
          <span style="font-size:0.75rem;color:#a3a3a3;align-self:center">Stateless one-shot scan: it mutates nothing and persists nothing. Pasted manifests over 256 KiB are refused.</span>
        </div>
        <div style="display:flex;gap:8px;margin-top:8px;font-size:0.78rem;color:#737373" id="mcpSummary"></div>
      </div>
      <div class="card hidden" id="mcpFindingsCard">
        <div class="card-title">Findings</div>
        <div style="overflow-x:auto">
          <table><thead><tr><th>Severity</th><th>Rule</th><th>Tool</th><th>Field</th><th>Message</th><th>Evidence class</th></tr></thead>
          <tbody id="mcpFindingsBody"></tbody></table>
        </div>
      </div>
    </div>
    <div id="tab-siem" data-truth-class="OSS MACHINERY + EE VIEW" class="hidden"><span class="truth-badge" data-truth="OSS MACHINERY + EE VIEW">OSS MACHINERY + EE VIEW</span><div class="card" id="siemConfigCard"><div class="card-title">SIEM Forwarding</div>
      <label class="toggle" style="margin-bottom:16px"><input type="checkbox" id="siemEnabled"> Enabled</label>
      <div style="display:flex;flex-direction:column;gap:8px;max-width:400px">
        <input class="input" id="siemBackend" placeholder="splunk / elastic / sentinel"><input class="input" id="siemUrl" placeholder="SIEM endpoint URL"><input class="input" id="siemToken" type="password" placeholder="SIEM token">
      </div><div class="actions"><button class="btn" data-hi="saveSIEM()">Save</button></div></div>
      <div class="card hidden" id="demoSiemCard"><div class="card-title">SIEM Forwarding</div>
        <p class="screen-note" id="demoSiemConfigured"></p>
        <span class="findings-label">Simulated demo data</span>
        <p class="screen-note">The forwarding example below illustrates what this deployment would send and how often: a simulated collector endpoint, the event shape the real forwarder emits, and per-hour event counts over the demo window. No events leave the gateway in demo mode.</p>
        <div style="font-size:12px;color:#525252;margin-bottom:6px" id="demoSiemTarget"></div>
        <div style="overflow-x:auto">
          <table><thead><tr><th>Hour</th><th>Events</th><th>Batches</th><th>Status</th></tr></thead>
          <tbody id="demoSiemEvents"></tbody></table>
        </div>
        <p class="screen-note" style="margin-top:10px" id="demoSiemWindow"></p>
        <p class="screen-note" style="margin-top:6px">One example event, in the field shape the real forwarder POSTs:</p>
        <pre id="demoSiemSample" style="font-size:11px;max-height:220px;overflow:auto"></pre>
      </div>
    </div>
    <div id="tab-users" data-truth-class="OSS MACHINERY + EE VIEW" class="hidden"><span class="truth-badge" data-truth="OSS MACHINERY + EE VIEW">OSS MACHINERY + EE VIEW</span>
      <div class="card" id="usersAddCard"><div class="card-title">Add User</div>
        <div style="display:flex;flex-direction:column;gap:8px;max-width:400px">
          <input class="input" id="newKey" placeholder="API Key"><input class="input" id="newRole" placeholder="admin / operator / auditor"><input class="input" id="newName" placeholder="Name">
        </div><div class="actions"><button class="btn" data-hi="addUser()">Add</button></div></div>
      <div class="card" id="usersTableCard"><div class="card-title">Users</div>
        <table><thead><tr><th>Key</th><th>Role</th><th>Name</th><th>MFA</th><th>Actions</th></tr></thead>
        <tbody id="userTableBody"></tbody></table>
      </div>
      <div class="card hidden" id="demoUsersCard"><div class="card-title">Operators</div>
        <span class="findings-label">Simulated demo data</span>
        <p class="screen-note">A read-only view of this deployment's operator roster. The demo credential cannot list real operators, so the table illustrates the panel's operator and MFA view with simulated records: names, roles and MFA enrolment state. Management controls stay with the authenticated operator view.</p>
        <table><thead><tr><th>Operator</th><th>Role</th><th>MFA</th></tr></thead>
        <tbody id="demoUserTableBody"></tbody></table>
      </div>
      <div class="card hidden" id="mfaSetupCard">
        <div class="card-title">MFA Setup</div>
        <p style="font-size:13px;color:#525252;margin-bottom:12px">Scan the QR code or enter the secret manually in your authenticator app (Google Authenticator, Authy, 1Password). Then enter the 6-digit code below to confirm.</p>
        <div id="mfaQrCode" style="margin-bottom:12px"></div>
        <div style="font-family:ui-monospace,monospace;font-size:13px;padding:12px;background:#fafafa;border-radius:8px;border:1px solid #e5e5e5;margin-bottom:12px;word-break:break-all" id="mfaSecret"></div>
        <div style="font-size:12px;color:#737373;margin-bottom:8px" id="mfaUri"></div>
        <div style="display:flex;gap:8px;align-items:center">
          <input class="input" id="mfaCodeInput" placeholder="6-digit code" style="width:140px" maxlength="6">
          <button class="btn" data-hi="confirmMfa()">Confirm</button>
        </div>
      </div>
    </div>
    <div id="tab-config" data-truth-class="OSS LIVE" class="hidden"><span class="truth-badge" data-truth="OSS LIVE">OSS LIVE</span>
      <div class="card" id="configEditCard"><div class="card-title">Gateway Configuration</div>
        <div id="configForm" style="display:grid;grid-template-columns:1fr 1fr;gap:12px 24px;max-width:700px">
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Host</label><input class="input" id="cfg-host" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Gateway Port</label><input class="input" id="cfg-port" type="number" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Admin Port</label><input class="input" id="cfg-admin_port" type="number" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Signer Backend</label>
            <select class="input" id="cfg-signer_backend" style="width:100%">
              <option value="local">local</option><option value="aws">aws</option><option value="azure">azure</option><option value="vault">vault</option>
            </select></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">KMS Key ID</label><input class="input" id="cfg-kms_key_id" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">KMS Region</label><input class="input" id="cfg-kms_region" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Policy File</label><input class="input" id="cfg-policy_file" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Policy Directory</label><input class="input" id="cfg-policy_dir" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Receipt Store</label><input class="input" id="cfg-receipt_store" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Audit Chain</label><input class="input" id="cfg-audit_chain" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Audit Log File</label><input class="input" id="cfg-audit_log_file" style="width:100%"></div>
          <div style="display:flex;align-items:end;gap:8px">
            <label class="toggle"><input type="checkbox" id="cfg-audit_persist"> Audit Persist</label>
          </div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Compliance Framework</label>
            <select class="input" id="cfg-compliance_framework" style="width:100%">
              <option value="eu-ai-act">eu-ai-act</option><option value="iso-42001">iso-42001</option><option value="soc2">soc2</option>
            </select></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Registry Path</label><input class="input" id="cfg-registry_path" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">SIEM Backend</label>
            <select class="input" id="cfg-siem_backend" style="width:100%">
              <option value="">(disabled)</option><option value="splunk">splunk</option><option value="elastic">elastic</option><option value="sentinel">sentinel</option>
            </select></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">SIEM URL</label><input class="input" id="cfg-siem_url" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">SIEM Token</label><input class="input" id="cfg-siem_token" type="password" placeholder="(unchanged)" style="width:100%"></div>
          <div><label style="font-size:12px;color:#737373;display:block;margin-bottom:4px">Health Check Token</label><input class="input" id="cfg-health_check_token" type="password" placeholder="(unchanged)" style="width:100%"></div>
        </div>
        <div class="actions">
          <button class="btn" data-hi="saveConfig()">Save Config</button>
          <button class="btn btn-secondary" data-hi="loadConfig()">Reset</button>
        </div>
        <div id="configStatus" style="margin-top:12px;font-size:13px"></div>
        <div style="margin-top:16px"><pre id="configView" style="display:none"></pre></div>
      </div>
      <div class="card hidden" id="demoConfigCard"><div class="card-title">Gateway Configuration</div>
        <span class="findings-label">Live deployment configuration</span>
        <p class="screen-note">The real configuration this gateway is running, rendered read-only for the demo: binding addresses, ports, signer backend, policy source and evidence store paths. Secret fields are never shown, and every edit control stays with the authenticated operator view.</p>
        <pre id="demoConfigView" style="font-size:12px"></pre>
      </div>
    </div>

  </div>
  </div>
</div>

<script>
let key='', totpCode='', connPollId=null, allConns=[], dirFilter='all', selectedSource=null, selectedDest=null;

function initSso() {
  fetch('/api/session/config').then(r=>r.json()).then(d=>{
    if (d && d.oidc_enabled) document.getElementById('ssoLoginBtn').classList.remove('hidden');
  }).catch(()=>{});
}
function ssoLogin() {
  fetch('/api/oidc/login').then(r=>r.json()).then(d=>{
    if (d && d.authorization_url) window.location.href=d.authorization_url;
    else alert('SSO is not enabled on this gateway');
  }).catch(()=>alert('SSO login failed'));
}
function handleOidcCallback() {
  const q=new URLSearchParams(window.location.search);
  const code=q.get('code')||'', error=q.get('error')||'';
  if (!code && !error) return false;
  fetch('/api/oidc/callback',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:code,state:q.get('state')||'',error:error})})
    .then(r=>{
      if (r.ok) { r.json().then(d=>{ key=d.session_token; history.replaceState(null,'',window.location.pathname); showMain(); }); return; }
      history.replaceState(null,'',window.location.pathname);
      r.json().then(d=>alert('SSO sign-in refused: '+(d.detail||'unknown error'))).catch(()=>alert('SSO sign-in refused'));
    })
    .catch(()=>alert('SSO sign-in failed'));
  return true;
}

function login() {
  key = document.getElementById('apiKey').value;
  // Try without TOTP first
  fetch('/api/stats', {headers: {'Authorization': key}})
    .then(r => {
      if (r.ok) { showMain(); }
      else if (r.status === 401 && r.headers.get('content-type','').includes('json')) {
        r.json().then(d => {
          if (d.detail && d.detail.includes('MFA required')) {
            // Show TOTP input
            document.getElementById('totpRow').classList.remove('hidden');
            document.getElementById('totpInput').focus();
            alert('This account has MFA enabled. Enter the 6-digit code from your authenticator app.');
          } else { alert('Invalid API key'); }
        });
      } else { alert('Invalid API key'); }
    });
}
function loginWithTotp() {
  totpCode = document.getElementById('totpInput').value;
  if (!totpCode || totpCode.length !== 6) { alert('Enter the 6-digit TOTP code'); return; }
  fetch('/api/stats', {headers: {'Authorization': key, 'X-TOTP': totpCode}})
    .then(r => { if (r.ok) { showMain(); } else { alert('Invalid TOTP code'); } });
}
function showMain() {
  document.getElementById('login').classList.add('hidden');
  document.getElementById('main').classList.remove('hidden');
  loadAll();
}
function showTab(t,el) {
  document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('[id^=tab-]').forEach(x=>x.classList.add('hidden'));
  el.classList.add('active'); document.getElementById('tab-'+t).classList.remove('hidden');
  if(t==='dashboard')loadStats(); if(t==='connections'){demoExample();updatePathTail();if(!pathPollId)pathPollId=setInterval(updatePathTail,3000);startConnPolling();}else if(pathPollId){clearInterval(pathPollId);pathPollId=null;} else stopConnPolling();
  if(t==='policies'){loadPolicy();loadSimPanel();} if(t==='simulate')loadSimTab(); if(t==='stop')loadStopPanel(); if(t==='assure')loadAssure(); if(t==='learn')loadLearn(); if(t==='receipts'){loadReceipts();loadKeyFamily();loadKeyModel();if(typeof demoMode!=='undefined'&&demoMode)loadCoverage();} if(t==='capdemo')capDemoLoad(); if(t==='mcp')loadMcpPanel(); if(t==='siem')loadSIEM(); if(t==='users')loadUsers(); if(t==='config')loadConfig();
  if(t==='policies')loadPolicy(); if(t==='assure')loadAssure(); if(t==='learn')loadLearn(); if(t==='receipts'){loadReceipts();loadKeyFamily();loadKeyModel();if(typeof demoMode!=='undefined'&&demoMode)loadCoverage();} if(t==='capdemo')capDemoLoad(); if(t==='siem')loadSIEM(); if(t==='users')loadUsers(); if(t==='config')loadConfig();
  if(t==='dlp')loadDlpPanel();
  if(t==='injection'||t==='shadow')loadDemoFindings();
  if(t==='session')loadSessionPanel();
}
function api(p,o){const h={'Authorization':key,...((o||{}).headers||{})};if(totpCode)h['X-TOTP']=totpCode;return fetch(p,{...(o||{}),headers:h});}
function loadAll(){loadStats();}
function loadStats(){api('/api/stats').then(r=>r.json()).then(d=>{
  document.getElementById('statsGrid').innerHTML=`<div class="stat"><div class="stat-value">${escn(d.total_requests)}</div><div class="stat-label">Total</div></div><div class="stat"><div class="stat-value">${escn(d.allowed)}</div><div class="stat-label">Allowed</div></div><div class="stat"><div class="stat-value">${escn(d.denied)}</div><div class="stat-label">Denied</div></div><div class="stat"><div class="stat-value">${escn(d.escalated)}</div><div class="stat-label">Escalated</div></div><div class="stat"><div class="stat-value">${escn(d.avg_latency_us)}</div><div class="stat-label">Avg us</div></div>`;
  let tb=document.getElementById('toolTableBody');tb.innerHTML='';Object.entries(d.tools||{}).forEach(([t,s])=>tb.innerHTML+=`<tr><td>${esc(t)}</td><td>${escn(s.allow)}</td><td>${escn(s.deny)}</td><td>${escn(s.escalate)}</td></tr>`);
});}
function esc(s){return s?s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])):'--';}
function escn(v){return esc(String(v===undefined||v===null?0:v));}
function setDirFilter(d,el){dirFilter=d;document.querySelectorAll('.dir-toggle button').forEach(b=>b.classList.remove('active'));el.classList.add('active');loadConnections(lastLimit||200);}

// === Netbird-style flow graph ===
let lastLimit=1;
function loadConnections(limit) {
  lastLimit = limit || 1;
  if(limit===undefined) limit=lastLimit;
  let p=new URLSearchParams({limit:limit});
  let fd=document.getElementById('filterDecision').value;
  if(fd)p.set('decision',fd);
  api('/api/connections?'+p.toString()).then(r=>r.json()).then(d=>{
    allConns=d.connections||[];
    if(demoMode&&demoScenarioFilter!=='all'&&demoScenarioFilter!=='threats'){
      const sc=demoScenarioFilter;
      const tools=demoToolMap();
      allConns=allConns.filter(c=>(tools[sc]||[]).includes(c.tool)||(c.policy||'').toLowerCase().includes({banking:'banking',government:'government',health:'healthcare'}[sc]));
    }
    if(demoMode&&demoScenarioFilter==='threats') allConns=threatsLens(allConns);
    renderFlow();renderConnTable();
    if(lastLimit===1&&allConns.length){selectConn(0);showPath(0);}
  }).catch(()=>{});
}

function getFiltered() {
  let fd=document.getElementById('filterDecision').value;
  let conns=allConns;
  if(fd)conns=conns.filter(c=>c.decision===fd);
  if(selectedSource)conns=conns.filter(c=>c.source===selectedSource);
  if(selectedDest)conns=conns.filter(c=>c.destination===selectedDest);
  const mid=document.getElementById('midFilter');
  if(mid&&mid.value){const mv=mid.value.toLowerCase();conns=conns.filter(c=>(c.tool||'').toLowerCase().includes(mv));}
  return conns;
}

function renderFlow() {
  let conns=getFiltered();
  let sf=(document.getElementById('srcFilter')?.value||'').toLowerCase();
  let mf=(document.getElementById('midFilter')?.value||'').toLowerCase();
  let df=(document.getElementById('dstFilter')?.value||'').toLowerCase();

  // Group by source
  let bySrc={}; conns.forEach(c=>{let s=c.source||'unknown';if(sf&&!s.toLowerCase().includes(sf))return;if(!bySrc[s])bySrc[s]={t:0,a:0,d:0,e:0};bySrc[s].t++;bySrc[s][c.decision[0]]=(bySrc[s][c.decision[0]]||0)+1;});
  // Group by tool
  let byTool={}; conns.forEach(c=>{let t=c.tool||'unknown';let p=c.policy||'';if(mf&&!t.toLowerCase().includes(mf)&&!p.toLowerCase().includes(mf))return;if(!byTool[t])byTool[t]={t:0,a:0,d:0,e:0,p:p};byTool[t].t++;byTool[t][c.decision[0]]=(byTool[t][c.decision[0]]||0)+1;});
  // Group by dest
  let byDst={}; conns.forEach(c=>{let d=c.destination||'unknown';if(df&&!d.toLowerCase().includes(df))return;if(!byDst[d])byDst[d]={t:0,a:0,d:0,e:0};byDst[d].t++;byDst[d][c.decision[0]]=(byDst[d][c.decision[0]]||0)+1;});

  // Render source column
  let srcEntries=Object.entries(bySrc).sort((a,b)=>b[1].t-a[1].t);
  document.getElementById('srcCount').textContent=srcEntries.length;
  document.getElementById('srcList').innerHTML=srcEntries.length?srcEntries.map(([n,d])=>{
    let pct=Math.round(d.a/d.t*100);
    let dot=d.a>d.d?'dot-allow':d.d>d.a?'dot-deny':'dot-escalate';
    return `<div class="flow-item${selectedSource===n?' active':''}" id="src-${esc(n)}" data-name="${esc(n)}" data-hi="flowItemClick(event,'source')">
      <div class="flow-item-name"><span class="flow-item-dot ${dot}"></span>${esc(n)}</div>
      <div class="flow-item-meta">${escn(d.t)} calls: ${escn(d.a)}A / ${escn(d.d)}D / ${escn(d.e)}E</div>
      <div class="flow-item-bar"><div class="flow-item-bar-fill" style="width:${pct}%;background:#171717"></div></div>
    </div>`;
  }).join(''):'<div class="flow-empty">No sources</div>';

  // Render center column
  let midEntries=Object.entries(byTool).sort((a,b)=>b[1].t-a[1].t);
  document.getElementById('midCount').textContent=midEntries.length;
  document.getElementById('midList').innerHTML=midEntries.length?midEntries.map(([n,d])=>{
    let pct=Math.round(d.a/d.t*100);
    let dot=d.a>d.d?'dot-allow':d.d>d.a?'dot-deny':'dot-escalate';
    let pol=d.p?d.p.split('/').pop():'';
    return `<div class="flow-item" id="mid-${esc(n)}" data-name="${esc(n)}" data-hi="flowItemClick(event,'tool')">
      <div class="flow-item-name"><span class="flow-item-dot ${dot}"></span>${esc(n)}</div>
      <div class="flow-item-meta">${escn(d.t)} calls: ${escn(d.a)}A / ${escn(d.d)}D / ${escn(d.e)}E ${pol?'<span class="protocol-tag">'+esc(pol)+'</span>':''}</div>
      <div class="flow-item-bar"><div class="flow-item-bar-fill" style="width:${pct}%;background:#171717"></div></div>
    </div>`;
  }).join(''):'<div class="flow-empty">No gate activity</div>';

  // Render destination column
  let dstEntries=Object.entries(byDst).sort((a,b)=>b[1].t-a[1].t);
  document.getElementById('dstCount').textContent=dstEntries.length;
  document.getElementById('dstList').innerHTML=dstEntries.length?dstEntries.map(([n,d])=>{
    let pct=Math.round(d.a/d.t*100);
    let dot=d.a>d.d?'dot-allow':d.d>d.a?'dot-deny':'dot-escalate';
    return `<div class="flow-item${selectedDest===n?' active':''}" id="dst-${esc(n)}" data-name="${esc(n)}" data-hi="flowItemClick(event,'dest')">
      <div class="flow-item-name"><span class="flow-item-dot ${dot}"></span>${esc(n)}</div>
      <div class="flow-item-meta">${escn(d.t)} calls: ${escn(d.a)}A / ${escn(d.d)}D / ${escn(d.e)}E</div>
      <div class="flow-item-bar"><div class="flow-item-bar-fill" style="width:${pct}%;background:#171717"></div></div>
    </div>`;
  }).join(''):'<div class="flow-empty">No destinations</div>';

  // Draw SVG connection lines between columns
  drawFlowLines(conns);
}

function drawFlowLines(conns) {
  let svg=document.getElementById('flowSvg');
  let graph=document.getElementById('flowGraph');
  let rect=graph.getBoundingClientRect();
  svg.setAttribute('width',rect.width);
  svg.setAttribute('height',rect.height);
  svg.innerHTML='';

  // Build source->tool and tool->dest edge maps
  let srcToTool={}; conns.forEach(c=>{let s=c.source||'unknown',t=c.tool||'unknown';let k=s+'||'+t;if(!srcToTool[k])srcToTool[k]={count:0,dec:c.decision};srcToTool[k].count++;});
  let toolToDst={}; conns.forEach(c=>{let t=c.tool||'unknown',d=c.destination||'unknown';let k=t+'||'+d;if(!toolToDst[k])toolToDst[k]={count:0,dec:c.decision};toolToDst[k].count++;});

  function getRightEdge(id){let el=document.getElementById(id);if(!el)return null;let r=el.getBoundingClientRect();return{x:r.right-rect.left,y:r.top+r.height/2-rect.top};}
  function getLeftEdge(id){let el=document.getElementById(id);if(!el)return null;let r=el.getBoundingClientRect();return{x:r.left-rect.left,y:r.top+r.height/2-rect.top};}
  function getMidRight(id){let el=document.getElementById('mid-'+id);if(!el)return null;let r=el.getBoundingClientRect();return{x:r.right-rect.left,y:r.top+r.height/2-rect.top};}
  function getMidLeft(id){let el=document.getElementById('mid-'+id);if(!el)return null;let r=el.getBoundingClientRect();return{x:r.left-rect.left,y:r.top+r.height/2-rect.top};}

  let lineColor={'allow':'#22c55e','deny':'#ef4444','escalate':'#f59e0b'};
  let ns='http://www.w3.org/2000/svg';

  // Draw source -> tool lines
  Object.entries(srcToTool).forEach(([k,info])=>{
    let [s,t]=k.split('||');
    let src=getRightEdge('src-'+s);
    let mid=getMidLeft(t);
    if(src&&mid){
      let path=document.createElementNS(ns,'path');
      let cx=(src.x+mid.x)/2;
      path.setAttribute('d',`M${src.x},${src.y} C${cx},${src.y} ${cx},${mid.y} ${mid.x},${mid.y}`);
      path.setAttribute('stroke',lineColor[info.dec]||'#d4d4d4');
      path.setAttribute('stroke-width',Math.min(1+info.count*0.5,4));
      path.setAttribute('fill','none');
      path.setAttribute('opacity','0.4');
      svg.appendChild(path);
    }
  });

  // Draw tool -> dest lines
  Object.entries(toolToDst).forEach(([k,info])=>{
    let [t,d]=k.split('||');
    let mid=getMidRight(t);
    let dst=getLeftEdge('dst-'+d);
    if(mid&&dst){
      let path=document.createElementNS(ns,'path');
      let cx=(mid.x+dst.x)/2;
      path.setAttribute('d',`M${mid.x},${mid.y} C${cx},${mid.y} ${cx},${dst.y} ${dst.x},${dst.y}`);
      path.setAttribute('stroke',lineColor[info.dec]||'#d4d4d4');
      path.setAttribute('stroke-width',Math.min(1+info.count*0.5,4));
      path.setAttribute('fill','none');
      path.setAttribute('opacity','0.4');
      svg.appendChild(path);
    }
  });
}

function flowItemClick(ev,kind){
  const el=ev.currentTarget||ev.target.closest('.flow-item');
  const n=el?el.dataset.name:null; if(n===null||n===undefined)return;
  if(kind==='source')toggleSource(n);
  else if(kind==='dest')toggleDest(n);
  else filterByTool(n);
}
function userMfaAction(ev,action){
  const el=ev.currentTarget||ev.target.closest('[data-user-id]');
  const id=el?el.dataset.userId:null; if(!id)return;
  if(action==='setup')setupMfa(id); else disableMfa(id);
}
function toggleSource(n){selectedSource=selectedSource===n?null:n;renderFlow();renderConnTable();}
function toggleDest(n){selectedDest=selectedDest===n?null:n;renderFlow();renderConnTable();}
function filterByTool(t){document.getElementById('midFilter').value=t;renderFlow();renderConnTable();}

function renderConnTable() {
  let conns=getFiltered();
  let tb=document.getElementById('connBody');tb.innerHTML='';
  conns.forEach((c,i)=>{
    let badge=c.decision==='allow'?'badge-allow':c.decision==='deny'?'badge-deny':'badge-escalate';
    let time=c.timestamp?c.timestamp.substring(11,19):'--:--:--';
    let policy=c.policy?c.policy.split('/').pop():'--';
    tb.innerHTML+=`<tr class="conn-row" data-idx="${i}"><td>${esc(time)}</td><td>${esc(c.source)}</td><td>${esc(c.tool)}</td><td>${esc(policy)}</td><td><span class="${badge}">${esc(c.decision)}</span></td><td>${esc(c.destination)}</td><td style="max-width:200px;overflow:hidden;text-overflow:ellipsis">${esc(c.reason)}</td><td>${escn(c.latency_us)}us</td></tr>`;
  });
}
function selectConn(i){document.querySelectorAll('.conn-row').forEach(r=>r.classList.remove('selected'));let row=document.querySelector(`.conn-row[data-idx="${i}"]`);if(row)row.classList.add('selected');}
function demoExample(){loadConnections(1);}
function loadRecent(){loadConnections(200);}
function showPath(i){
  let c=allConns[i]; if(!c) return;
  let card=document.getElementById('connPathCard'); let body=document.getElementById('connPath');
  card.classList.remove('hidden');
  let dt=c.timestamp?String(c.timestamp).replace('T',' ').slice(0,19):'';
  body.innerHTML=
    '<div><div class="card-title">Inbound</div><div style="font-size:13px;font-weight:500">'+esc(c.agent_id||c.source||'unknown')+'</div>'+
    '<div style="color:#a3a3a3;font-size:12px">'+esc(c.tool||'')+' &middot; '+esc(dt)+'</div></div>'+
    '<div><div class="card-title">Gate processing</div><div style="font-size:13px;font-weight:600">'+esc((c.decision||'').toUpperCase())+((c.reason)?' &middot; '+esc(c.reason):'')+'</div>'+
    '<div style="color:#a3a3a3;font-size:12px">'+esc(c.policy||'default')+' &middot; '+(c.latency_us||0)+'&micro;s'+((c.receipt_id)?' &middot; receipt '+esc(String(c.receipt_id).slice(0,30))+'&hellip;':'')+'</div></div>'+
    '<div><div class="card-title">Outbound</div><div style="font-size:13px;font-weight:500">'+esc(c.destination||'unknown')+'</div>'+
    '<div style="color:#a3a3a3;font-size:12px">policy-checked destination</div></div>';
}
let pathFilter='all', pathOpen=-1, latestConns=[], pathPollId=null;
function setDecisionFilter(f, el){
  pathFilter=f; pathOpen=-1;
  document.querySelectorAll('#pathPills button').forEach(b=>b.classList.toggle('active', b===el));
  const fd=document.getElementById('filterDecision'); if(fd) fd.value=(f==='all'?'':f);
  if(allConns.length) loadConnections(lastLimit||200);
  renderPathTail();
}
function updatePathTail(){
  const p=new URLSearchParams({limit:12});
  api('/api/connections?'+p.toString()).then(r=>r.json()).then(d=>{
    latestConns=(d.connections||[]);
    renderPathTail();
  }).catch(()=>{});
}
function pathRowClick(i){ pathOpen=(pathOpen===i? -1:i); renderPathTail(); }
function renderPathTail(){
  const body=document.getElementById('connPath'); if(!body) return;
  const shown=latestConns.filter(c=>pathFilter==='all'||c.decision===pathFilter);
  const cnt=document.getElementById('pathCount'); if(cnt) cnt.textContent=latestConns.length+' in last 12s';
  if(!shown.length){ body.innerHTML='<div class="flow-empty">No recent requests'+(pathFilter!=='all'?' with this decision':'')+'</div>'; return; }
  body.innerHTML=shown.slice(0,8).map((c,i)=>{
    const gi=latestConns.indexOf(c);
    const badge=c.decision==='allow'?'badge-allow':c.decision==='deny'?'badge-deny':'badge-escalate';
    const t=String(c.timestamp||'').slice(11,19);
    let row='<div class="path-row" style="display:flex;gap:10px;align-items:center;padding:8px 4px;border-bottom:1px solid #f0f0f0;cursor:pointer" data-gi="'+gi+'">'+
      '<span style="font-family:ui-monospace,Menlo,monospace;font-size:11px;color:#a3a3a3">'+esc(t)+'</span>'+
      '<span style="font-size:12px;font-weight:500;min-width:150px">'+esc(c.agent_id||c.source||'')+'</span>'+
      '<span style="font-size:12px;color:#737373">&rarr; '+esc(c.tool||'')+'</span>'+
      '<span style="font-size:12px;color:#737373">&rarr; '+esc(c.destination||'')+'</span>'+
      '<span class="'+badge+'">'+esc(c.decision)+'</span>'+
      '<span style="font-size:11px;color:#a3a3a3">'+(c.latency_us||0)+'&micro;s'+((c.receipt_id)?' &middot; '+esc(String(c.receipt_id).slice(0,16))+'&hellip;':'')+'</span></div>';
    if(pathOpen===gi){
      row+='<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;padding:12px 4px 14px;border-bottom:1px solid #f0f0f0;background:#fafafa">'+
        '<div><div class="card-title">Inbound</div><div style="font-size:13px;font-weight:500">'+esc(c.agent_id||c.source||'unknown')+'</div>'+
        '<div style="color:#a3a3a3;font-size:12px">'+esc(c.tool||'')+' &middot; '+esc(String(c.timestamp||'').replace('T',' ').slice(0,19))+'</div></div>'+
        '<div><div class="card-title">Gate processing</div><div style="font-size:13px;font-weight:600">'+esc((c.decision||'').toUpperCase())+((c.reason)?' &middot; '+esc(c.reason):'')+'</div>'+
        '<div style="color:#a3a3a3;font-size:12px">'+esc(c.policy||'default')+' &middot; '+(c.latency_us||0)+'&micro;s'+((c.receipt_id)?' &middot; receipt '+esc(String(c.receipt_id).slice(0,30))+'&hellip;':'')+'</div></div>'+
        '<div><div class="card-title">Outbound</div><div style="font-size:13px;font-weight:500">'+esc(c.destination||'unknown')+'</div>'+
        '<div style="color:#a3a3a3;font-size:12px">policy-checked destination</div></div></div>';
    }
    return row;
  }).join('');
}

function startConnPolling(){stopConnPolling();connPollId=setInterval(()=>{if(document.getElementById('liveMode')?.checked&&!document.getElementById('tab-connections').classList.contains('hidden'))loadConnections();},5000);}
function stopConnPolling(){if(connPollId){clearInterval(connPollId);connPollId=null;}}

let currentFile='';
function loadPolicy(){api('/api/policies').then(r=>r.json()).then(d=>{let fl=document.getElementById('fileList');fl.innerHTML='';(d.files||[]).forEach(f=>{let chip=document.createElement('div');chip.className='file-chip'+(f.name===currentFile||(!currentFile&&f===d.files[0])?' active':'');chip.textContent=f.name;chip.onclick=()=>{currentFile=f.name;loadPolicyFile(f.path);document.querySelectorAll('.file-chip').forEach(c=>c.classList.remove('active'));chip.classList.add('active');};fl.appendChild(chip);});if(d.content!==undefined)document.getElementById('policyEditor').value=d.content;});}
function loadPolicyFile(path){api('/api/policies?file='+encodeURIComponent(path)).then(r=>r.json()).then(d=>{document.getElementById('policyEditor').value=d.content||'';});}
function validatePolicy(){api('/api/policies/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:document.getElementById('policyEditor').value})}).then(r=>r.json()).then(d=>alert(d.valid?'Valid':'Invalid: '+d.error));}
function savePolicy(){api('/api/policies',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:document.getElementById('policyEditor').value})}).then(r=>r.json()).then(d=>alert('Saved: '+JSON.stringify(d)));}
function reloadPolicy(){api('/api/policies/reload',{method:'POST'}).then(r=>r.json()).then(d=>alert('Reloaded: '+JSON.stringify(d)));}
let rcptCursor=null, rcptCursors=[];
/* --- ambient ledger field: synthetic, login screen only, muted state tints --- */
(function(){
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const field = document.getElementById('field');
  if(!field || reduced) return;
  const ctx = field.getContext('2d');
  let W=0,H=0,dpr=1, chips=[];
  function fit(){ dpr=Math.min(2,devicePixelRatio||1); W=innerWidth; H=innerHeight; field.width=W*dpr; field.height=H*dpr; }
  fit(); addEventListener('resize', fit);
  const LANES=12;
  function spawn(){
    const r=Math.random(), kind = r<.10?'esc':r<.34?'no':'ok';
    chips.push({lane:Math.floor(Math.random()*LANES), x:-30-Math.random()*320,
      v:.045+Math.random()*.05, s:9+Math.random()*7, kind, done:false, seed:Math.random(), dy:0, trail:null});
  }
  function step(dt,t){
    const lh=H/(LANES+1);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,W,H);
    for(let l=1;l<=LANES;l++){
      ctx.strokeStyle='rgba(10,10,10,.08)'; ctx.lineWidth=1;
      ctx.beginPath(); ctx.moveTo(0,lh*l+.5); ctx.lineTo(W,lh*l+.5); ctx.stroke();
    }
    for(const c of chips){
      if(c.x===undefined){ continue; }
      c.x+=c.v*dt*150;
      if(!c.done && c.x>W*.22 && Math.random()<.008) c.done=true;
      if(c.done && c.kind==='no') c.dy=Math.min(30,c.dy+24*dt);
      const y=lh*(c.lane+1)+c.dy+(c.kind==='esc'?Math.sin(t*2+c.seed*9)*2:0), h=c.s, q=h/2;
      if(c.kind==='no'&&c.done){
        ctx.strokeStyle='rgba(10,10,10,.42)'; ctx.lineWidth=1.5;
        ctx.strokeRect(c.x-q,y-q,h,h);
        ctx.beginPath(); ctx.moveTo(c.x-q+2,y-q+2); ctx.lineTo(c.x+q-2,y+q-2);
        ctx.moveTo(c.x+q-2,y-q+2); ctx.lineTo(c.x-q+2,y+q-2); ctx.stroke();
      } else if(c.kind==='esc'){
        ctx.strokeStyle='rgba(10,10,10,.38)'; ctx.lineWidth=1.5;
        ctx.beginPath(); ctx.moveTo(c.x,y-q); ctx.lineTo(c.x+q,y); ctx.lineTo(c.x,y+q); ctx.lineTo(c.x-q,y); ctx.closePath(); ctx.stroke();
      } else if(c.done){
        ctx.fillStyle='rgba(10,10,10,.40)'; ctx.fillRect(c.x-q,y-q,h,h);
        if(c.trail==null) c.trail=c.x;
        ctx.strokeStyle='rgba(10,10,10,.22)'; ctx.lineWidth=1; ctx.setLineDash([2,3]);
        ctx.beginPath(); ctx.moveTo(c.trail,y); ctx.lineTo(c.x-q-5,y); ctx.stroke(); ctx.setLineDash([]);
      } else {
        ctx.strokeStyle='rgba(10,10,10,.34)'; ctx.lineWidth=1.5;
        ctx.strokeRect(c.x-q,y-q,h,h);
        if(c.seed>.8){ ctx.fillStyle='rgba(10,10,10,.34)'; ctx.fillRect(c.x-1,y-1,3,3); }
      }
    }
    chips = chips.filter(c=>c.x<W+50 && c.dy<H*.6);
    let added=0; while(chips.length<targetChips && added<24){spawn(); added++;}
    if(chips.length>LANES*30+40) chips.length=LANES*30;
  }
  let last=performance.now();
  function frame(now){ const dt=Math.min(.05,(now-last)/1000); last=now;
    if(!document.hidden) step(dt, now/1000);
    requestAnimationFrame(frame); }
  requestAnimationFrame(frame);
  // login screen only: the field disappears as soon as the login card does
  const loginEl = document.getElementById('login');
  const hud = document.getElementById('pulseHud');
  new MutationObserver(()=>{
    const gone = loginEl.classList.contains('hidden');
    field.classList.toggle('hidden', gone);
    if(hud) hud.classList.toggle('hidden', gone);
  }).observe(loginEl, {attributes:true, attributeFilter:['class']});
  // real rate hook: the counter is the gateway's actual gate throughput
  let targetChips = LANES*14;
  const pulseEl = document.getElementById('pulseCount');
  function refreshPulse(){
    fetch('/api/live-pulse').then(r=>r.json()).then(d=>{
      if(pulseEl && d.live){ pulseEl.textContent = String(d.rpm_1m); hud && hud.classList.remove('hidden'); }
      targetChips = Math.min(LANES*30, Math.max(LANES*10, LANES + Math.round((d.rpm_1m||0)/60*LANES/4)));
    }).catch(()=>{ if(hud) hud.classList.add('hidden'); });
  }
  setInterval(refreshPulse, 5000); refreshPulse();
})();
function rcptQueryParams(){
  const p=new URLSearchParams(); p.set('limit',20);
  const t=document.getElementById('rcpt-filter-tool').value.trim(); if(t)p.set('tool',t);
  const a=document.getElementById('rcpt-filter-agent').value.trim(); if(a)p.set('agent_id',a);
  const d=document.getElementById('rcpt-filter-decision').value; if(d)p.set('decision',d);
  const tr=document.getElementById('rcpt-filter-trace').value.trim(); if(tr)p.set('trace_id',tr);
  if(rcptCursor)p.set('cursor',rcptCursor);
  return p.toString();
}
function loadReceipts(){
  api('/api/receipts?'+rcptQueryParams()).then(r=>r.json()).then(d=>{
    const rows=document.getElementById('rcptRows'); rows.innerHTML='';
    (d.receipts||[]).forEach(r=>{
      const tr=document.createElement('tr');
      tr.style.borderBottom='1px solid #f0f1f4';
      const dec=r.decision; const color=dec==='allow'?'#16a34a':(dec==='deny'?'#dd2f45':'#d97706');
      tr.innerHTML='<td style="padding:6px 10px">'+new Date((r.iat||0)*1000).toISOString().replace('T',' ').slice(0,19)+'</td>'
        +'<td style="padding:6px 10px">'+esc(r.tool||'')+'</td>'
        +'<td style="padding:6px 10px">'+esc(r.agent_id||'')+'</td>'
        +'<td style="padding:6px 10px;color:'+color+';font-weight:600">'+esc(r.decision||'')+'</td>'
        +'<td style="padding:6px 10px;font-family:monospace;font-size:11px">'+esc(r.trace_id?r.trace_id.slice(0,12)+'…':'')+'</td>'
        +'<td style="padding:6px 10px"><a href="#" style="color:#3a3f4b" data-hash="'+esc(r.receipt_hash||'')+'" data-hi="rcptRowClick(event)">trace</a> <a href="#" style="color:#3a3f4b" data-hash="'+esc(r.receipt_hash||'')+'" data-hi="offlineVerify(event)">verify</a> '+(r.signing_family==='pq1-hybrid'?'<span style="display:inline-block;padding:1px 6px;border:1px solid #7c3aed;border-radius:999px;font-size:10px;color:#7c3aed;vertical-align:middle">PQ hybrid</span>':'')+'</td>';
      rows.appendChild(tr);
    });
    rcptCursor=d.next_cursor||null;
    document.getElementById('rcpt-count').textContent=(d.total??0)+' total · '+(d.count||0)+' shown';
  });
}
function rcptRowClick(e){const a=e.target.closest('a[data-hash]'); if(a) showAncestry(a.getAttribute('data-hash'));}
function clearRcptFilters(){['rcpt-filter-tool','rcpt-filter-agent','rcpt-filter-decision','rcpt-filter-trace'].forEach(i=>document.getElementById(i).value=''); rcptCursor=null; loadReceipts();}
function rcptPage(older){
  if(older && rcptCursor){rcptCursors.push(rcptCursor); loadReceipts();}
  else if(!older && rcptCursors.length){rcptCursor=rcptCursors.pop(); loadReceipts();}
}
function showAncestry(hash){
  const panel=document.getElementById('rcpt-ancestry'); panel.style.display='block';
  document.getElementById('ancestryView').textContent='Walking ancestry…';
  api('/api/receipts/'+encodeURIComponent(hash)+'/ancestors').then(r=>r.ok?r.json():{nodes:[],edges:[]}).then(d=>{
    if(!d.nodes||!d.nodes.length){document.getElementById('ancestryView').textContent='No ancestry found (gate receipts are trace-roots; agent-side provenance chains attach as parents).'; return;}
    const lines=d.nodes.map(n=>(n.decision==='deny'?'✗ ':'✓ ')+new Date((n.iat||0)*1000).toISOString().slice(11,19)+'  '+(n.tool||'')+'  '+(n.agent_id||'')+'  ['+(n.receipt_hash||'').slice(7,19)+']');
    document.getElementById('ancestryView').textContent=lines.join('\\n')+((d.edges&&d.edges.length)?'\\n\\nedges: '+d.edges.length:'');
  });
}
function loadAssure(){
  const crossView=document.getElementById('crossOrgView'), confView=document.getElementById('confView');
  crossView.textContent='Verifying as Organisation B (no contact with the issuing operator)…';
  confView.textContent='Committing simulated arguments…';
  api('/api/demo/cross-org').then(r=>r.ok?r.json():r.json().then(d=>{throw new Error(d.detail||'not loaded');})).then(d=>{
    const lines=[
      d.description,
      '',
      'Organisation A (issuer): key id '+d.org_a.key_id+', '+d.org_a.receipt_count+' receipt(s) signed under its own key',
      'Organisation B (verifier): pin = '+d.org_b.pinned_key_source,
      'Contact with Organisation A: '+d.contact.statement,
      '',
      'What the Organisation B verifier sees:',
    ];
    (d.verifications||[]).forEach(v=>{
      lines.push('  receipt '+v.receipt_hash_prefix+'…  verdict: '+v.verdict);
      lines.push('    signature check: '+v.signature_check+' (Ed25519 JWS against the pinned key)');
      lines.push('    hash linkage: '+(v.hash_linkage&&v.hash_linkage.recomputed_matches?'ok - recomputed from the receipt bytes':'FAILED'));
      lines.push('    '+v.offline);
    });
    lines.push('');
    lines.push('Fail-closed contrast: '+(d.wrong_key_check&&d.wrong_key_check.verdict==='failed'?'a receipt offered under any key other than the pinned Organisation A key is REFUSED.':'UNEXPECTED: see endpoint response.'));
    lines.push('');
    lines.push(d.offline);
    lines.push('');
    lines.push(d.note);
    crossView.textContent=lines.join('\\n');
  }).catch(err=>{ crossView.textContent='Cross-organisation view unavailable: '+err.message; });
  api('/api/demo/conformance').then(r=>r.ok?r.json():r.json().then(d=>{throw new Error(d.detail||'not loaded');})).then(d=>{
    const lines=[
      d.description,
      '',
      'Simulated tool call: '+d.simulated_traffic.tool+' (committed with the real conformance machinery)',
      'Proof artefact: '+d.proof_artifact.kind+' = '+d.proof_artifact.identifier,
      'Scheme: '+d.proof_artifact.scheme,
      '',
      'Policy claims proven over the commitment:',
      ...d.claims.map(c=>'  ['+c.result+'] '+c.claim+' ('+c.constraint_kind+' on '+(c.disclosed_value===null?'hidden field '+c.field:c.field+' = '+JSON.stringify(c.disclosed_value))+')'),
      '',
      'Disclosed to the verifier: '+d.disclosed.fields.join(', '),
      'Stays hidden: '+d.hidden.fields.join(', ')+' - '+d.hidden.note,
      '',
      d.fail_closed_note,
      '',
      d.note
    ];
    confView.textContent=lines.join('\\n');
  }).catch(err=>{ confView.textContent='Conformance view unavailable: '+err.message; });
}
function offlineVerify(e){
  const a=e.target.closest('a[data-hash]'); if(!a) return;
  const panel=document.getElementById('rcpt-offline'); panel.style.display='block';
  const view=document.getElementById('offlineView');
  view.textContent='Verifying offline (no operator contact)…';
  api('/api/receipts/'+encodeURIComponent(a.getAttribute('data-hash'))+'/offline-verify',{method:'POST'}).then(r=>r.ok?r.json():r.json().then(d=>{throw new Error((d.detail&&(d.detail.errors&&d.detail.errors.join?d.detail.errors.join('; '):d.detail))||'verification failed');})).then(d=>{
    const lines=[
      'verdict: '+d.verdict,
      'signature check: '+d.signature_check+' (Ed25519 JWS under the gate public key)',
      'hash linkage: '+(d.hash_linkage&&d.hash_linkage.recomputed_matches?'ok - stored hash matches a recomputation from the receipt bytes':'FAILED')+(d.hash_linkage&&d.hash_linkage.recomputed_sha256_prefix?(' (' + d.hash_linkage.recomputed_sha256_prefix + '…)'):''),
      'receipts checked: '+d.receipt_count,
      '',
      d.offline,
      '',
      d.note
    ];
    view.textContent=lines.join('\\n');
  }).catch(err=>{ view.textContent='Verification failed: '+err.message; });
}
function exportReceipts(){
  const key=getApiKey(); if(!key){alert('Sign in first');return;}
  window.open('/api/receipts/export','_blank');
}
// ================= CAPABILITY TOKEN INSPECTOR (E1, demo-only) =================
let capDemoData=null;
function capDemoLoad(){
  const list=document.getElementById('capDemoList'); if(!list) return;
  const view=document.getElementById('capEnvelopeView');
  if(view&&!view.textContent)view.textContent='Pick a simulated capability call.';
  api('/api/demo/capabilities').then(r=>r.ok?r.json():{calls:[]}).then(d=>{
    capDemoData=d;
    while(list.firstChild)list.removeChild(list.firstChild);
    (d.calls||[]).forEach(c=>{
      const b=document.createElement('button');
      b.className='btn btn-secondary'; b.style.cssText='display:block;width:100%;margin-bottom:6px;font-size:12px;text-align:left';
      b.setAttribute('data-call-id',esc(c.id)); b.setAttribute('data-hi','capDemoPick(event)');
      b.textContent=c.scenario+' · '+c.agent_id+' · '+c.tool;
      list.appendChild(b);
    });
    list.dataset.note=d.note||'';
  });
}
function capDemoPick(e){
  const b=e.target.closest('button[data-call-id]'); if(!b) return;
  const id=b.getAttribute('data-call-id');
  const call=(capDemoData&&capDemoData.calls||[]).find(c=>c.id===id); if(!call) return;
  window.__capDemoSelectedId=id;
  const view=document.getElementById('capEnvelopeView');
  const lines=['scenario: '+call.scenario,'expectation: '+call.expectation,'simulated call args: '+JSON.stringify(call.args),''];
  call.chain.forEach((t,i)=>{
    lines.push((i===0?'---- root token ':'---- attenuated token ')+'['+t.role+'] ----');
    lines.push('token id: '+t.token_id);
    lines.push('issuer: '+t.issuer+' (key '+t.issuer_key_id+')');
    lines.push('agent binding: '+t.agent_id);
    lines.push('tool scope: '+t.tool);
    lines.push('parent id: '+(t.parent_id||'(none - chain root)'));
    lines.push('issued: '+t.issued_at+' · not before: '+t.not_before+' · expires: '+t.expires_at);
    lines.push('signature: '+((t.signature_present&&t.signature_prefix)||'MISSING'));
    if(t.pq_signature_present!==undefined)lines.push('pq signature present: '+(!!t.pq_signature_present));
    lines.push('constraints: '+JSON.stringify(t.constraints));
    if(t.narrowed)lines.push('narrowed from parent: '+t.narrowed.join('; '));
  });
  lines.push('');
  lines.push('Simulated capability chains: minted live by the gateway real issuer over simulated calls. Verify runs the real capability gate.');
  view.textContent=lines.join('\\n');
}
function capDemoVerify(){
  if(!capDemoData||!capDemoData.calls||!capDemoData.calls.length){alert('Pick a simulated capability call first');return;}
  const picked=window.__capDemoSelectedId;
  const call=picked?(capDemoData.calls.find(c=>c.id===picked)||capDemoData.calls[0]):capDemoData.calls[0];
  const view=document.getElementById('capEnvelopeView');
  view.textContent='Running the real gate (CapabilityGate.check)…';
  api('/api/demo/capabilities/'+encodeURIComponent(call.id)+'/verify',{method:'POST'}).then(r=>r.ok?r.json():r.json().then(d=>{throw new Error((d.detail||'verification failed'));})).then(d=>{
    const lines=[
      'verdict: '+d.decision.verdict,
      'reason: '+d.decision.reason,
      'chain walked: '+d.chain.join(' -> '),
      'expectation: '+d.expectation,
      '',
      'tamper probe (simulated tamper: one constraint value altered in memory):'
    ];
    lines.push('verdict: '+d.tamper_probe.verdict+' · reason: '+d.tamper_probe.reason);
    lines.push('','fail-closed check: a tampered token must never pass the signature stage.');
    lines.push('',d.note);
    view.textContent=lines.join('\\n');
  }).catch(err=>{view.textContent='Verification failed: '+err.message;});
}
// ================= RECEIPT SIGNING KEY FAMILY (E2) =================
function loadKeyFamily(){
  const c=document.getElementById('rcpt-keyfamily'); if(!c) return;
  c.style.display='block';
  const v=document.getElementById('keyFamilyView');
  if(!v.textContent)v.textContent='Reading the live signer configuration…';
  api('/api/receipts/key-family').then(r=>r.ok?r.json():null).then(d=>{
    if(!d){v.textContent='Key family unavailable.';return;}
    v.textContent=[
      'signer backend: '+d.signer_backend,
      'signing key id: '+d.key_id,
      'key material type: '+d.issuer_key_type,
      'ML-DSA-65 (quantum-ready) available: '+(d.pq_available?'yes':'no'),
      'observed on stored receipts: classical '+((d.observed_families||{})['classical-ed25519']??0)+', pq1 hybrid '+((d.observed_families||{})['pq1-hybrid']??0),
      '',
      'The badge on a receipt row comes from that receipt own signed header; receipts whose material cannot be confirmed carry no badge.'
    ].join('\\n');
  });
}
function loadKeyModel(){
  const c=document.getElementById('rcpt-keymodel'); if(!c) return;
  c.style.display='block';
  const v=document.getElementById('keyModelView');
  if(!v.textContent)v.textContent='Reading the live signer configuration…';
  api('/api/demo/key-model').then(r=>r.ok?r.json():r.json().then(d=>{throw new Error(d.detail||'not loaded');})).then(d=>{
    const fam=d.observed_signature_families_on_receipts||{};
    const lines=[
      d.note,
      '',
      'signer backend: '+d.signer_backend,
      'receipt-signing key id: '+d.receipt_signing_key_id,
      'key material type: '+d.key_material_type,
      'gate identity: '+d.agent_id,
      'enrolment checks (re-run from the statement bytes):',
      '  key id binds to the key material: '+(d.gate_enrolment.key_id_binds_to_key_material?'yes':'NO - see endpoint response'),
      '  statement signature verifies: '+(d.gate_enrolment.identity_statement_signature_verified?'yes':'NO - see endpoint response'),
      'ML-DSA-65 (quantum-ready) available: '+(d.ml_dsa_available?'yes':'no'),
      'observed signature families on receipts: classical '+(fam['classical-ed25519']??0)+', pq1 hybrid '+(fam['pq1-hybrid']??0),
      '',
      'Key export posture: '+d.key_export_posture.key_material_location,
      '',
      'Rotation story, from the deployed code:'
    ];
    (d.rotation_story||[]).forEach(r=>{
      lines.push('  '+r.layer);
      lines.push('    functions: '+r.functions);
      lines.push('    '+r.story);
    });
    lines.push('','The rotation procedures are documented in the key-operations runbook and pinned by the key-rotation end-to-end test.');
    v.textContent=lines.join('\\n');
  }).catch(err=>{ v.textContent='Key model unavailable: '+err.message; });
}
// ================= ASSURANCE PACKET (G3, demo-only, read-only) =================
function loadAssurancePacket(){
  const v=document.getElementById('assurancePacketView'); if(!v) return;
  v.textContent='Assembling the packet in a disposable sandbox…';
  api('/api/demo/assurance-packet').then(r=>r.ok?r.json():r.json().then(d=>{throw new Error(d.detail||'not loaded');})).then(d=>{
    const lines=[
      d.note,
      '',
      d.boundary,
      '',
      'receipts in the packed chain: '+d.receipts+(d.truncated?' (bounded: showing the most recent records only)':'')
    ];
    if(!d.receipts){ v.textContent=lines.join('\\n'); return; }
    lines.push('');
    lines.push('PACK members (content-addressed, from the built index):');
    (d.index.members||[]).forEach(m=>lines.push('  '+m.role+'  '+m.path+'  sha256 '+m.sha256));
    lines.push('','packed kind: '+d.pack_kind+' · members: '+d.index.member_count+(d.index.audit_key_id?(' · pack signer key id: '+d.index.audit_key_id):''));
    const ih=d.manifest.input_hashes||{};
    lines.push('');
    lines.push('Manifest sha-pinned inputs:');
    if(ih.chain_sha256)lines.push('  chain: '+ih.chain_sha256);
    Object.keys(ih.public_keys||{}).forEach(k=>lines.push('  public key '+k+': '+ih.public_keys[k]));
    Object.keys(ih.capability_statements||{}).forEach(k=>lines.push('  statement '+k+': '+ih.capability_statements[k]));
    lines.push('  tool version: '+(d.manifest.tool_version||'')+' · generated_at: '+d.generated_at);
    const cv=d.manifest.chain_verdict||{};
    lines.push('');
    lines.push('Manifest chain verdict: valid='+(cv.valid===true?'true':'false')+', receipts='+cv.receipt_count);
    const av=d.offline_verdict||{};
    lines.push('');
    lines.push('Offline verification (the pack verifies alone, no network):');
    lines.push('  ok: '+(av.ok===true?'true':(av.ok===false?'false':''))+' · integrity: '+av.integrity_ok+' · manifest signature: '+av.manifest_signature_ok);
    lines.push('  chain valid: '+av.chain_valid+' · reproducible: '+av.reproducible+' · index signature: '+av.index_signature_ok);
    ((av.reasons)||[]).forEach(x=>lines.push('  - '+x));
    const fam=d.signing_families||{};
    lines.push('','signature families this deployment produces: classical '+(fam['classical-ed25519']??0)+', pq1 hybrid '+(fam['pq1-hybrid']??0)+', other '+(fam.other??0));
    v.textContent=lines.join('\\n');
  }).catch(err=>{ v.textContent='Assurance packet unavailable: '+err.message; });
}
function loadSIEM(){if(typeof demoMode!=='undefined'&&demoMode){loadDemoSIEM();return;}api('/api/siem').then(r=>r.json()).then(d=>{document.getElementById('siemEnabled').checked=d.enabled;document.getElementById('siemBackend').value=d.backend||'';document.getElementById('siemUrl').value=d.url||'';});}
function saveSIEM(){api('/api/siem',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled:document.getElementById('siemEnabled').checked,backend:document.getElementById('siemBackend').value,url:document.getElementById('siemUrl').value,token:document.getElementById('siemToken').value})}).then(r=>r.json()).then(d=>alert('Saved'));}
function loadUsers(){if(typeof demoMode!=='undefined'&&demoMode){loadDemoUsers();return;}api('/api/users').then(r=>r.json()).then(d=>{let tb=document.getElementById('userTableBody');tb.innerHTML='';d.users.forEach(u=>{const uid=esc(u.user_id||'');tb.innerHTML+=`<tr><td>${esc(u.user_id||'')}</td><td>${esc(u.api_key_label||'')}</td><td>${esc(u.role)}</td><td>${esc(u.name||'')}</td><td>${u.mfa_enabled?'<span style="color:#22c55e;font-size:12px">Enabled</span>':'<span style="color:#a3a3a3;font-size:12px">Off</span>'}</td><td><button class="btn btn-secondary" style="padding:4px 10px;font-size:11px" data-user-id="${uid}" data-hi="userMfaAction(event,'setup')">Setup MFA</button>${u.mfa_enabled?` <button class="btn btn-secondary" style="padding:4px 10px;font-size:11px" data-user-id="${uid}" data-hi="userMfaAction(event,'disable')">Disable</button>`:''}</td></tr>`;});});}
function addUser(){api('/api/users',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({api_key:document.getElementById('newKey').value,role:document.getElementById('newRole').value,name:document.getElementById('newName').value})}).then(r=>r.json()).then(d=>{alert('Added');loadUsers();});}
let mfaSetupKey='';
function setupMfa(key){
  mfaSetupKey=key;
  api(`/api/users/${encodeURIComponent(key)}/mfa/setup`,{method:'POST'}).then(r=>r.json()).then(d=>{
    if(d.status==='ok'){
      document.getElementById('mfaSetupCard').classList.remove('hidden');
      document.getElementById('mfaSecret').textContent=d.secret;
      document.getElementById('mfaUri').textContent=d.uri;
      // Generate QR code using Google Charts API fallback to text display
      const qrUrl=`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(d.uri)}`;
      document.getElementById('mfaQrCode').innerHTML=`<img src="${esc(qrUrl)}" width="200" height="200" style="border-radius:8px;border:1px solid #e5e5e5" alt="QR Code for TOTP setup" />`;
      document.getElementById('mfaCodeInput').value='';
      document.getElementById('mfaCodeInput').focus();
    } else { alert('MFA setup failed: '+(d.detail||'unknown')); }
  });
}
function confirmMfa(){
  const code=document.getElementById('mfaCodeInput').value;
  if(!code||code.length!==6){alert('Enter the 6-digit code from your authenticator app');return;}
  api(`/api/users/${encodeURIComponent(mfaSetupKey)}/mfa/verify?code=${code}`,{method:'POST'}).then(r=>{if(!r.ok){return r.json().then(d=>{throw new Error(d.detail||'Invalid code');});}return r.json();}).then(d=>{
    alert('MFA enabled successfully! You will need a TOTP code for future logins.');
    document.getElementById('mfaSetupCard').classList.add('hidden');
    loadUsers();
  }).catch(e=>alert('MFA verification failed: '+e.message));
}
function disableMfa(key){
  if(!confirm('Disable MFA for this user?'))return;
  api(`/api/users/${encodeURIComponent(key)}/mfa/disable`,{method:'POST'}).then(r=>r.json()).then(d=>{alert('MFA disabled');loadUsers();});
}
function loadConfig(){if(typeof demoMode!=='undefined'&&demoMode){loadDemoConfig();return;}api('/api/config').then(r=>r.json()).then(d=>{
  // Populate form fields
  const fields=['host','port','admin_port','signer_backend','kms_key_id','kms_region','policy_file','policy_dir','receipt_store','audit_chain','audit_log_file','siem_backend','siem_url','compliance_framework','registry_path'];
  fields.forEach(f=>{const el=document.getElementById('cfg-'+f);if(el&&d[f]!==undefined)el.value=d[f];});
  const checks=['audit_persist'];
  checks.forEach(f=>{const el=document.getElementById('cfg-'+f);if(el&&d[f]!==undefined)el.checked=d[f];});
  // Clear password fields (don't show existing secrets)
  document.getElementById('cfg-siem_token').value='';
  document.getElementById('cfg-health_check_token').value='';
  document.getElementById('configStatus').textContent='';
  // Also show raw YAML for reference
  document.getElementById('configView').textContent=JSON.stringify(d,null,2);
  document.getElementById('configView').style.display='block';
});}
function saveConfig(){
  const body={};
  const fields=['host','port','admin_port','signer_backend','kms_key_id','kms_region','policy_file','policy_dir','receipt_store','audit_chain','audit_log_file','siem_backend','siem_url','compliance_framework','registry_path'];
  fields.forEach(f=>{const el=document.getElementById('cfg-'+f);if(el&&el.value!=='')body[f]=el.value;});
  body['audit_persist']=document.getElementById('cfg-audit_persist').checked;
  const st=document.getElementById('cfg-siem_token').value;
  if(st)body['siem_token']=st;
  const ht=document.getElementById('cfg-health_check_token').value;
  if(ht)body['health_check_token']=ht;
  api('/api/config',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).then(r=>r.json()).then(d=>{
    const status=document.getElementById('configStatus');
    if(d.status==='ok'){
      status.style.color='#22c55e';
      status.textContent=`Saved: ${d.changed.length} fields changed. File: ${d.message}`;
      if(d.restart_needed){
        status.textContent+=' - Restart needed for host/port/signer changes.';
        status.style.color='#e5b85c';
      }
    } else if(d.status==='partial'){
      status.style.color='#e5b85c';
      status.textContent=`Partial: ${d.warning}`;
    } else {
      status.style.color='#ef4444';
      status.textContent='Error: '+JSON.stringify(d);
    }
  });
}

// ================= DEMO OPERATIONS (Users / SIEM / Config demo views) =================
// textContent-only rendering over the read-only /api/demo/* endpoints: the
// demo tabs never touch the operator mutation routes and never build markup
// from response data.
function loadDemoUsers(){
  const tb=document.getElementById('demoUserTableBody');
  const card=document.getElementById('demoUsersCard');
  card.classList.remove('hidden');
  api('/api/demo/users').then(r=>{
    if(r.status===404){tb.textContent='';const tr=document.createElement('tr');const tdEl=document.createElement('td');tdEl.colSpan=3;tdEl.style.color='#a3a3a3';tdEl.textContent='Demo mode is not configured on this deployment.';tr.appendChild(tdEl);tb.appendChild(tr);return null;}
    return r.json();
  }).then(d=>{
    if(!d)return;
    // Reset at render time: showTab dispatches each loader twice, so an
    // async render must stay idempotent.
    tb.textContent='';
    (d.users||[]).forEach(u=>{
      const tr=document.createElement('tr');
      const name=document.createElement('td');name.textContent=u.name||u.user_id||'';
      const role=document.createElement('td');role.textContent=u.role||'';
      const mfa=document.createElement('td');
      const span=document.createElement('span');span.style.fontSize='12px';
      if(u.mfa_enabled){span.style.color='#22c55e';span.textContent='Enabled (TOTP)';}
      else{span.style.color='#e5b85c';span.textContent='API key only';}
      mfa.appendChild(span);
      tr.appendChild(name);tr.appendChild(role);tr.appendChild(mfa);
      tb.appendChild(tr);
    });
    if(!(d.users||[]).length){const tr=document.createElement('tr');const tdEl=document.createElement('td');tdEl.colSpan=3;tdEl.textContent='No operators in the simulated roster.';tr.appendChild(tdEl);tb.appendChild(tr);}
  }).catch(()=>{});
}
function loadDemoSIEM(){
  api('/api/demo/siem').then(r=>{
    if(r.status===404){document.getElementById('demoSiemConfigured').textContent='Demo mode is not configured on this deployment.';return null;}
    return r.json();
  }).then(d=>{
    if(!d)return;
    document.getElementById('demoSiemCard').classList.remove('hidden');
    const conf=d.configured||{};
    const state=conf.enabled?'SIEM forwarding is enabled on this deployment.':'SIEM forwarding is not currently enabled; the signed evidence chain stays local and nothing is forwarded.';
    const parts=['Backend: '+(conf.backend||'(none configured)'),'Endpoint: '+(conf.url||'(none configured)'),'Credential on file: '+(conf.token_configured?'yes':'no')+' (never displayed)','Undelivered events buffered: '+String(conf.buffered_events!=null?conf.buffered_events:0)];
    document.getElementById('demoSiemConfigured').textContent=state;
    document.getElementById('demoSiemTarget').textContent=parts.join('   ·   ');
    const sim=d.simulated||{};
    document.getElementById('demoSiemWindow').textContent=(sim.window_note||'')+' Total events in the window: '+escn(sim.events_forwarded_total||0)+'.';
    const sample=sim.event_sample||{};
    document.getElementById('demoSiemSample').textContent=JSON.stringify(sample,null,2);
    const body=document.getElementById('demoSiemEvents');body.textContent='';
    (sim.activity||[]).forEach(b=>{
      const tr=document.createElement('tr');
      const hour=document.createElement('td');hour.textContent=b.label||'';
      const events=document.createElement('td');events.textContent=escn(b.events||0);
      const batches=document.createElement('td');batches.textContent=String(b.batches!=null?b.batches:'-');
      const status=document.createElement('td');status.textContent=b.status||'';
      tr.appendChild(hour);tr.appendChild(events);tr.appendChild(batches);tr.appendChild(status);
      body.appendChild(tr);
    });
  }).catch(()=>{});
}
function loadDemoConfig(){
  api('/api/demo/config').then(r=>{
    if(r.status===404){document.getElementById('demoConfigView').textContent='Demo mode is not configured on this deployment.';return null;}
    return r.json();
  }).then(d=>{
    if(!d)return;
    document.getElementById('demoConfigCard').classList.remove('hidden');
    const view=document.getElementById('demoConfigView');view.textContent='';
    (d.profile||[]).forEach(row=>{
      const line=document.createElement('div');
      const v=row.value;
      line.textContent=(row.label||'')+': '+(v===''||v===null||v===undefined?'(not set)':String(v));
      view.appendChild(line);
    });
  }).catch(()=>{});
}

// ================= DEMO COVERAGE (assurance receipted-share view) =================
// textContent-only rendering over the read-only /api/demo/coverage endpoint:
// the contract legend, the computed buckets and the per-tool / per-agent
// rollups render as text nodes, never as markup built from response data.
function loadDemoCoverage(){
  const unavailable=document.getElementById('demoCoverageUnavailable');
  const card=document.getElementById('rcptCoverageCard');
  card.classList.remove('hidden');
  api('/api/demo/coverage').then(r=>{
    if(r.status===404){unavailable.textContent='Demo mode is not configured on this deployment.';return null;}
    return r.json();
  }).then(d=>{
    if(!d)return;
    document.getElementById('demoCoverageBasis').textContent=d.basis||'';
    unavailable.textContent=d.unavailable_note||'';
    const b=d.breakdown||{};
    const summary=document.getElementById('demoCoverageSummary');summary.textContent='';
    [['receipted_share', d.receipted_share==null?'unavailable (no receipts yet)':String(d.receipted_share)],
     ['receipted', b.receipted==null?0:b.receipted],
     ['out_of_gate', (b.out_of_gate==null?0:b.out_of_gate)+' — disclosed, not computed at the gate vantage'],
     ['pending', (b.pending==null?0:b.pending)+' — disclosed: every stored receipt is terminal'],
     ['total', b.total==null?0:b.total]].forEach(function(pair){
      const line=document.createElement('div');
      line.textContent=pair[0]+': '+String(pair[1]);
      summary.appendChild(line);
    });
    fillCoverageRollup('demoCoverageTools', d.by_tool||{});
    fillCoverageRollup('demoCoverageAgents', d.by_agent||{});
    const legend=document.getElementById('demoCoverageLegend');legend.textContent='';
    ((d.contract||{}).buckets||[]).forEach(function(bk){
      const line=document.createElement('div');
      line.style.marginBottom='4px';
      line.textContent=bk.bucket+' — '+bk.definition+' At this vantage: '+bk.at_this_vantage;
      legend.appendChild(line);
    });
    ((d.contract||{}).flags||[]).forEach(function(f){
      const line=document.createElement('div');
      line.style.marginBottom='4px';
      line.textContent=f.flag+' — '+f.semantics+' '+f.vantage_note;
      legend.appendChild(line);
    });
    document.getElementById('demoCoverageFlagsNote').textContent='Flags are stated read-only above: none are computed at the gate-side vantage, and no zero is claimed where cross-vantage evidence is absent. Cross-vantage reconciliation is the assurance receipted-share view; the demo numbers stay within the receipt stream this panel already holds.';
  }).catch(()=>{});
}
function fillCoverageRollup(tbodyId, rollups){
  const tb=document.getElementById(tbodyId);if(!tb)return;
  tb.textContent='';
  const names=Object.keys(rollups).sort();
  if(!names.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=6;td.style.color='#a3a3a3';td.textContent='No gate receipts in the demo window yet.';tr.appendChild(td);tb.appendChild(tr);return;}
  names.forEach(function(name){
    const r=rollups[name]||{};
    const tr=document.createElement('tr');
    [name, r.receipted==null?0:r.receipted, r.out_of_gate==null?0:r.out_of_gate, r.pending==null?0:r.pending, r.total==null?0:r.total, r.receipted_share==null?'—':String(r.receipted_share)].forEach(function(cell){
      const td=document.createElement('td');td.textContent=String(cell);tr.appendChild(td);
    });
    tb.appendChild(tr);
  });
}
function loadCoverage(){if(typeof demoMode!=='undefined'&&demoMode){loadDemoCoverage()}}

setInterval(()=>{if(!document.getElementById('main').classList.contains('hidden')&&!document.getElementById('tab-dashboard').classList.contains('hidden'))loadStats();},5000);
window.addEventListener('resize',()=>{if(!document.getElementById('tab-connections').classList.contains('hidden'))drawFlowLines(getFiltered());});

// ================= DEMO FINDINGS (EPIC D screens) =================
// textContent-only rendering: every DOM write for these screens goes through
// createElement/textContent, so no injected demo text can become markup.
let demoFindings = null;
function loadDemoFindings() {
  const p = demoScenarioFilter && demoScenarioFilter !== 'all' ? demoScenarioFilter : 'all';
  api('/api/demo-findings?scenario=' + encodeURIComponent(p)).then(r => r.json()).then(d => {
    demoFindings = d;
    renderInjectionScreen(d);renderShadowScreen(d);
  }).catch(() => {});
}
function findingsRows(tbodyId, headers, rowsGetter, emptyLabel) {
  // shared textContent table builder for the findings screens
  const tb = document.getElementById(tbodyId);
  if (!tb) return;
  tb.textContent = '';
  const rows = rowsGetter();
  if (!rows.length) {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.colSpan = headers.length;
    td.textContent = emptyLabel || 'No findings for this scenario';
    td.style.color = '#8b919e';
    tr.appendChild(td);tb.appendChild(tr);return;
  }
  rows.forEach(cells => {
    const tr = document.createElement('tr');
    cells.forEach(v => {
      const td = document.createElement('td');
      td.textContent = String(v === undefined || v === null ? '' : v);
      tr.appendChild(td);
    });
    tb.appendChild(tr);
  });
}
function findingsStats(gridId, entries) {
  const g = document.getElementById(gridId);
  if (!g) return;
  g.textContent = '';
  entries.forEach(([label, val]) => {
    const s = document.createElement('div');s.className = 'stat';
    const sv = document.createElement('div');sv.className = 'stat-value';sv.textContent = String(val === undefined || val === null ? 0 : val);
    const sl = document.createElement('div');sl.className = 'stat-label';sl.textContent = String(label || '');
    s.appendChild(sv);s.appendChild(sl);g.appendChild(s);
  });
}
function whereLabel(f) { return f.kind === 'agent_text' ? 'Agent text' : 'Tool output'; }
function renderInjectionScreen(d) {
  const fs = (d.injection || {}).findings || [];
  findingsStats('injSummary', [['Findings', fs.length], ['Denied', fs.filter(f => f.decision === 'deny').length], ['Escalated', fs.filter(f => f.decision === 'escalate').length]]);
  findingsRows('injTableBody', 7, () => fs.map(f => [f.agent, f.tool, whereLabel(f), f.score, f.category, f.decision, f.reason]));
}
function renderShadowScreen(d) {
  const fs = (d.shadow || {}).findings || [];
  const kinds = {unknown_model: 0, unapproved_endpoint: 0, byok_attempt: 0};
  fs.forEach(f => { if (kinds[f.kind] !== undefined) kinds[f.kind]++; });
  findingsStats('shadowSummary', [['Findings', fs.length], ['Unknown models', kinds.unknown_model], ['Unapproved endpoints', kinds.unapproved_endpoint], ['Key attempts', kinds.byok_attempt]]);
  findingsRows('shadowTableBody', 5, () => fs.map(f => [f.agent, f.tool, f.kind.replace(/_/g, ' '), f.detail, f.policy_response]));
}

// ================= DEMO MODE =================
const DEMO_SCENARIOS = ['banking', 'government', 'health', 'capability'];
// Tool-name signature per demo scenario (D6). capability: PII/DLP, prompt
// injection, shadow AI and MCP registry traffic fed by the demo generator.
function demoToolMap(){
  return {
    banking:['lookup_balance','transfer_internal','transfer_external','block_card','increase_card_limit','check_loan_status','create_loan_application','file_sar','check_sanctions','unblock_card','lookup_transaction_history'],
    government:['check_benefit_entitlement','lookup_payment_history','schedule_benefit_payment','flag_fraud_suspected','lookup_tax_account','calculate_tax_estimate','submit_self_assessment','retrieve_planning_application','update_case_notes','recommend_decision','check_immigration_status','request_dbs_check','search_foi_register','draft_foi_response'],
    health:['read_patient_record','write_patient_note','prescribe_medication','prescribe_controlled','order_imaging','view_imaging_result','order_lab_test','review_lab_results','triage_assessment','export_patient_summary','book_appointment','cancel_appointment'],
    capability:['redact_document','classify_text','check_dlp_policy','export_analytics','bulk_export_records','screen_user_message','flag_injection_attempt','execute_shell','send_email','audit_ai_usage','list_approved_models','invoke_unapproved_model','forward_external_llm','list_mcp_tools','invoke_mcp_tool','fetch_mcp_manifest']
  };
}
// ================= SESSION BEHAVIOUR (Q2 demo plane) =================
// Renderers over the read-only /api/demo/session-* endpoints: every
// response-sourced value passes through esc/escn into innerHTML, so
// hostile strings can never become markup.
function loadSessionPanel(){loadSessionRules();loadSessionWindows();loadSessionFindings();}
function loadSessionRules(){
  api('/api/demo/session-rules').then(function(r){
    if(r.status===404){document.getElementById('sessionRulesBody').innerHTML=esc('Demo mode is not configured on this deployment.');return null;}
    return r.json();
  }).then(function(d){
    if(!d)return;
    let out='';
    if(d.config_error){out+='<div>'+esc('CONFIG ERROR (fail-closed): '+d.config_error)+'</div>';}
    (d.session_rules||[]).forEach(function(rl){
      out+='<div>'+esc(rl.id+' - '+rl.kind+' ('+(rl.threshold!==undefined&&rl.threshold!==null?'threshold '+rl.threshold+', ':'')+'window '+rl.window_seconds+'s'+((rl.tool_patterns&&rl.tool_patterns.length)?', tools '+rl.tool_patterns.join(','):'')+') '+(d.deny_only?'deny-only (v1)':'')+')')+'</div>';
    });
    if(d.window){out+='<div>'+esc('window state bound: ttl '+d.window.ttl_seconds+'s, max keys '+d.window.max_keys+', max entries '+d.window.max_entries)+'</div>';}
    (d.limits||[]).forEach(function(l){out+='<div>'+esc('honest limit: '+l)+'</div>';});
    document.getElementById('sessionRulesBody').innerHTML=out;
  }).catch(function(){document.getElementById('sessionRulesBody').innerHTML=esc('unavailable');});
}
function loadSessionWindows(){
  api('/api/demo/session-windows').then(function(r){
    if(r.status===404){document.getElementById('sessionWindowsBody').innerHTML=esc('Demo mode is not configured on this deployment.');return null;}
    return r.json();
  }).then(function(d){
    if(!d)return;
    if(d.available===false){
      document.getElementById('sessionWindowsBody').innerHTML='<div>'+esc(d.unavailable_note||'receipt index unavailable; windows are never fabricated')+'</div>';
      return;
    }
    let out='';
    const wins=d.sessions||[];
    if(!wins.length){out+='<div>'+esc('no active windows (available only after demo traffic declares a session id)')+'</div>';}
    wins.forEach(function(w){
      const agents=(w.agents||[]).join(',')||'-';
      out+='<div>'+esc(String(w.session_id).slice(0,18)+' - agents '+agents+' - receipts '+w.receipts+' (allows '+w.allows+', denies '+w.denies+', escalates '+w.escalates+')')+'</div>';
    });
    document.getElementById('sessionWindowsBody').innerHTML=out;
  }).catch(function(){document.getElementById('sessionWindowsBody').innerHTML=esc('unavailable');});
}
function loadSessionFindings(){
  api('/api/demo/session-findings').then(function(r){
    if(r.status===404){document.getElementById('sessionFindingsBody').innerHTML=esc('Demo mode is not configured on this deployment.');return null;}
    return r.json();
  }).then(function(d){
    if(!d)return;
    let out='';
    const fs=d.findings||[];
    if(!fs.length){out+='<div>'+esc('no session-monitor findings yet')+'</div>';}
    fs.forEach(function(f){
      out+='<div>'+esc(f.test_id+' - '+f.verdict+' - tool '+f.tool+' - cited receipt '+(f.cited_receipt||'')+' - '+(f.receipt_hash||''))+' <button class="btn btn-secondary" data-hi="sessionFindingVerify(event)" data-receipt="'+esc(f.receipt_hash||'')+'" data-cited="'+esc(f.cited_receipt||'')+'">Verify offline</button></div>';
    });
    document.getElementById('sessionFindingsBody').innerHTML=out;
  }).catch(function(){document.getElementById('sessionFindingsBody').innerHTML=esc('unavailable');});
}
function sessionFindingVerify(ev, el){
  const body=document.getElementById('sessionFindingsBody');
  const hash=(el&&el.getAttribute)?(el.getAttribute('data-receipt')||''):'';
  const cited=el&&el.getAttribute?el.getAttribute('data-cited'):null;
  if(!hash){body.innerHTML+='<div>'+esc('no receipt selected; use a finding row button')+'</div>';return;}
  body.innerHTML+='<div>'+esc('offline verify running for '+(cited||hash))+'</div>';
  api('/api/demo/session-findings/'+encodeURIComponent(hash)+'/offline-verify',{method:'POST'}).then(function(r){
    const status=r.status;
    return r.json().then(function(d){return {status:status, d:d};});
  }).then(function(res){
    let line='verifier responded '+res.status+'; disclosed rather than fabricated.';
    if(res.status===200 && res.d && res.d.verdict==='valid'){
      line='VERIFIED OFFLINE: the finding and its cited gate receipt verify through the real ProvenanceVerifier.';
    } else if(res.status===422){
      line='VERIFICATION FAILED (honest): the verifier rejected the chain; disclosed, never hidden.';
    } else if(res.status===404){
      line='UNAVAILABLE: the finding or its cited receipt is not in this chain.';
    } else if(res.status===401||res.status===403){
      line='AUTH REQUIRED: the verifier needs a signed-in session; the offline-verify card on the Receipts tab shows the same mechanism.';
    }
    body.innerHTML+='<div>'+esc(line)+'</div>';
  }).catch(function(){
    body.innerHTML+='<div>'+esc('verifier unreachable; nothing was claimed verified.')+'</div>';
  });
}
// ================= DATA PROTECTION (D2 demo plane) =================
// Renderers over the read-only /api/demo/dlp-findings endpoint: every
// response-sourced value rides esc() into innerHTML or the shared
// textContent-only table builder, so hostile strings can never become
// markup. The rows show digests, class names and counts only: the
// values behind them never reach this surface.
function loadDlpPanel(){loadDlpFindings();}
function dshort(v){v=String(v||'');return v.length>22?v.slice(0,22)+'...':v;}
function collarSpans(f){return (f.matched_classes||[]).map(function(c){return '[REDACTED:'+c+'] x'+((f.span_counts||{})[c]||0);}).join(', ');}
function loadDlpFindings(){
  api('/api/demo/dlp-findings').then(function(r){
    if(r.status===404){document.getElementById('dlpFindingsBody').innerHTML=esc('Demo mode is not configured on this deployment.');return null;}
    return r.json();
  }).then(function(d){
    if(!d)return;
    if(d.available===false){document.getElementById('dlpFindingsBody').innerHTML='<div>'+esc(d.unavailable_note||'x_dlp findings unavailable; never fabricated')+'</div>';return;}
    findingsStats('dlpSummary', [['Scans', d.count], ['Advisory findings', d.advisory_findings||0], ['Pattern classes', Object.keys(d.by_class||{}).length]]);
    let out='';
    const byClass=d.by_class||{};
    Object.keys(byClass).sort().forEach(function(cls){out+='<div>'+esc('[REDACTED:'+cls+'] x'+byClass[cls])+'</div>';});
    if(!out){out='<div>'+esc(d.empty_note||'no x_dlp receipts yet')+'</div>';}
    document.getElementById('dlpFindingsBody').innerHTML=out;
    findingsRows('dlpTableBody', 9, () => (d.findings||[]).map(f => [dshort(f.scan_id), dshort((f.route||{}).source)+' -> '+dshort((f.route||{}).destination), collarSpans(f), f.action, f.rule_id, dshort(f.content_sha256), dshort(f.redacted_content_sha256), dshort(f.cited_receipt), dshort(f.receipt_hash)]), 'No x_dlp receipts yet: findings appear when demo traffic carries the canned patterns.');
  }).catch(function(){document.getElementById('dlpFindingsBody').innerHTML=esc('unavailable');});
}
// The threats lens (D6, cross-cutting): keep only the attack-relevant
// decisions - denied and escalated calls - across every scenario.
function threatsLens(conns){ return conns.filter(c=>c.decision==='deny'||c.decision==='escalate'); }
let demoMode = false;
let topoNodes = [], topoEdges = [], topoSelected = null, topoConns = [];
let topoHoverLoop = null, topoDenyLoops = [];

async function fetchDemoKey() {
  // The server exposes the read-only demo key (no other secrets)
  try {
    const r = await fetch('/api/demo-key');
    if (r.ok) { const d = await r.json(); return d.demo_key || ''; }
  } catch (e) {}
  return '';
}

async function enterDemo() {
  const dk = await fetchDemoKey();
  if (!dk) { alert('Demo is not configured on this deployment. Set RAUCLE_DEMO_KEY.'); return; }
  key = dk;
  totpCode = '';
  demoMode = true;
  document.body.classList.add('demo');
  document.getElementById('login').classList.add('hidden');
  document.getElementById('main').classList.remove('hidden');
  document.getElementById('demoBanner').classList.remove('hidden');
  buildScenarioPicker();
  showMainDemo();
  tourMaybeStart();
}
// ?demo=1 (or #demo) auto-enters demo mode after the page settles
window.addEventListener('load', () => {
  if (handleOidcCallback()) return;
  const q = new URLSearchParams(window.location.search);
  const h = window.location.hash || '';
  if (q.get('demo') === '1' || q.get('tour') === '1' || h.startsWith('#demo')) {
    const btn = document.getElementById('enterDemoBtn');
    if (btn) btn.click();
  }
  initSso();
});

function buildScenarioPicker() {
  const bar = document.getElementById('scenarioPicker');
  if (!bar) return;
  const mk = (label, val) => `<button class="scenario-btn${(demoScenarioFilter===val)?' active':''}" data-scenario="${esc(val)}" data-hi="scenarioClick(event)">${esc(label)}</button>`;
  let html = mk('All', 'all');
  DEMO_SCENARIOS.forEach(s => html += mk(s[0].toUpperCase()+s.slice(1), s));
  html += mk('Threats', 'threats');
  bar.innerHTML = html;
}

let demoScenarioFilter = 'all';
function setDemoScenario(v) { demoScenarioFilter = v; buildScenarioPicker(); loadConnections(); topoRefresh(); loadDemoFindings(); }
function scenarioClick(ev){
  const el=ev.currentTarget||ev.target.closest('[data-scenario]');
  if(el&&el.dataset.scenario)setDemoScenario(el.dataset.scenario);
}

function showMainDemo() {
  // Default to the connections tab where the live topology lives
  const connTab = document.querySelector('.tab[data-tab-id], .tab');
  document.querySelectorAll('.tab').forEach(x => {
    if (x.dataset.tabId === 'connections') x.click();
  });
  loadAll();
}

// ================= GUIDED TOUR =================
const TOUR_SEEN_KEY = 'raucle_demo_tour_done_v1';
let tourStep = 0, tourBox = null, tourTimer = null;
const TOUR_STEPS = [
  // Narrative arc (D17): enterprise overview, what the EE console shows
  // over OSS raucle, session monitoring catching a real runaway loop, DLP
  // receipts, receipt -> offline verify -> coverage, capability tokens
  // and PQ, compliance, then the honest EE-limits close.
  {tab:'dashboard', target:'#overviewGrid', title:'The enterprise overview',
   body:'One grid of everything the console manages. Every card carries a truth badge: OSS LIVE means real code running in this demo, OSS MACHINERY + EE VIEW means real OSS data shown through the Enterprise Edition shape, EE-ONLY means simulated and labelled because that surface is not built.'},
  {tab:'dashboard', target:'#enterpriseOverview', title:'EE running on raucle',
   body:'The stack underneath is the Apache-2.0 open-source raucle gateway: the enforcement, receipts and verifier you will see in these steps are the same code any buyer self-hosts. The console is the operator surface that sits on top.'},
  {tab:'session', target:'#sessionRulesCard', title:'Session monitoring: the runaway catch',
   body:'Demo traffic declares a session id, so multi-turn behaviour is provable: this rule set stops a runaway tool loop inside one session window, by threshold and window, deterministically and deny-only.'},
  {tab:'session', target:'#sessionFindingsCard', title:'The catch is receipted, verified offline',
   body:'Every session deny leaves a signed session-monitor finding citing the gate receipt that triggered it. The verify button runs the real ProvenanceVerifier over the minimal honest chain, with no contact with any operator.'},
  {tab:'dlp', target:'[data-tab-id="dlp"].tab', title:'DLP receipts from the real pattern engine',
   body:'Demo tool calls run through the OSS advisory redaction engine: when the canned synthetic patterns appear in a call, the matched spans are collared and the scan lands as a signed x_dlp receipt citing the gate receipt for that call.'},
  {tab:'dlp', target:'#dlpFindingsCard', title:'Bounded disclosure: digests, never values',
   body:'Each row pairs the original content digest with the redacted digest, so a third party can prove the outbound content differed without either side ever holding the values. Class names and span counts only: the scanned content never enters the receipt.'},
  {tab:'simulate', target:'[data-tab-id="simulate"].tab', title:'Policy simulate: test a change before you deploy',
   body:'The operator question the demo answers: what would THIS policy have done to the traffic actually served? Pick a preset tweak or paste a candidate, and the real engine replays the recorded window deterministically, with no wall clock in the signed result.'},
  {tab:'simulate', target:'#simTabResultCard', title:'The flippable diff, signed',
   body:'Current against candidate decisions, bounded to tools, agents and hashes: never argument values, never denial reasons. The receipt binds the candidate policy and the window by hash, and a validated change deploys through the editor path that re-verifies the signature.'},
  {tab:'receipts', target:'#rcptTable', title:'Every decision leaves a signed receipt',
   body:'Allows, denies, escalations and session findings alike: signed and content-addressed at the moment of decision, so the record cannot quietly change afterwards.'},
  {tab:'receipts', target:'#rcpt-offline', title:'Offline verify: no operator contact',
   body:'A receipt verifies here with no phone home: signatures and hash linkage re-checked on this machine. This is the property that makes the evidence portable and the trust path vendor-free.'},
  {tab:'receipts', target:'#rcptCoverageCard', title:'Coverage: the receipted-share metric',
   body:'One honest number over the demo receipt stream: what ran inside the gate plane versus disclosed gaps and pending windows. Gaps are disclosed, never folded into a claimed zero.'},
  {tab:'capdemo', target:'#capDemoList', title:'Capability tokens, attenuated live',
   body:'Pick a simulated capability call and the real issuer mints and narrows the token envelope; the verify button runs the genuine capability gate, so the outcomes are its actual decisions.'},
  {tab:'receipts', target:'#rcpt-keymodel', title:'The signing keys: enrolled, never exported',
   body:'Read from the live signer configuration: the backend, the key family, and the enrolment checks. Self-custody keys, post-quantum receipts, and private material never leaves the boundary.'},
  {tab:'assure', target:'#assurancePacketView', title:'Compliance: the assurance packet',
   body:'One click builds a real audit pack from the signed receipt chain, sha-pinned and verified offline. Framework crosswalks land where the regulation names them, in mapped-to language, never as compliance claims.'},
  {tab:'mcp', target:'#mcpManifestText', title:'Tool poisoning, caught before it runs',
   body:'Pick the seeded poisoned manifest or paste your own tool JSON and the real static analysis engine runs live: hidden instructions, injection phrases, rug-pull wording, planted keys and SSRF targets, each finding carrying its severity, location and evidence class. A static scan mints no receipt, and the findings never echo the payload.'},
  {tab:'dashboard', target:'#honestyBanner', title:'The honest close: what is EE-only',
   body:'Everything labelled EE-ONLY is simulated here because that surface is not built yet: the fleet multi-org view, SIEM targets and the classifier layer. What you watched catch a runaway loop was real raucle, today.'},
];
function tourShow(){
  const s=TOUR_STEPS[tourStep];
  if(!s){tourEnd(true);return;}
  document.querySelectorAll('.tab').forEach(x=>{if(x.dataset.tabId===s.tab)x.click();});
  setTimeout(()=>{
    const el=document.querySelector(s.target)||document.getElementById('tab-'+s.tab);
    if(!el){tourStep++;tourShow();return;}
    el.scrollIntoView({behavior:'smooth',block:'center'});
    const host=document.getElementById('tourHost');
    host.innerHTML=`<div class="tour-card" id="tourCard"></div>`;
    const spot=document.createElement('div');
    spot.className='tour-spot';
    const sb=el.getBoundingClientRect();
    spot.style.left=sb.left+'px';spot.style.top=sb.top+'px';spot.style.width=sb.width+'px';spot.style.height=sb.height+'px';
    host.insertBefore(spot,host.firstChild);
    positionTourCard(el);
  },220);
}
function positionTourCard(el){
  const s=TOUR_STEPS[tourStep];
  if(!s){return;}
  const r=el.getBoundingClientRect();
  let bx=Math.min(Math.max(r.left+r.width/2-160,12),window.innerWidth-332);
  let by=Math.max(r.bottom+12,12);
  if(by+170>window.innerHeight-12) by=Math.max(12,r.top-186);
  const host=document.getElementById('tourHost');
  const card=document.getElementById('tourCard');
  if(!card)return;
  card.style.left=bx+'px';card.style.top=by+'px';
  card.innerHTML=`
      <div class="tour-step">Step ${tourStep+1} of ${TOUR_STEPS.length} · ${esc(s.title)}</div>
      <div class="tour-body">${esc(s.body)}</div>
      <div class="tour-actions">
        <button class="tour-skip" data-hi="tourEnd(false)">Skip tour</button>
        <button class="tour-next" data-hi="tourNext()">${tourStep+1<TOUR_STEPS.length?'Next':'Start exploring'}</button>
      </div>
      <div class="tour-dots">${TOUR_STEPS.map((_,i)=>`<span class="${i===tourStep?'on':''}"></span>`).join('')}</div>
    </div>`;
  // keep the card anchored if the panel scrolls or resizes mid-step
  if(!window.__tourReposition){window.__tourReposition=true;window.addEventListener('resize',()=>{const c=document.getElementById('tourCard');if(!c)return;const s=TOUR_STEPS[tourStep];const el2=s&&(document.querySelector(s.target)||document.getElementById('tab-'+s.tab));if(el2)positionTourCard(el2);});}
  window.addEventListener('scroll',()=>{const c=document.getElementById('tourCard');if(!c)return;const s=TOUR_STEPS[tourStep];const el2=s&&(document.querySelector(s.target)||document.getElementById('tab-'+s.tab));if(el2)positionTourCard(el2);},{passive:true});
}
function tourNext(){tourStep++;tourShow();}
function tourEnd(seen){
  clearTimeout(tourTimer);tourStep=0;
  const host=document.getElementById('tourHost');if(host)host.innerHTML='';
  try{localStorage.setItem(TOUR_SEEN_KEY,seen?'1':'1');}catch(e){}
}
function tourMaybeStart(){
  let force = false;
  try { force = new URLSearchParams(window.location.search).get('tour') === '1'; } catch(e) {}
  if (force) { try{localStorage.removeItem(TOUR_SEEN_KEY);}catch(e){} }
  let done=false;
  try{done=localStorage.getItem(TOUR_SEEN_KEY)==='1';}catch(e){}
  if(done)return;
  tourStep=0;tourShow();
}
function tourRestart(){try{localStorage.removeItem(TOUR_SEEN_KEY);}catch(e){}tourStep=0;tourShow();}

// ================= EMBEDDED LIVE TOPOLOGY =================
// Hero palette: ink #171717, green #22c55e, deny red #dd6b78, warn #e5b85c,
// neutral #8b919e. Glow loops (hero-style) appear on node hover and around
// deny sources when deny filtering is active.
const TOPO_COL_X = { source: 40, policy: 400, destination: 760 };
const TOPO_NODE_H = 60, TOPO_NODE_GAP = 22, TOPO_W = 190;

function topoEdgeColor(decision) {
  if (decision === 'allow') return '#22c55e';
  if (decision === 'deny') return '#dd6b78';
  if (decision === 'escalate') return '#e5b85c';
  return '#171717';
}

function topoFilterConns(conns) {
  let out = conns;
  const df = document.getElementById('topoDecisionFilter')?.value || '';
  if (df) out = out.filter(c => c.decision === df);
  if (demoScenarioFilter !== 'all') {
    out = out.filter(c => {
      // Scenario inference: policy file name or tool name carries the scenario signature
      const pol = (c.policy || '').toLowerCase();
      const tools = demoToolMap();
      if (demoScenarioFilter === 'threats') return c.decision === 'deny' || c.decision === 'escalate';
      return (tools[demoScenarioFilter] || []).includes(c.tool) || pol.includes(demoScenarioFilter) || pol.includes({banking:'banking',government:'government',health:'healthcare'}[demoScenarioFilter]);
    });
  }
  return out;
}

function topoBuild() {
  topoLayoutCache = null;
  const conns = topoFilterConns(topoConns);
  if (!conns.length) { topoNodes = []; topoEdges = []; return; }
  const bySrc = {}, byTool = {}, byDst = {};
  conns.forEach(c => {
    const s = c.source || 'unknown', t = c.tool || 'unknown', d = c.destination || 'unknown';
    (bySrc[s] = bySrc[s] || {n:0, allow:0, deny:0, escalate:0}).n++; bySrc[s][c.decision] = (bySrc[s][c.decision]||0)+1;
    (byTool[t] = byTool[t] || {n:0, allow:0, deny:0, escalate:0, policy:c.policy||''}).n++; byTool[t][c.decision] = (byTool[t][c.decision]||0)+1;
    (byDst[d] = byDst[d] || {n:0, allow:0, deny:0, escalate:0}).n++; byDst[d][c.decision] = (byDst[d][c.decision]||0)+1;
  });
  const status = d => d.deny > d.allow ? 'deny' : d.escalate > 0 ? 'escalate' : 'allow';
  topoNodes = []; topoEdges = [];
  Object.entries(bySrc).forEach(([n, d]) => topoNodes.push({id:'src-'+n, type:'source', label:n, sub:d.n+' calls', status:status(d), meta:d}));
  Object.entries(byTool).forEach(([n, d]) => topoNodes.push({id:'tool-'+n, type:'policy', label:n, sub:(d.policy||'').split('/').pop(), badge:d.n+' calls', status:status(d), meta:d}));
  Object.entries(byDst).forEach(([n, d]) => topoNodes.push({id:'dst-'+n, type:'destination', label:n, sub:d.n+' calls', status:status(d), meta:d}));
  const seen = {};
  conns.forEach((c, i) => {
    const s = 'src-'+(c.source||'unknown'), t = 'tool-'+(c.tool||'unknown'), d = 'dst-'+(c.destination||'unknown');
    const col = topoEdgeColor(c.decision);
    const seg = (a, b, lbl) => {
      const k = a+'|'+b+'|'+lbl;
      if (seen[k]) return; seen[k] = 1;
      topoEdges.push({id:'e'+i+'-'+a+'-'+b, source:a, target:b, label:lbl, colour:col, decision:c.decision});
    };
    seg(s, t, ''); seg(t, d, (c.policy||'').split('/').pop());
  });
}

function topoEdgePath(sp, dp) {
  const x1 = sp.x + TOPO_W, y1 = sp.y + TOPO_NODE_H/2, x2 = dp.x, y2 = dp.y + TOPO_NODE_H/2;
  const mx = (x1 + x2) / 2;
  return `M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`;
}

let topoLayoutCache = null;
function topoChainRank() {
  const conns = topoFilterConns(topoConns);
  const chains = {};
  conns.forEach(c => {
    const s = 'src-'+(c.source||'unknown'), t = 'tool-'+(c.tool||'unknown'), d = 'dst-'+(c.destination||'unknown');
    const k = s+'|'+t+'|'+d;
    (chains[k] = chains[k] || {n:0, parts:[s,t,d]}).n++;
  });
  return Object.values(chains).sort((a,b) => b.n-a.n);
}
function topoLayout() {
  if (topoLayoutCache) return topoLayoutCache;
  const ranked = topoChainRank();
  const rowOf = new Map(), pos = {};
  ranked.forEach((ch, idx) => ch.parts.forEach(id => { if(!rowOf.has(id)) rowOf.set(id, idx); }));
  const pitch = TOPO_NODE_H + 88;  // aligned rows: the five busiest chains sit on rows 0-4
  rowOf.forEach((row, id) => {
    const type = id.startsWith('src-') ? 'source' : id.startsWith('tool-') ? 'policy' : 'destination';
    pos[id] = {x: TOPO_COL_X[type], y: 40 + row*pitch};
  });
  topoLayoutCache = {pos, rows: ranked.length};
  return pos;
}
function frameTopChains() {
  const canvas = document.getElementById('topoCanvas');
  if (!canvas || !topoConns.length) { topoFitPending = true; return; }
  const cw = canvas.clientWidth || 1000, ch = canvas.clientHeight || 720;
  const ranked = topoChainRank();
  const ids = new Set();
  ranked.slice(0,5).forEach(ch => ch.parts.forEach(id => ids.add(id)));
  const pos = topoLayout();
  let minX=Infinity, minY=Infinity, maxX=-Infinity, maxY=-Infinity;
  ids.forEach(id => {
    const pt = pos[id]; if(!pt) return;
    minX = Math.min(minX, pt.x); minY = Math.min(minY, pt.y);
    maxX = Math.max(maxX, pt.x + TOPO_W); maxY = Math.max(maxY, pt.y + TOPO_NODE_H);
  });
  if (!isFinite(minX)) { topoFitPending = true; return; }
  const pad = 26;
  const bw = (maxX - minX) + pad*2, bh = (maxY - minY) + pad*2;
  const scale = Math.min((cw - 20)/bw, (ch - 20)/bh, 2.4);
  topoScale = Math.max(0.4, scale);
  topoPanX = (cw - (minX + maxX)*topoScale)/2;
  topoPanY = (ch - (minY + maxY)*topoScale)/2;
}

function topoGlowLoop(svg, x, y, w, h, colour) {
  // Hero-style glowing rounded-rect loop around a node
  const g = document.createElementNS('http://www.w3.org/2000/svg','rect');
  g.setAttribute('x', x - 4); g.setAttribute('y', y - 4);
  g.setAttribute('width', w + 8); g.setAttribute('height', h + 8);
  g.setAttribute('rx', 13); g.setAttribute('fill', 'none');
  g.setAttribute('stroke', colour); g.setAttribute('stroke-width', '2');
  g.setAttribute('opacity', '0.85');
  g.style.filter = `drop-shadow(0 0 6px ${colour})`;
  const anim = document.createElementNS('http://www.w3.org/2000/svg','animate');
  anim.setAttribute('attributeName', 'opacity');
  anim.setAttribute('values', '0.35;0.95;0.35');
  anim.setAttribute('dur', '1.6s');
  anim.setAttribute('repeatCount', 'indefinite');
  g.appendChild(anim);
  svg.appendChild(g);
  return g;
}

function topoRender() {
  const svg = document.getElementById('topoSvg'), content = document.getElementById('topoContent');
  if (!svg || !content) return;
  const motion = document.getElementById('topoMotion')?.checked !== false;
  svg.innerHTML = ''; content.innerHTML = '';
  topoHoverLoop = null; topoDenyLoops = [];
  if (!topoNodes.length) {
    content.innerHTML = '<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);color:#8b919e;font-size:0.85rem">No connections yet' + (demoScenarioFilter!=='all' ? ' in this scenario' : '') + '</div>';
    return;
  }
  const pos = topoLayout();

  // connected set for dimming
  const conn = new Set();
  if (topoSelected) {
    conn.add(topoSelected);
    topoEdges.forEach(e => { if (e.source===topoSelected) conn.add(e.target); if (e.target===topoSelected) conn.add(e.source); });
  }

  // edges + particles
  topoEdges.forEach(e => {
    const sp = pos[e.source], dp = pos[e.target];
    if (!sp || !dp) return;
    const dimmed = topoSelected && !conn.has(e.source) && !conn.has(e.target);
    const d = topoEdgePath(sp, dp);
    const base = document.createElementNS('http://www.w3.org/2000/svg','path');
    base.setAttribute('d', d); base.setAttribute('stroke', e.colour);
    base.setAttribute('stroke-width','1.4'); base.setAttribute('fill','none');
    base.setAttribute('opacity', dimmed ? '0.08' : '0.35');
    svg.appendChild(base);
    if (motion && !dimmed) {
      const p = document.createElementNS('http://www.w3.org/2000/svg','circle');
      p.setAttribute('r','3'); p.setAttribute('fill', e.colour); p.setAttribute('opacity','0.9');
      p.style.filter = `drop-shadow(0 0 4px ${e.colour})`;
      const a = document.createElementNS('http://www.w3.org/2000/svg','animateMotion');
      a.setAttribute('dur', e.decision==='deny' ? '3.4s' : '2.4s');
      a.setAttribute('repeatCount','indefinite');
      a.setAttribute('path', d);
      p.appendChild(a); svg.appendChild(p);
    }
    if (e.label) {
      const l = document.createElement('div');
      l.textContent = e.label;
      l.style.cssText = 'position:absolute;font-size:10px;padding:2px 8px;border-radius:4px;background:#fff;border:1px solid #e5e7ec;color:#8b919e;font-family:ui-monospace,monospace;pointer-events:none;transform:translate(-50%,-50%);white-space:nowrap';
      l.style.left = ((pos[e.source].x+TOPO_W+pos[e.target].x)/2)+'px';
      l.style.top = ((pos[e.source].y+pos[e.target].y)/2+TOPO_NODE_H/2)+'px';
      content.appendChild(l);
    }
  });

  // nodes
  const denyFilterOn = (document.getElementById('topoDecisionFilter')?.value === 'deny');
  topoNodes.forEach(n => {
    const p = pos[n.id]; if (!p) return;
    const el = document.createElement('div');
    el.className = 'topo-node topo-node-' + (n.type==='source' ? 'src' : n.type==='destination' ? 'dst' : 'pol') +
      (topoSelected === n.id ? ' selected' : '') + (topoSelected && !conn.has(n.id) ? ' dimmed' : '');
    el.style.left = p.x + 'px'; el.style.top = p.y + 'px';
    el.innerHTML = `<div class="topo-node-hdr"><span class="topo-dot ${n.status}"></span>` +
      `<span class="topo-name">${esc(n.label)}</span></div>` +
      `<div class="topo-sub">${esc(n.sub || '')}</div>` +
      (n.badge ? `<span class="topo-badge">${esc(n.badge)}</span>` : '');
    el.addEventListener('click', () => {
      const wasSame = topoSelected === n.id;
      topoSelected = wasSame ? null : n.id;
      // Filter the traffic flow table below to this node's flow
      if (!wasSame) {
        if (n.id.startsWith('src-')) { selectedSource = n.label; selectedDest = null; }
        else if (n.id.startsWith('dst-')) { selectedDest = n.label; selectedSource = null; }
        else { selectedSource = null; selectedDest = null;
               const mid = document.getElementById('midFilter'); if (mid) mid.value = n.label; }
      } else {
        selectedSource = null; selectedDest = null;
        const mid = document.getElementById('midFilter'); if (mid) mid.value = '';
      }
      topoRender();
      renderFlow(); renderConnTable();
    });
    el.addEventListener('mouseenter', () => {
      topoHoverLoop = topoGlowLoop(svg, p.x, p.y, TOPO_W, TOPO_NODE_H, '#171717');
    });
    el.addEventListener('mouseleave', () => {
      if (topoHoverLoop) { topoHoverLoop.remove(); topoHoverLoop = null; }
    });
    content.appendChild(el);
    // Deny view: glowing red loops around deny nodes (hero-styled)
    if (denyFilterOn && n.status === 'deny') {
      topoDenyLoops.push(topoGlowLoop(svg, p.x, p.y, TOPO_W, TOPO_NODE_H, '#dd6b78'));
    }
  });

  // Apply the current view (scale + pan); fit computed lazily on first render
  applyTopoView();
}

// ===== topology view model: zoom + pan =====
let topoScale = 1, topoPanX = 0, topoPanY = 0, topoFitPending = false, topoInitPending = true, topoUserZoomed = false, topoFitAllPending = false;

function topoExtents() {
  if (!topoNodes.length) return null;
  const pos = topoLayout();
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  topoNodes.forEach(n => {
    const pt = pos[n.id]; if (!pt) return;
    minX = Math.min(minX, pt.x); minY = Math.min(minY, pt.y);
    maxX = Math.max(maxX, pt.x + TOPO_W); maxY = Math.max(maxY, pt.y + TOPO_NODE_H);
  });
  if (!isFinite(minX)) return null;
  return {x: minX, y: minY, w: maxX - minX, h: maxY - minY};
}

function applyTopoView() {
  const svg = document.getElementById('topoSvg');
  const content = document.getElementById('topoContent');
  const canvas = document.getElementById('topoCanvas');
  if (!svg || !content || !canvas) return;
  if (topoInitPending) {
    topoInitPending = false;
    frameTopChains();
  } else if (topoFitAllPending) {
    const cw = canvas.clientWidth || 1000, ch = canvas.clientHeight || 720;
    const contentW = TOPO_COL_X.destination + TOPO_W + 60;
    let maxY = 0;
    const pos2 = topoLayout();
    Object.values(pos2).forEach(p => { maxY = Math.max(maxY, p.y + TOPO_NODE_H); });
    const contentH = Math.max(maxY + 40, 100);
    const scale = Math.min((cw - 40) / contentW, (ch - 40) / contentH, 1.4);
    topoScale = Math.max(0.15, scale);
    topoUserZoomed = false;
    topoPanX = (cw - contentW * topoScale) / 2;
    topoPanY = Math.max(20, (ch - contentH * topoScale) / 2);
    topoFitAllPending = false;
  } else if (topoFitPending) {
    frameTopChains();
    topoFitPending = false;
  }
  // clamp the pan so the graph can never be lost outside the canvas
  const extents = topoExtents();
  const cw = canvas.clientWidth || 1000, ch = canvas.clientHeight || 720;
  if (extents) {
    const maxX = extents.x + extents.w, maxY = extents.y + extents.h;
    topoPanX = Math.min(topoPanX, cw - 20);
    topoPanX = Math.max(topoPanX, cw - maxX * topoScale - 20);
    topoPanY = Math.min(topoPanY, ch - 30);
    topoPanY = Math.max(topoPanY, ch - maxY * topoScale - 30);
  }
  const t = `translate(${topoPanX}px,${topoPanY}px) scale(${topoScale})`;
  content.style.transform = t;
  svg.style.transform = t;
  svg.style.transformOrigin = '0 0';
  content.style.transformOrigin = '0 0';
}

// The default view frames the five busiest chains (frameTopChains).

function topoZoomIn() { topoZoomBy(1.25); }
function topoZoomOut() { topoZoomBy(0.8); }
function topoZoomBy(f) {
  const canvas = document.getElementById('topoCanvas');
  const cw = canvas.clientWidth || 1000, ch = canvas.clientHeight || 720;
  const cx = cw / 2, cy = ch / 2;
  topoPanX = cx - (cx - topoPanX) * f;
  topoPanY = cy - (cy - topoPanY) * f;
  topoScale = Math.min(3, Math.max(0.15, topoScale * f));
  topoFitPending = false;
  applyTopoView();
}
function topoFit() { topoFitAllPending = true; applyTopoView(); }

function topoFullscreen() {
  const canvas = document.getElementById('topoCanvas');
  if (!document.fullscreenElement) {
    canvas.requestFullscreen().catch(()=>{});
  } else {
    document.exitFullscreen();
  }
}
document.addEventListener('fullscreenchange', () => {
  const icon = document.getElementById('topoFsIcon');
  if (icon) {
    icon.innerHTML = document.fullscreenElement
      ? '<path d="M8 3v3a2 2 0 0 1-2 2H3"/><path d="M21 8h-3a2 2 0 0 1-2-2V3"/><path d="M3 16h3a2 2 0 0 1 2 2v3"/><path d="M16 21v-3a2 2 0 0 1 2-2h3"/><line x1="8" y1="16" x2="16" y2="8"/><line x1="16" y1="16" x2="8" y2="8"/>'
      : '<path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M16 3h3a2 2 0 0 1 2 2v3"/><path d="M8 21H5a2 2 0 0 1-2-2v-3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/><line x1="3" y1="3" x2="21" y2="21"/>';
  }
  topoFitPending = true;
  setTimeout(applyTopoView, 120);
});

// Pan: drag anywhere on the canvas background (not on nodes or controls)
function initTopoPan() {
  const canvas = document.getElementById('topoCanvas');
  if (!canvas || canvas.dataset.panBound) return;
  canvas.dataset.panBound = '1';
  let panning = false, lastX = 0, lastY = 0;
  canvas.addEventListener('mousedown', (ev) => {
    if (ev.target.closest('.topo-node') || ev.target.closest('.topo-controls')) return;
    panning = true;
    lastX = ev.clientX; lastY = ev.clientY;
    canvas.classList.add('panning');
  });
  window.addEventListener('mousemove', (ev) => {
    if (!panning) return;
    topoPanX += ev.clientX - lastX;
    topoPanY += ev.clientY - lastY;
    topoUserZoomed = true;
    lastX = ev.clientX; lastY = ev.clientY;
    topoFitPending = false;
    applyTopoView();
  });
  window.addEventListener('mouseup', () => {
    panning = false;
    canvas.classList.remove('panning');
  });
  canvas.addEventListener('wheel', (ev) => {
    // scrolling the topology pans the view instead of zooming: the chains
    // above and below the framed rows stay reachable and fully visible
    ev.preventDefault();
    topoPanY -= ev.deltaY;
    topoPanX -= ev.deltaX;
    topoFitPending = false;
    topoUserZoomed = true;
    applyTopoView();
  }, { passive: false });
}

let topoPollId = null;
let topoSig = '';
function topoRefresh() {
  initTopoPan();
  const p = new URLSearchParams({limit: 120});
  api('/api/connections?' + p.toString()).then(r => r.json()).then(d => {
    const fresh = d.connections || [];
    const head = fresh[0] || {};
    const sig = [fresh.length, head.timestamp || '', head.tool || '', (fresh[fresh.length-1]||{}).timestamp || ''].join('|');
    if (sig === topoSig) { applyTopoView(); return; }  // keep animation, still settle the fit
    topoSig = sig;
    topoConns = fresh;
    topoBuild(); topoRender();
  }).catch(() => {});
}

// Start topology polling when the connections tab is shown; stop when hidden.
const origShowTab = showTab;
showTab = function(t, el) {
  origShowTab(t, el);
  if (t === 'connections') {
    if (!topoUserZoomed) topoFitPending = true;   // first visible render: the canvas has real dimensions now
    topoRefresh();
    if (!topoPollId) topoPollId = setInterval(() => {
      if (!document.hidden && !document.getElementById('tab-connections').classList.contains('hidden')) topoRefresh();
    }, 5000);
  } else if (topoPollId) {
    clearInterval(topoPollId); topoPollId = null;
  }
};


// ================= LEARN MODE =================
function loadLearn(){
  api('/api/learn/summary').then(r=>r.json()).then(s=>{
    let el=document.getElementById('learnSummary');
    if(!s.learn_mode){
      el.innerHTML='<span style="color:#e5b85c">Learn mode is off.</span> Set <code>RAUCLE_LEARN_MODE=true</code> and restart the gateway to start observing unmatched traffic.';
    } else if(!Object.keys(s.tools||{}).length){
      el.innerHTML='Learn mode is on. No unmatched calls recorded yet.';
    } else {
      let rows=Object.entries(s.tools).map(([t,d])=>`<tr><td>${esc(t)}</td><td>${escn(d.calls)}</td><td>${esc((d.agents||[]).join(', ')||'-')}</td></tr>`).join('');
      el.innerHTML='<table><tr><th>Observed tool</th><th>Denied calls</th><th>Agents</th></tr>'+rows+'</table>';
    }
  }).catch(()=>{});
  api('/api/learn/draft').then(r=>r.json()).then(d=>{
    document.getElementById('learnDraft').textContent=d.yaml||'Nothing learned yet.';
  }).catch(()=>{});
}
function copyDraftToEditor(){
  const draft=document.getElementById('learnDraft').textContent;
  if(!draft||draft.startsWith('Nothing')||draft.startsWith('No obs')){alert('Nothing to copy yet.');return;}
  showTab('policies',document.querySelector('.tab[data-tab-id="policies"]'));
  document.getElementById('policyEditor').value=draft;
  alert('Draft copied into the editor. Review, adjust constraints, then Save & Deploy.');
}
function clearLearn(){
  if(!confirm('Discard all learned observations?'))return;
  api('/api/learn/clear',{method:'POST'}).then(()=>loadLearn());
}

// ================= POLICY SIMULATE SHOWPIECE (D10) =================
// textContent-only rendering; the run POSTs to the demo simulate plane and
// never touches the apply path.
let simPresets = [], simPreset = '';
function loadSimPanel(){
  const card=document.getElementById('simDemoCard');
  if(!card)return;
  card.classList.add('hidden');
  if(!demoMode)return;
  card.classList.remove('hidden');
  api('/api/demo/policy-simulate/presets').then(r=>{ if(r.ok) return r.json(); throw 0; }).then(d=>{
    simPresets=d.presets||[];
    const bar=document.getElementById('simPresetList');
    bar.textContent='';
    simPresets.forEach(p=>{
      const chip=document.createElement('div');
      chip.className='file-chip'+(simPreset===p.name?' active':'');
      chip.setAttribute('data-sim-name',p.name);
      chip.setAttribute('data-hi','simPick(event)');
      chip.title=p.description||'';
      chip.textContent=p.label+' (simulated)';
      bar.appendChild(chip);
    });
  }).catch(()=>{ document.getElementById('simPresetList').textContent='Demo mode is not configured on this deployment.'; });
}
function simPick(ev){
  const el=ev.currentTarget||ev.target.closest('[data-sim-name]');
  const name=el?el.dataset.simName:null; if(!name)return;
  simPreset=name;
  document.querySelectorAll('#simPresetList .file-chip').forEach(c=>c.classList.toggle('active',c.dataset.simName===name));
}
function renderSimOutcome(d){
  const o=d.outcome||{};
  const out=document.getElementById('simOutcome');
  out.textContent='';
  const parts=[
    'Recorded actions replayed: '+(o.actions_replayed||0),
    'Outcome (current allow/deny): '+(o.current||{}).allow+'/'+(o.current||{}).deny,
    'Outcome (candidate allow/deny): '+(o.candidate||{}).allow+'/'+(o.candidate||{}).deny,
    'Decisions changed: '+((o.changed_decisions||[]).length),
    'Verdict: '+(o.verdict||'')
  ];
  parts.forEach(t=>{ const p=document.createElement('div'); p.textContent=t; out.appendChild(p); });
  const tb=document.getElementById('simChangesBody');
  tb.textContent='';
  const table=document.getElementById('simChangesTable');
  (o.changed_decisions||[]).forEach(c=>{
    table.classList.remove('hidden');
    const tr=document.createElement('tr');
    [c.tool,c.agent_id,c.current_decision,c.candidate_decision,String(c.evidence_depth||'')].forEach(v=>{
      const tdEl=document.createElement('td'); tdEl.textContent=v==null?'':String(v); tr.appendChild(tdEl);
    });
    tb.appendChild(tr);
  });
  const rc=document.getElementById('simReceipt');
  rc.textContent='';
  const rh=document.createElement('div'); rh.textContent='Simulation receipt hash: '+(d.receipt_hash||'');
  const jw=document.createElement('div'); jw.textContent='Signed receipt (EdDSA JWS): '+(d.jws||'');
  const note=document.createElement('div'); note.textContent=d.note||'';
  note.style.whiteSpace='normal';
  rc.appendChild(rh);rc.appendChild(jw);rc.appendChild(note);
}
function simRun(){
  if(!simPreset){ alert('Choose a demo policy tweak first.'); return; }
  const sum=document.getElementById('simOutcome');
  sum.textContent='Running the real simulation engine over the simulated window...';
  api('/api/demo/policy-simulate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({preset:simPreset})}).then(r=>{
    if(r.status===404){ alert('Demo mode is not configured on this deployment.'); return null; }
    if(!r.ok){ sum.textContent='The simulation was refused.'; return null; }
    return r.json();
  }).then(d=>{ if(d) renderSimOutcome(d); }).catch(()=>{ sum.textContent='Simulation request failed.'; });
}

// ================= X6 POLICY SIMULATE TAB (K2) =================
// The panel tab over the shipped X6 surface: pick a preset tweak (the
// D10 demo plane, real engine over the simulated window) or paste a
// candidate policy (the operator plane, POST /api/policy/simulate).
// textContent-only rendering; no apply path lives in this tab.
let simTabPresets = [], simTabPreset = '', simTabBusy = false;
const SIM_TAB_MAX_ROWS = 200;
function loadSimTab(){
  const bar=document.getElementById('simTabPresetList');
  if(!bar)return;
  api('/api/demo/policy-simulate/presets').then(r=>{ if(r.ok) return r.json(); throw 0; }).then(d=>{
    simTabPresets=d.presets||[];
    bar.textContent='';
    simTabPresets.forEach(p=>{
      const chip=document.createElement('div');
      chip.className='file-chip'+(simTabPreset===p.name?' active':'');
      chip.setAttribute('data-sim-tab-name',p.name);
      chip.setAttribute('data-hi','simTabPick(event)');
      chip.title=p.description||'';
      chip.textContent=p.label+' (simulated window)';
      bar.appendChild(chip);
    });
  }).catch(()=>{ bar.textContent='Demo mode is not configured on this deployment: preset tweaks are unavailable here.'; });
}
function simTabPick(ev){
  const el=ev.currentTarget||ev.target.closest('[data-sim-tab-name]');
  const name=el?el.dataset.simTabName:null; if(!name)return;
  simTabPreset=name;
  document.querySelectorAll('#simTabPresetList .file-chip').forEach(c=>c.classList.toggle('active',c.dataset.simTabName===name));
}
function simTabNotice(text){
  const sum=document.getElementById('simTabSummary');
  if(sum)sum.textContent=text;
}
function simTabClear(){
  simTabPreset='';
  document.querySelectorAll('#simTabPresetList .file-chip').forEach(c=>c.classList.remove('active'));
  ['simTabCandidate','simTabWindow','simTabStore'].forEach(id=>{const f=document.getElementById(id);if(f)f.value='';});
  const tb=document.getElementById('simTabChangesBody'); if(tb)tb.textContent='';
  const table=document.getElementById('simTabChangesTable'); if(table)table.classList.add('hidden');
  const hs=document.getElementById('simTabHashes'); if(hs)hs.textContent='';
  simTabNotice('No simulation yet: choose a preset tweak or paste a candidate policy, then run. The outcome renders here.');
}
function renderSimTab(d){
  // both response shapes end in the same bounded view: the demo plane
  // carries d.outcome, the operator plane carries d.result.gate
  const gate=d.outcome||((d.result||{}).gate)||{};
  const root=d.outcome||d.result||{};
  const sum=document.getElementById('simTabSummary');
  sum.textContent='';
  const parts=[
    'Recorded actions replayed: '+(gate.actions_replayed||0)+(gate.actions_unreplayable?(' (unreplayable: '+gate.actions_unreplayable+', never guessed)'):''),
    'Under the current policy: allow '+((gate.current||{}).allow||0)+' / deny '+((gate.current||{}).deny||0),
    'Under the candidate: allow '+((gate.candidate||{}).allow||0)+' / deny '+((gate.candidate||{}).deny||0),
    'Decisions that flip: '+((gate.changed_decisions||[]).length),
    'Verdict: '+(gate.verdict||''),
    'Evidence depth behind the verdict (chain depth): '+(gate.chain_depth||0)
  ];
  parts.forEach(t=>{ const p=document.createElement('div'); p.textContent=t; sum.appendChild(p); });
  const tb=document.getElementById('simTabChangesBody');
  tb.textContent='';
  const table=document.getElementById('simTabChangesTable');
  const changed=gate.changed_decisions||[];
  if(changed.length)table.classList.remove('hidden');
  changed.slice(0,SIM_TAB_MAX_ROWS).forEach(c=>{
    const tr=document.createElement('tr');
    [c.tool,c.agent_id,c.current_decision,c.candidate_decision,String(c.evidence_depth==null?'':c.evidence_depth),c.receipt_hash].forEach(v=>{
      const tdEl=document.createElement('td'); tdEl.textContent=v==null?'':String(v); tr.appendChild(tdEl);
    });
    tb.appendChild(tr);
  });
  if(changed.length>SIM_TAB_MAX_ROWS){
    const tr=document.createElement('tr');
    const tdEl=document.createElement('td');
    tdEl.colSpan=6;
    tdEl.textContent='Display bounded to the first '+SIM_TAB_MAX_ROWS+' of '+changed.length+' flipping decisions.';
    tr.appendChild(tdEl);
    tb.appendChild(tr);
  }
  const hs=document.getElementById('simTabHashes');
  hs.textContent='';
  const hlines=[
    'Candidate policy hash: '+(root.candidate_policy_hash||''),
    'Window hash: '+(root.window_hash||''),
    'Simulation receipt hash: '+(d.receipt_hash||''),
    'Signed receipt (EdDSA JWS): '+(d.jws||'')
  ];
  if(d.note)hlines.push(d.note);
  hlines.forEach(t=>{ const p=document.createElement('div'); p.textContent=t; hs.appendChild(p); });
}
function simTabRequest(r){
  if(r.ok)return r.json();
  if(r.status===404){ simTabNotice('Demo mode is not configured on this deployment: preset tweaks are unavailable here.'); return null; }
  return r.json().catch(()=>({})).then(det=>{
    const detail=det&&det.detail!==undefined?det.detail:det;
    let text='';
    if(Array.isArray(detail)){ text=detail.map(x=>(x&&(x.msg||x))||'').join('; '); }
    else if(detail){ text=String(detail); }
    if(r.status===403){ text='Simulation refused: '+(text||'insufficient role')+'. The key in use holds the auditor role; simulation over a live deployment window needs an operator key.'; }
    else if(r.status===422){ text='The request was refused as malformed (422): '+(text||'validation failed'); }
    else if(r.status===400){ text='The simulation was refused named: '+text; }
    else { text='The simulation request failed (HTTP '+r.status+').'; }
    simTabNotice(text);
    return null;
  });
}
function simTabRun(){
  if(simTabBusy){ simTabNotice('A simulation is already running: one run at a time.'); return; }
  const cEl=document.getElementById('simTabCandidate');
  const yaml=cEl&&cEl.value?cEl.value.trim():'';
  let url='', body=null;
  if(yaml){
    // client-side size cap: refuse oversize pasted policies before any
    // request leaves the panel (the MCP manifest precedent)
    if(yaml.length>256*1024){ simTabNotice('The pasted candidate policy is over 256 KiB: the panel refuses it before any request leaves.'); return; }
    body={candidate_policy_yaml:yaml};
    const w=document.getElementById('simTabWindow');
    if(w&&w.value.trim())body.window_ref=w.value.trim();
    const st=document.getElementById('simTabStore');
    if(st&&st.value.trim())body.input_store_ref=st.value.trim();
    url='/api/policy/simulate';
  } else if(simTabPreset){
    url='/api/demo/policy-simulate';
    body={preset:simTabPreset};
  } else {
    simTabNotice('Choose a preset policy tweak or paste a candidate policy YAML first: nothing has been simulated yet.');
    return;
  }
  simTabBusy=true;
  simTabNotice('Running the real simulation engine...');
  api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
    .then(simTabRequest)
    .then(d=>{ if(d)renderSimTab(d); })
    .catch(()=>{ simTabNotice('The simulation request failed.'); })
    .finally(()=>{ simTabBusy=false; });
}

// ================= EMERGENCY AUTHORITY STOP SCREEN (D9) =================
// Read-only display of the operator-control story: receipted transitions
// rendered as textContent; nothing here arms or applies anything.
let stopLoaded = false;
function loadStopPanel(){
  if(stopLoaded)return;
  stopLoaded=true;
  api('/api/demo/stop').then(r=>{ if(r.ok) return r.json(); throw 0; }).then(d=>{
    renderStopScreen(d);
  }).catch(()=>{ stopLoaded=false; });
}
function renderStopScreen(d){
  const q=document.getElementById('stopQuorum');
  q.textContent='';
  const qu=(d.quorum||{});
  ['global','agent','chain'].forEach(s=>{
    const chip=document.createElement('div');
    chip.className='file-chip';
    chip.textContent='Scope '+s+': M of N = '+(qu[s]!==undefined?qu[s]:'-');
    q.appendChild(chip);
  });
  const qn=document.createElement('div');
  qn.textContent=qu.note||'';
  qn.style.cssText='font-size:0.78rem;color:#8b919e;width:100%';
  q.appendChild(qn);
  const sb=document.getElementById('stopStoryBody');
  sb.textContent='';
  (d.story||[]).forEach(s=>{
    const o=s.outcome||{};
    const tr=document.createElement('tr');
    [s.step,(o.status||''),(o.operator||o.actor||'demo-operator'),(s.detail||''),' '].forEach(v=>{
      const tdEl=document.createElement('td'); tdEl.textContent=v==null?'':String(v); tr.appendChild(tdEl);
    });
    sb.appendChild(tr);
  });
  const rb=document.getElementById('stopReceiptsBody');
  rb.textContent='';
  (d.receipts||[]).forEach(r=>{
    const tr=document.createElement('tr');
    const scope=r.scope||'global';
    const approvers=(r.approvers||[]).join(', ')||'-';
    const qv=(r.min_approvers!=null&&r.min_approvers>1)?('of '+r.min_approvers):'single';
    [scope,r.verdict,approvers,qv].forEach(v=>{
      const tdEl=document.createElement('td'); tdEl.textContent=v==null?'':String(v); tr.appendChild(tdEl);
    });
    rb.appendChild(tr);
  });
}

// ================= MCP SCANNER (D5) =================
// The declarations below were once glued onto this header comment line and
// were therefore commented out: every loadMcpPanel() run then threw on the
// undeclared variables and the tab landed on its 'demo not configured'
// fallback with nothing selected. Keep the declarations on their own line.
let mcpManifests = [], mcpSelected = '';
function loadMcpPanel(){
  api('/api/demo/mcp/manifests').then(r=>{ if(r.ok) return r.json(); throw 0; }).then(d=>{
    mcpManifests = d.manifests||[];
    const bar=document.getElementById('mcpManifestList');
    bar.innerHTML='';
    mcpManifests.forEach(m=>{
      const chip=document.createElement('div');
      chip.className='file-chip'+(mcpSelected===m.name?' active':'');
      chip.setAttribute('data-mcp-name',m.name);
      chip.setAttribute('data-hi','mcpPick(event)');
      chip.title=(m.description||'')+(m.featured?' (first shown in the demo)':'');
      chip.textContent=m.label+' (simulated)';
      bar.appendChild(chip);
    });
    autoMcpSelect();
  }).catch(()=>{ document.getElementById('mcpManifestList').textContent='Demo mode is not configured on this deployment.'; });
}
// On demo entry the scanner lands pre-selected: the featured manifest is
// fetched and scanned through the real scanner route, so the findings table
// renders before the visitor touches anything. Never overrides a chosen
// manifest.
function autoMcpSelect(){
  if(mcpSelected)return;
  const first=(mcpManifests.find(m=>m.featured)||mcpManifests[0]||{}).name;
  if(!first)return;
  mcpSelected=first;
  document.querySelectorAll('#mcpManifestList .file-chip').forEach(c=>c.classList.toggle('active',c.dataset.mcpName===first));
  api('/api/demo/mcp/manifests/'+encodeURIComponent(first)).then(r=>{
    if(!r.ok)throw 0;
    return r.json();
  }).then(d=>{
    document.getElementById('mcpManifestText').value=JSON.stringify(d.manifest,null,2);
    mcpScan();
  }).catch(()=>{});
}
function mcpPick(ev){
  const el=ev.currentTarget||ev.target.closest('[data-mcp-name]');
  const name=el?el.dataset.mcpName:null; if(!name)return;
  mcpSelected=name;
  document.querySelectorAll('#mcpManifestList .file-chip').forEach(c=>c.classList.toggle('active',c.dataset.mcpName===name));
  api('/api/demo/mcp/manifests/'+encodeURIComponent(name)).then(r=>r.json()).then(d=>{
    document.getElementById('mcpManifestText').value=JSON.stringify(d.manifest,null,2);
  }).catch(()=>{});
}
function mcpClear(){ mcpSelected=''; document.getElementById('mcpManifestText').value=''; document.querySelectorAll('#mcpManifestList .file-chip').forEach(c=>c.classList.remove('active')); renderMcpFindings([]); }
const MCP_SEV_COLOUR={'CRITICAL':'#ef4444','HIGH':'#dd6b78','MEDIUM':'#e5b85c','LOW':'#8b919e','INFO':'#a3a3a3'};
function renderMcpFindings(list){
  const card=document.getElementById('mcpFindingsCard'), body=document.getElementById('mcpFindingsBody'), sum=document.getElementById('mcpSummary');
  body.textContent='';
  if(!list.length){ card.classList.add('hidden'); sum.textContent='No findings reported.'; return; }
  card.classList.remove('hidden');
  list.forEach(f=>{
    const tr=document.createElement('tr');
    const sev=document.createElement('td');
    const badge=document.createElement('span');
    badge.style.cssText='font-size:11px;font-weight:600;padding:2px 10px;border-radius:999px;color:#fff;background:'+(MCP_SEV_COLOUR[f.severity]||'#a3a3a3');
    badge.textContent=f.severity;
    sev.appendChild(badge);
    tr.appendChild(sev);
    tr.appendChild(td(f.rule_id));
    tr.appendChild(td(f.tool));
    tr.appendChild(td(f.field));
    tr.appendChild(td(f.message));
    const ev=document.createElement('td');
    ev.style.cssText='font-family:ui-monospace,monospace;font-size:11px';
    // evidence class only: the raw excerpt is payload and never reaches a cell
    ev.textContent=f.category||'';
    tr.appendChild(ev);
    body.appendChild(tr);
  });
  const bySev={};
  list.forEach(f=>{bySev[f.severity]=(bySev[f.severity]||0)+1;});
  sum.textContent=Object.keys(bySev).sort().map(s=>s+': '+bySev[s]).join('  ·  ');
}
function td(html){const el=document.createElement('td');el.textContent=html==null?'':String(html);return el;}
function mcpScan(){
  const raw=document.getElementById('mcpManifestText').value.trim();
  if(!raw){alert('Choose a demo manifest or paste manifest JSON first.');return;}
  // client-side size cap, mirroring the server's 256 KiB refusal
  if(raw.length>256*1024){alert('The pasted manifest is over 256 KiB: the demo refuses oversize manifests.');return;}
  let manifest;
  try{ manifest=JSON.parse(raw); }catch(e){ alert('The manifest is not valid JSON: '+e.message); return; }
  const sum=document.getElementById('mcpSummary');
  sum.textContent='Scanning with the real gateway scanner\\u2026';
  api('/api/demo/mcp/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({manifest:manifest})}).then(r=>{
    if(r.status===404){alert('Demo mode is not configured on this deployment.');return;}
    return r.json();
  }).then(d=>{ if(d) renderMcpFindings(d.findings||[]); }).catch(()=>{ sum.textContent='Scan request failed.'; });
}

if(!globalThis.__raucleHiBound){globalThis.__raucleHiBound=true;function gotoTopology(){window.location.href='/topology';}function reloadPage(){location.reload();}function navEvidencePack(el){showTab('assure',el);setTimeout(function(){var t=document.getElementById('assurancePacketView');if(t&&t.offsetParent)t.scrollIntoView({behavior:'smooth',block:'start'});},350);}function navKeyModel(el){showTab('receipts',el);setTimeout(function(){var t=document.getElementById('rcpt-keymodel');if(t&&t.offsetParent)t.scrollIntoView({behavior:'smooth',block:'start'});},350);}function navCoverage(el){showTab('receipts',el);setTimeout(function(){var t=document.getElementById('rcptCoverageCard');if(t&&t.offsetParent)t.scrollIntoView({behavior:'smooth',block:'start'});},350);};globalThis.__HI={"gotoTopology()":(ev,el)=>gotoTopology(),"reloadPage()":(ev,el)=>reloadPage(),"addUser()":(ev,el)=>addUser(),"clearLearn()":(ev,el)=>clearLearn(),"clearRcptFilters()":(ev,el)=>clearRcptFilters(),"confirmMfa()":(ev,el)=>confirmMfa(),"copyDraftToEditor()":(ev,el)=>copyDraftToEditor(),"demoExample()":(ev,el)=>demoExample(),"enterDemo()":(ev,el)=>enterDemo(),"exportReceipts()":(ev,el)=>exportReceipts(),"flowItemClick(event,'dest')":(ev,el)=>flowItemClick(ev,'dest'),"flowItemClick(event,'source')":(ev,el)=>flowItemClick(ev,'source'),"flowItemClick(event,'tool')":(ev,el)=>flowItemClick(ev,'tool'),"loadConfig()":(ev,el)=>loadConfig(),"loadLearn()":(ev,el)=>loadLearn(),"loadReceipts()":(ev,el)=>loadReceipts(),"loadAssure()":(ev,el)=>loadAssure(),"loadRecent()":(ev,el)=>loadRecent(),"login()":(ev,el)=>login(),"loginWithTotp()":(ev,el)=>loginWithTotp(),"rcptPage(false)":(ev,el)=>rcptPage(false),"rcptPage(true)":(ev,el)=>rcptPage(true),"rcptRowClick(event)":(ev,el)=>rcptRowClick(ev),"reloadPolicy()":(ev,el)=>reloadPolicy(),"saveConfig()":(ev,el)=>saveConfig(),"savePolicy()":(ev,el)=>savePolicy(),"saveSIEM()":(ev,el)=>saveSIEM(),"scenarioClick(event)":(ev,el)=>scenarioClick(ev),"setDecisionFilter('all',this)":(ev,el)=>setDecisionFilter('all',el),"setDecisionFilter('allow',this)":(ev,el)=>setDecisionFilter('allow',el),"setDecisionFilter('deny',this)":(ev,el)=>setDecisionFilter('deny',el),"setDecisionFilter('escalate',this)":(ev,el)=>setDecisionFilter('escalate',el),"setDirFilter('all',this)":(ev,el)=>setDirFilter('all',el),"setDirFilter('inbound',this)":(ev,el)=>setDirFilter('inbound',el),"setDirFilter('outbound',this)":(ev,el)=>setDirFilter('outbound',el),"showTab('config',this)":(ev,el)=>showTab('config',el),"showTab('connections',this)":(ev,el)=>showTab('connections',el),"showTab('dlp',this)":(ev,el)=>showTab('dlp',el),"showTab('injection',this)":(ev,el)=>showTab('injection',el),"showTab('shadow',this)":(ev,el)=>showTab('shadow',el),"showTab('dashboard',this)":(ev,el)=>showTab('dashboard',el),"showTab('learn',this)":(ev,el)=>showTab('learn',el),"showTab('mcp',this)":(ev,el)=>showTab('mcp',el),"showTab('policies',this)":(ev,el)=>showTab('policies',el),"showTab('stop',this)":(ev,el)=>showTab('stop',el),"showTab('receipts',this)":(ev,el)=>showTab('receipts',el),"showTab('assure',this)":(ev,el)=>showTab('assure',el),"showTab('capdemo',this)":(ev,el)=>showTab('capdemo',el),"navEvidencePack()":(ev,el)=>navEvidencePack(el),"navKeyModel()":(ev,el)=>navKeyModel(el),"navCoverage()":(ev,el)=>navCoverage(el),"capDemoPick(event)":(ev,el)=>capDemoPick(ev),"capDemoVerify()":(ev,el)=>capDemoVerify(),"loadAssurancePacket()":(ev,el)=>loadAssurancePacket(),"showTab('siem',this)":(ev,el)=>showTab('siem',el),"showTab('users',this)":(ev,el)=>showTab('users',el),"offlineVerify(event)":(ev,el)=>offlineVerify(ev),"topoFit()":(ev,el)=>topoFit(),"topoFullscreen()":(ev,el)=>topoFullscreen(),"topoZoomIn()":(ev,el)=>topoZoomIn(),"topoZoomOut()":(ev,el)=>topoZoomOut(),"tourEnd(false)":(ev,el)=>tourEnd(false),"tourNext()":(ev,el)=>tourNext(),"tourRestart()":(ev,el)=>tourRestart(),"userMfaAction(event,'disable')":(ev,el)=>userMfaAction(ev,'disable'),"userMfaAction(event,'setup')":(ev,el)=>userMfaAction(ev,'setup'),"validatePolicy()":(ev,el)=>validatePolicy(),"mcpScan()":(ev,el)=>mcpScan(),"mcpClear()":(ev,el)=>mcpClear(),"mcpPick(event)":(ev,el)=>mcpPick(ev),"sessionFindingVerify(event)":(ev,el)=>sessionFindingVerify(ev),"showTab('session',this)":(ev,el)=>showTab('session',el),"simRun()":(ev,el)=>simRun(),"simPick(event)":(ev,el)=>simPick(ev),"simTabPick(event)":(ev,el)=>simTabPick(ev),"simTabRun()":(ev,el)=>simTabRun(),"simTabClear()":(ev,el)=>simTabClear(),"ssoLogin()":(ev,el)=>ssoLogin(),"showTab('simulate',this)":(ev,el)=>showTab('simulate',el)};document.addEventListener('click',function(ev){const c=ev.target&&ev.target.closest?ev.target.closest('[data-hi]'):null;if(!c)return;const a=c.closest('a[href="#"]');if(a)ev.preventDefault();const fn=globalThis.__HI[c.getAttribute('data-hi')];if(fn)fn(ev,c);});};
</script>
</body>
</html>"""


TOPOLOGY_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Raucle Gateway - Traffic Topology</title>
<style>
:root {
  --bg: #101114;
  --surface: rgba(30,33,39,0.92);
  --surface-hover: rgba(43,47,55,0.98);
  --border: rgba(255,255,255,0.12);
  --text-primary: #f2f4f7;
  --text-secondary: #8e969f;
  --active-green: #39d49a;
  --active-cyan: #45cbd8;
  --warning: #e5b85c;
  --blocked: #dd6b78;
}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:ui-sans-serif,system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--text-primary);overflow:hidden}
.topology-canvas{
  position:relative;width:100%;height:calc(100vh - 48px);
  background-color:var(--bg);
  background-image:radial-gradient(rgba(255,255,255,0.10) 1px,transparent 1px);
  background-size:24px 24px;
  overflow:hidden;cursor:grab;
}
.topology-canvas:active{cursor:grabbing}
.topology-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:1}
.topology-content{position:absolute;top:0;left:0;width:100%;height:100%;z-index:2;transform-origin:0 0}
.node-card{
  position:absolute;width:180px;padding:12px 14px;border-radius:10px;
  background:var(--surface);border:1px solid var(--border);
  box-shadow:0 4px 12px rgba(0,0,0,0.3);cursor:pointer;
  transition:opacity 0.3s,background 0.2s,transform 0.2s,border-color 0.2s;
  backdrop-filter:blur(8px);user-select:none;
}
.node-card:hover{background:var(--surface-hover);border-color:rgba(255,255,255,0.2);transform:translateY(-1px)}
.node-card.selected{border-color:var(--active-green);box-shadow:0 0 0 2px rgba(57,212,154,0.3),0 4px 12px rgba(0,0,0,0.4)}
.node-card.dimmed{opacity:0.2}
.node-card.inactive{opacity:0.4}
.node-header{display:flex;align-items:center;gap:8px;margin-bottom:4px}
.node-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;animation:pulse-dot 2s infinite}
.node-dot.active{background:var(--active-green);box-shadow:0 0 8px var(--active-green)}
.node-dot.warning{background:var(--warning);box-shadow:0 0 8px var(--warning)}
.node-dot.inactive{background:var(--text-secondary);animation:none;box-shadow:none}
.node-dot.blocked{background:var(--blocked);box-shadow:0 0 8px var(--blocked)}
@keyframes pulse-dot{0%,100%{opacity:1}50%{opacity:0.5}}
.node-label{font-size:13px;font-weight:600;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.node-subtitle{font-size:11px;color:var(--text-secondary);margin-top:2px;font-family:ui-monospace,monospace}
.node-badge{display:inline-block;font-size:9px;padding:1px 6px;border-radius:4px;background:rgba(255,255,255,0.1);color:var(--text-secondary);margin-top:4px}
.node-type-source .node-dot{background:var(--active-cyan);box-shadow:0 0 8px var(--active-cyan)}
.node-type-destination .node-dot{background:var(--active-green);box-shadow:0 0 8px var(--active-green)}

.edge-label{
  position:absolute;font-size:10px;padding:2px 8px;border-radius:4px;
  background:var(--surface);border:1px solid var(--border);color:var(--text-secondary);
  font-family:ui-monospace,monospace;pointer-events:none;transform:translate(-50%,-50%);
  white-space:nowrap;transition:opacity 0.3s;z-index:3;
}
.edge-label.dimmed{opacity:0.15}

.topology-header{display:flex;align-items:center;justify-content:space-between;padding:10px 24px;border-bottom:1px solid var(--border);background:var(--bg);position:relative;z-index:10}
.topology-title{display:flex;align-items:center;gap:12px}
.topology-title h1{font-size:16px;font-weight:600;letter-spacing:-0.025em}
.topology-controls{display:flex;gap:8px;align-items:center}
.topo-btn{background:var(--surface);border:1px solid var(--border);color:var(--text-primary);padding:6px 14px;border-radius:8px;cursor:pointer;font-size:13px;font-family:inherit;transition:background 0.2s}
.topo-btn:hover{background:var(--surface-hover)}
.topo-btn.active{border-color:var(--active-green);color:var(--active-green)}
.filter-select{background:var(--surface);border:1px solid var(--border);color:var(--text-primary);padding:6px 12px;border-radius:8px;font-size:13px;font-family:inherit;outline:none}

.details-panel{position:absolute;top:48px;right:0;width:340px;height:calc(100vh - 48px);background:var(--surface);border-left:1px solid var(--border);padding:20px;overflow-y:auto;transform:translateX(100%);transition:transform 0.3s;z-index:20;backdrop-filter:blur(12px)}
.details-panel.open{transform:translateX(0)}
.details-panel h2{font-size:15px;font-weight:600;margin-bottom:12px;color:var(--text-primary)}
.details-panel .detail-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border)}
.detail-label{color:var(--text-secondary);font-size:12px}
.detail-value{color:var(--text-primary);font-size:12px;font-family:ui-monospace,monospace}
.detail-status{display:inline-flex;align-items:center;gap:6px}
.close-btn{position:absolute;top:16px;right:16px;background:none;border:none;color:var(--text-secondary);font-size:20px;cursor:pointer}
.live-indicator{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--active-green);margin-right:6px;animation:pulse-dot 2s infinite}
</style>
</head>
<body>
<div class="topology-header">
  <div class="topology-title">
    <h1>Raucle Gateway</h1>
    <span style="font-size:11px;padding:2px 8px;border-radius:999px;background:rgba(255,255,255,0.08);color:var(--text-secondary)">Topology</span>
  </div>
  <div class="topology-controls">
    <span><span class="live-indicator"></span>Live</span>
    <select class="filter-select" id="decisionFilter">
      <option value="">All Decisions</option>
      <option value="allow">Allow</option>
      <option value="deny">Deny</option>
      <option value="escalate">Escalate</option>
    </select>
    <button class="topo-btn" id="topoFitBtn">Fit View</button>
    <button class="topo-btn" id="motionBtn">Motion: On</button>
  </div>
</div>
<div class="topology-canvas" id="canvas">
  <svg class="topology-svg" id="svg"></svg>
  <div class="topology-content" id="content"></div>
</div>
<div class="details-panel" id="detailsPanel">
  <button class="close-btn" id="detailsCloseBtn">&times;</button>
  <h2 id="detailTitle"></h2>
  <div id="detailBody"></div>
</div>

<script>
// === DATA MODEL ===
let topologyNodes = [];
let topologyEdges = [];
let selectedNode = null;
let selectedEdge = null;
let motionEnabled = true;
let allConns = [];
let apiKey = '';
let pollId = null;

// === LAYOUT (deterministic three-column) ===
const COL_X = { source: 80, policy: 420, destination: 760 };
const NODE_H = 64;
const NODE_GAP = 24;

function layoutNodes(nodes) {
  const cols = { source: [], policy: [], destination: [] };
  nodes.forEach(n => cols[n.type]?.push(n));
  const positions = {};
  ['source','policy','destination'].forEach(type => {
    const colNodes = cols[type];
    const totalH = colNodes.length * (NODE_H + NODE_GAP) - NODE_GAP;
    let y = Math.max(40, (window.innerHeight - 48 - totalH) / 2);
    colNodes.forEach(n => {
      positions[n.id] = { x: COL_X[type], y };
      y += NODE_H + NODE_GAP;
    });
  });
  return positions;
}

// === SVG EDGE PATHS ===
function edgePath(src, dst) {
  const sx = src.x + 180, sy = src.y + NODE_H / 2;
  const dx = dst.x, dy = dst.y + NODE_H / 2;
  const cx = (sx + dx) / 2;
  return `M${sx},${sy} C${cx},${sy} ${cx},${dy} ${dx},${dy}`;
}

function getEdgeColor(decision) {
  if (decision === 'allow') return '#39d49a';
  if (decision === 'deny') return '#dd6b78';
  if (decision === 'escalate') return '#e5b85c';
  return '#45cbd8';
}

// === RENDER ===
function render() {
  const positions = layoutNodes(topologyNodes);
  const svg = document.getElementById('svg');
  const content = document.getElementById('content');
  svg.innerHTML = '';
  content.innerHTML = '';

  // Determine connected nodes for selection dimming
  let connectedIds = new Set();
  if (selectedNode) {
    connectedIds.add(selectedNode);
    topologyEdges.forEach(e => {
      if (e.source === selectedNode) connectedIds.add(e.target);
      if (e.target === selectedNode) connectedIds.add(e.source);
    });
  }

  // Draw edges
  topologyEdges.forEach(edge => {
    const src = topologyNodes.find(n => n.id === edge.source);
    const dst = topologyNodes.find(n => n.id === edge.target);
    if (!src || !dst) return;
    const sp = positions[src.id], dp = positions[dst.id];
    if (!sp || !dp) return;

    const color = edge.colour || getEdgeColor(edge.status);
    const isDimmed = selectedNode && !connectedIds.has(edge.source) && !connectedIds.has(edge.target);
    const opacity = isDimmed ? '0.1' : '0.5';

    // Base path (faint)
    const pathId = `path-${edge.id}`;
    const d = edgePath(sp, dp);
    const baseLine = document.createElementNS('http://www.w3.org/2000/svg','path');
    baseLine.setAttribute('d', d);
    baseLine.setAttribute('stroke', color);
    baseLine.setAttribute('stroke-width', '1.5');
    baseLine.setAttribute('fill', 'none');
    baseLine.setAttribute('opacity', opacity);
    svg.appendChild(baseLine);

    // Visible path (for hit testing and motion reference)
    const visPath = document.createElementNS('http://www.w3.org/2000/svg','path');
    visPath.setAttribute('d', d);
    visPath.setAttribute('id', pathId);
    visPath.setAttribute('stroke', 'transparent');
    visPath.setAttribute('stroke-width', '20');
    visPath.setAttribute('fill', 'none');
    visPath.setAttribute('style', 'pointer-events:stroke;cursor:pointer');
    visPath.addEventListener('click', () => selectEdge(edge));
    svg.appendChild(visPath);

    // Animated particles
    if (motionEnabled && !isDimmed) {
      const count = edge.particleCount || 2;
      const speed = edge.animationSpeed || 1;
      for (let i = 0; i < count; i++) {
        const particle = document.createElementNS('http://www.w3.org/2000/svg','circle');
        particle.setAttribute('r', '3');
        particle.setAttribute('fill', color);
        particle.setAttribute('opacity', '0.9');
        particle.style.filter = `drop-shadow(0 0 4px ${color})`;

        const anim = document.createElementNS('http://www.w3.org/2000/svg','animateMotion');
        anim.setAttribute('dur', `${3 / speed}s`);
        anim.setAttribute('repeatCount', 'indefinite');
        anim.setAttribute('begin', `${(i / count) * (3 / speed)}s`);
        anim.setAttribute('path', d);
        particle.appendChild(anim);
        svg.appendChild(particle);
      }
    }

    // Edge label (protocol/ports)
    if (edge.label) {
      const mx = (sp.x + 180 + dp.x) / 2;
      const my = (sp.y + NODE_H/2 + dp.y + NODE_H/2) / 2;
      const labelEl = document.createElement('div');
      labelEl.className = 'edge-label' + (isDimmed ? ' dimmed' : '');
      labelEl.style.left = mx + 'px';
      labelEl.style.top = my + 'px';
      labelEl.textContent = edge.label;
      labelEl.dataset.edgeId = edge.id;
      labelEl.addEventListener('click', () => selectEdge(edge));
      labelEl.style.pointerEvents = 'auto';
      labelEl.style.cursor = 'pointer';
      content.appendChild(labelEl);
    }
  });

  // Draw nodes
  topologyNodes.forEach(node => {
    const pos = positions[node.id];
    if (!pos) return;
    const isDimmed = selectedNode && !connectedIds.has(node.id);
    const isSelected = selectedNode === node.id;

    const card = document.createElement('div');
    card.className = `node-card node-type-${node.type}` + (isSelected ? ' selected' : '') + (isDimmed ? ' dimmed' : '') + (node.status === 'inactive' ? ' inactive' : '');
    card.style.left = pos.x + 'px';
    card.style.top = pos.y + 'px';
    card.tabIndex = 0;
    card.setAttribute('role', 'button');
    card.setAttribute('aria-label', `${node.type}: ${node.label}`);

    const statusClass = node.status === 'active' ? 'active' : node.status === 'warning' ? 'warning' : node.status === 'blocked' ? 'blocked' : 'inactive';
    card.innerHTML = `
      <div class="node-header">
        <div class="node-dot ${statusClass}"></div>
        <div class="node-label">${esc(node.label)}</div>
      </div>
      ${node.subtitle ? `<div class="node-subtitle">${esc(node.subtitle)}</div>` : ''}
      ${node.badge ? `<div class="node-badge">${esc(node.badge)}</div>` : ''}
    `;
    card.addEventListener('click', () => selectNode(node));
    card.addEventListener('keydown', (e) => { if (e.key === 'Enter') selectNode(node); });
    content.appendChild(card);
  });
}

function esc(s) { return s ? s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])) : ''; }

// === SELECTION ===
function selectNode(node) {
  if (selectedNode === node.id) {
    selectedNode = null;
    closeDetails();
  } else {
    selectedNode = node.id;
    showNodeDetails(node);
  }
  render();
}

function selectEdge(edge) {
  selectedEdge = edge;
  showEdgeDetails(edge);
}

function showNodeDetails(node) {
  const panel = document.getElementById('detailsPanel');
  document.getElementById('detailTitle').textContent = node.label;
  let html = '';
  if (node.subtitle) html += `<div class="detail-row"><span class="detail-label">Address</span><span class="detail-value">${esc(node.subtitle)}</span></div>`;
  html += `<div class="detail-row"><span class="detail-label">Type</span><span class="detail-value">${esc(node.type)}</span></div>`;
  html += `<div class="detail-row"><span class="detail-label">Status</span><span class="detail-status"><span class="node-dot ${node.status||'inactive'}"></span>${esc(node.status || 'unknown')}</span></div>`;
  if (node.metadata) {
    Object.entries(node.metadata).forEach(([k,v]) => {
      html += `<div class="detail-row"><span class="detail-label">${esc(k)}</span><span class="detail-value">${esc(String(v))}</span></div>`;
    });
  }
  // Show connected edges
  const conns = topologyEdges.filter(e => e.source === node.id || e.target === node.id);
  if (conns.length) {
    html += `<div style="margin-top:16px;font-size:13px;font-weight:600;color:var(--text-primary)">Connections (${conns.length})</div>`;
    conns.forEach(e => {
      const other = e.source === node.id ? e.target : e.source;
      const otherNode = topologyNodes.find(n => n.id === other);
      html += `<div class="detail-row"><span class="detail-label">${esc(otherNode?.label || other)}</span><span class="detail-value" style="color:${e.colour||getEdgeColor(e.status)}">${esc(e.label || e.status)}</span></div>`;
    });
  }
  document.getElementById('detailBody').innerHTML = html;
  panel.classList.add('open');
}

function showEdgeDetails(edge) {
  const panel = document.getElementById('detailsPanel');
  document.getElementById('detailTitle').textContent = edge.label || 'Connection';
  const srcNode = topologyNodes.find(n => n.id === edge.source);
  const dstNode = topologyNodes.find(n => n.id === edge.target);
  let html = '';
  html += `<div class="detail-row"><span class="detail-label">From</span><span class="detail-value">${esc(srcNode?.label || edge.source)}</span></div>`;
  html += `<div class="detail-row"><span class="detail-label">To</span><span class="detail-value">${esc(dstNode?.label || edge.target)}</span></div>`;
  if (edge.protocol) html += `<div class="detail-row"><span class="detail-label">Protocol</span><span class="detail-value">${esc(edge.protocol.toUpperCase())}</span></div>`;
  if (edge.ports) html += `<div class="detail-row"><span class="detail-label">Ports</span><span class="detail-value">${esc(String(edge.ports))}</span></div>`;
  html += `<div class="detail-row"><span class="detail-label">Status</span><span class="detail-status"><span class="node-dot ${edge.status==='active'?'active':'blocked'}"></span>${esc(edge.status || 'unknown')}</span></div>`;
  if (edge.trafficRate !== undefined) html += `<div class="detail-row"><span class="detail-label">Traffic Rate</span><span class="detail-value">${escn(edge.trafficRate)}/s</span></div>`;
  if (edge.metadata) {
    Object.entries(edge.metadata).forEach(([k,v]) => {
      html += `<div class="detail-row"><span class="detail-label">${esc(k)}</span><span class="detail-value">${esc(String(v))}</span></div>`;
    });
  }
  document.getElementById('detailBody').innerHTML = html;
  panel.classList.add('open');
}

function closeDetails() {
  document.getElementById('detailsPanel').classList.remove('open');
  selectedNode = null;
  selectedEdge = null;
  render();
}

// === PAN & ZOOM ===
let scale = 1, panX = 0, panY = 0, isDragging = false, dragStartX = 0, dragStartY = 0;
const canvas = document.getElementById('canvas');
const content = document.getElementById('content');
const svg = document.getElementById('svg');

function applyTransform() {
  content.style.transform = `translate(${panX}px,${panY}px) scale(${scale})`;
  svg.style.transform = `translate(${panX}px,${panY}px) scale(${scale})`;
}

canvas.addEventListener('mousedown', e => {
  if (e.target.classList.contains('node-card') || e.target.classList.contains('edge-label')) return;
  isDragging = true;
  dragStartX = e.clientX - panX;
  dragStartY = e.clientY - panY;
});
canvas.addEventListener('mousemove', e => {
  if (!isDragging) return;
  panX = e.clientX - dragStartX;
  panY = e.clientY - dragStartY;
  applyTransform();
});
canvas.addEventListener('mouseup', () => isDragging = false);
canvas.addEventListener('mouseleave', () => isDragging = false);

canvas.addEventListener('wheel', e => {
  e.preventDefault();
  const delta = e.deltaY > 0 ? 0.9 : 1.1;
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left, my = e.clientY - rect.top;
  panX = mx - (mx - panX) * delta;
  panY = my - (my - panY) * delta;
  scale = Math.max(0.3, Math.min(3, scale * delta));
  applyTransform();
}, { passive: false });

function fitView() {
  if (!topologyNodes.length) return;
  const positions = layoutNodes(topologyNodes);
  const maxX = Math.max(...Object.values(positions).map(p => p.x + 180));
  const maxY = Math.max(...Object.values(positions).map(p => p.y + NODE_H));
  const w = canvas.clientWidth, h = canvas.clientHeight;
  scale = Math.min(w / (maxX + 40), h / (maxY + 40), 1.2);
  panX = (w - maxX * scale) / 2;
  panY = 20;
  applyTransform();
}

// === MOTION ===
function toggleMotion() {
  motionEnabled = !motionEnabled;
  document.getElementById('motionBtn').textContent = `Motion: ${motionEnabled ? 'On' : 'Off'}`;
  render();
}

// Check prefers-reduced-motion
if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  motionEnabled = false;
}

// === DATA: Load from gateway API ===
function updateData() {
  // Try to fetch from gateway API
  fetch('/api/connections?limit=500', {
    headers: { Authorization: apiKey || 'test-key' }
  }).then(r => r.json()).then(d => {
    allConns = d.connections || [];
    buildTopology(allConns);
  }).catch(() => {
    // Fallback to sample data
    buildTopology([]);
  });
}

function buildTopology(conns) {
  if (!conns.length) {
    // Sample topology from the spec
    topologyNodes = [
      { id: 'client', type: 'source', label: 'Workstation', subtitle: '100.64.17.61', status: 'active' },
      { id: 'policy-infra', type: 'policy', label: 'workstation-to-infra', subtitle: 'TCP:22,443,8006', status: 'active' },
      { id: 'policy-dns', type: 'policy', label: 'workstation-to-dns', subtitle: 'UDP:53', status: 'active' },
      { id: 'infra', type: 'destination', label: 'Infrastructure', subtitle: '5 resources', status: 'active' },
      { id: 'dns', type: 'destination', label: 'DNS Server', subtitle: '1 resource', status: 'active' },
    ];
    topologyEdges = [
      { id: 'e1', source: 'client', target: 'policy-infra', status: 'active', colour: '#35d6a0', animationSpeed: 1, particleCount: 2 },
      { id: 'e2', source: 'policy-infra', target: 'infra', label: 'TCP:22,443,8006', protocol: 'tcp', ports: '22,443,8006', status: 'active', colour: '#35d6a0', animationSpeed: 1.2, particleCount: 2 },
      { id: 'e3', source: 'client', target: 'policy-dns', status: 'active', colour: '#48c8d8', animationSpeed: 0.8, particleCount: 1 },
      { id: 'e4', source: 'policy-dns', target: 'dns', label: 'UDP:53', protocol: 'udp', ports: '53', status: 'active', colour: '#48c8d8', animationSpeed: 0.8, particleCount: 1 },
    ];
    render();
    fitView();
    return;
  }

  // Build topology from real connections
  const filter = document.getElementById('decisionFilter')?.value;
  let filtered = conns;
  if (filter) filtered = filtered.filter(c => c.decision === filter);

  const bySrc = {}, byTool = {}, byDst = {};
  filtered.forEach(c => {
    const s = c.source || 'unknown';
    const t = c.tool || 'unknown';
    const d = c.destination || 'unknown';
    if (!bySrc[s]) bySrc[s] = { count: 0, allow: 0, deny: 0, escalate: 0 };
    bySrc[s].count++; bySrc[s][c.decision] = (bySrc[s][c.decision] || 0) + 1;
    if (!byTool[t]) byTool[t] = { count: 0, allow: 0, deny: 0, escalate: 0, policy: c.policy || '' };
    byTool[t].count++; byTool[t][c.decision] = (byTool[t][c.decision] || 0) + 1;
    if (!byDst[d]) byDst[d] = { count: 0, allow: 0, deny: 0, escalate: 0 };
    byDst[d].count++; byDst[d][c.decision] = (byDst[d][c.decision] || 0) + 1;
  });

  const nodes = [];
  const edges = [];

  Object.entries(bySrc).forEach(([name, d]) => {
    const status = d.deny > d.allow ? 'blocked' : d.escalate > 0 ? 'warning' : 'active';
    nodes.push({ id: `src-${name}`, type: 'source', label: name, subtitle: `${d.count} calls`, status, metadata: { allow: d.allow, deny: d.deny, escalate: d.escalate } });
  });
  Object.entries(byTool).forEach(([name, d]) => {
    const status = d.deny > d.allow ? 'blocked' : d.escalate > 0 ? 'warning' : 'active';
    const policy = d.policy ? d.policy.split('/').pop() : '';
    nodes.push({ id: `tool-${name}`, type: 'policy', label: name, subtitle: policy, badge: `${d.count} calls`, status, metadata: { allow: d.allow, deny: d.deny, escalate: d.escalate, policy } });
  });
  Object.entries(byDst).forEach(([name, d]) => {
    const status = d.deny > d.allow ? 'blocked' : d.escalate > 0 ? 'warning' : 'active';
    nodes.push({ id: `dst-${name}`, type: 'destination', label: name, subtitle: `${d.count} calls`, status, metadata: { allow: d.allow, deny: d.deny, escalate: d.escalate } });
  });

  // Build edges: source -> tool -> destination
  filtered.forEach((c, i) => {
    const sId = `src-${c.source || 'unknown'}`;
    const tId = `tool-${c.tool || 'unknown'}`;
    const dId = `dst-${c.destination || 'unknown'}`;
    const colour = getEdgeColor(c.decision);
    edges.push({ id: `e-s2t-${i}`, source: sId, target: tId, status: c.decision, colour, animationSpeed: c.decision === 'deny' ? 0.5 : 1, particleCount: 1 });
    edges.push({ id: `e-t2d-${i}`, source: tId, target: dId, label: c.policy ? c.policy.split('/').pop() : '', status: c.decision, colour, animationSpeed: c.decision === 'deny' ? 0.5 : 1.2, particleCount: 1, metadata: { decision: c.decision, reason: c.reason, latency_us: c.latency_us } });
  });

  // Deduplicate edges by (source,target) pair keeping the most recent
  const edgeMap = {};
  edges.forEach(e => {
    const key = `${e.source}|${e.target}`;
    if (!edgeMap[key]) edgeMap[key] = e;
  });
  topologyNodes = nodes;
  topologyEdges = Object.values(edgeMap);
  render();
  fitView();
}

// === POLLING ===
function startPolling() {
  if (pollId) clearInterval(pollId);
  pollId = setInterval(() => {
    if (!document.hidden) updateData();
  }, 5000);
}

// === INIT ===
updateData();
startPolling();
window.addEventListener('resize', () => { render(); fitView(); });
(function(){const ids=[['topoFitBtn','click',fitView],['motionBtn','click',toggleMotion],['detailsCloseBtn','click',closeDetails],['decisionFilter','change',updateData]];ids.forEach(function(x){const el=document.getElementById(x[0]);if(el)el.addEventListener(x[1],x[2]);});})();</script>
</body>
</html>"""


__all__ = ["create_gateway_app", "create_admin_app"]
