# Migration journal (20 November 2026)

The content below is the
Unreleased section as it stood when the per-lane entry convention landed,
moved verbatim. Future lanes never edit CHANGELOG.md; they write
`docs/changelog-entries/<branch>.md` and the assembler composes Unreleased
at merge time.

- Receipts v1.2 (EPIC W lane W1): state-verified write receipts as replay-verifiable evidence, recast per the Q-spec gate-vantage finding to evidence-at-mint from adapters (the gate sees tool-call requests, not tool execution, so the ADAPTER or runtime performs the read-back; the gate-executed read-back and a verified-after reconciliation mode stay named follow-ups gated on the in-path MCP gateway). New `x_state` extension on the authority-receipt mint path (`RaucleGateway.emit_state_evidence`): version anchor `state-evidence/v1`, closed field set, `pairing_id`, `read_tool`, `evidence_digest` (sha256 over the read-back's raw response bytes as the runtime submitted them), `handle` (extracted per the pairing entry's id_pointer), `field_classes` (field-presence names only), and the mandatory `cited_receipt` binding the read-back digest to the write's receipt id; absence is the literal sentinel `state_evidence: absent`, never a fake digest, and a covered write receipt carrying neither evidence nor the sentinel marks INVALID with a named reason at verify - the paper's false-success class made offline-checkable. Bounded disclosure throughout: digests, handles and names only, never read-back content, swept by the shared forbidden-field sweep. The write-to-read pairing registry is an operator-declared `state_pairings` policy-file section (per entry write_tool, read_tool, id_pointer, optional require_field_classes, deterministic id `<write_tool>:<read_tool>`), bound fail-closed at config load against the tool schema registry on the X1 doctrine: a pairing referencing an unknown tool or an undeclared id field raises a SchemaPolicyLoadError-class error at config load, never at call time; unknown pairing means no entry and the receipt then honestly says absent with no pairing_id; the registry binds at boot (restart-required on later section changes, the same split-brain guard as the manifest). The middleware evidence lane (`RaucleMiddleware.submit_state_evidence`, best-effort fail-open like every hook) hashes the raw read bytes, extracts the handle and submits through the mint path; a failed or skipped read yields the absent sentinel plus a receipted advisory finding (harness `state-verification`, test id `state_evidence_missing`) citing the write receipt, and an uncited submission mints nothing (no ghost citations). Offline verifier: per-line structural re-checks (sweep, closed set, unknown version refused, sentinel semantics, digest shapes, citation existence EARLIER in the chain) plus a chain-end coverage and linkage pass when the verifier is constructed with the registry (`ProvenanceVerifier(..., state_pairings=...)`, constructor-carried state like executor_keys): every ALLOWED covered write must carry evidence or the sentinel, pairing ids must exist, the cited receipt's tool and the block's read tool must match the registry entry, and every require_field_classes name must be present in field_classes (presence re-check, deliberately dumb). Without the registry the blocks stay structural - the documented off-deployment residual. Receipts without the extension keep their historical byte shape exactly (omit-when-absent); definition-drift findings and state evidence coexist on one chain with no conflict. Spec: docs/spec/provenance/v1.2/state-verification.md. Tests: tests/test_state_receipts.py (red-first, 28 checks).
- Receipts v1.2 (EPIC W lane W2): definition drift as replay-verifiable evidence. Every gate receipt for a schema-registered tool carries a versioned `x_gate.tool_definition` block (definition digest over the registered inputSchema at bind time, the manifest path it was pinned from, honest vantage `none` - the gate sees requests, not served definitions; the call-time served-definition diff waits for the in-path MCP gateway and is named as a follow-up). A manifest reload (`POST /api/tool-schemas/reload`, the same operator plane as the policy reload) supersedes changed definitions and emits a receipted `definition_changed` finding (harness `tool-schema`, old and new digests only, never schema content) citing the last gate receipt for the tool; no prior receipt means no citation and nothing is minted (`skipped_no_prior_receipt`, the x_finding contract forbids ghost citations), and a manifest configured after construction is refused with a named restart-required error (the split-brain guard: enforcement holds the registry bound at boot). Offline verifier: per-line structural re-checks (closed field set swept by the shared forbidden-field sweep, unknown version and vantage refused with named errors) plus a chain-end pin discipline - the LATEST block per tool must re-derive from the on-disk manifest (the deployment's registry state), a receipted transition excuses the divergence, silent drift fails with a named error, and an unreadable manifest is the documented off-deployment residual. Receipts for unregistered tools stay byte-identical to their pre-W2 shape. X1 unchanged (extend, do not fork): the load path still refuses a conflicting schema, only the explicit reload path observes drift.
- Receipts v1.2: counterfactual evidence blocks (emitter + verifier: version-gated, closed field set, two-key session window evidence, evaluated_at bound, never re-run, no content) and revocation-event receipts (v1.2 x_revocation kind: revocation kind, reason_class, revoked_hashes, capability-to-token ledger linkage; admin /api/revoke + request upgrades). Unknown versions refuse.

### Added - X2 slice 2: offline verification of the hosted transparency log

- The hosted transparency log (append-only, per-org, hash-chained log
  of registered receipt digests whose every append closes a signed
  epoch) is an operator surface in raucle-cloud; this carries the OSS
  half the licence split (17 Nov) demands: the verifier-side contract
  and the offline checks a third party runs with no trust in the
  operator.
- docs/spec/x2-transparency-log-v1.md: the wire contract in verifier
  terms. The closed entry profile (seven fields; the entry hash is
  sha256 over the OSS canonical JSON of six), the Ed25519 epoch
  checkpoint (typ transparency-epoch/v1, closed header and payload
  field sets, epoch == size), the proof surfaces, and the named
  statuses with their precedence.
- raucle/transparency.py: compute_log_entry_hash (byte-identical to
  the hosted log's own computation) plus verify_log_inclusion and
  verify_log_consistency, returning the named STATUS_LOG_* statuses
  (LOG-INCLUDED, LOG-CONSISTENT, LOG-MALFORMED, LOG-CHAIN-BROKEN,
  LOG-BAD-SIGNATURE, LOG-HEAD-MISMATCH) with every refusal reason
  reported, never just the first. The operator key is always a pinned
  parameter: a proof is never verified against its own rider key.
- tests/test_transparency_log_verify.py (red-first, 23 checks) plus
  the committed fixture generated by the cloud implementation
  (tests/fixtures/transparency-log/cloud-roundtrip.json): the OSS
  verifier accepts the log's real proofs and refuses doctored copies
  with named statuses, a cross-repo dogfood. Paired PR: raucle-cloud
  feat/x2-transparency-log (the log itself); both PR bodies disclose
  the pairing.

### Added - K1: boot streaming architecture (design slice, spec precedes implementation)

- docs/spec/boot-streaming-v0.1.md + ADR 0007 (docs/adr/, continuing the
  suite ADR series): the gateway boot streams the audit chain and feeds the
  receipt index in bounded windows and never maps a store whole - the named
  bigger follow-up to the 18 Nov demo OOM incident (12.2 GB audit log +
  15 GB index -> 23.4 GB resident, three kernel kills).
- The design: bind first (gate traffic needs neither the index nor the
  audit chain), a bounded reverse tail read replaces whole-scan chain
  resume, the receipt index builds in a background compactor with
  per-surface readiness (named refusals while building, never empty
  answers), session continuity restored from a TTL-bounded tail window,
  and the fail-closed tail discipline tightened (a torn tail is a named
  refusal, never a silently skipped line).
- Built on the shipped primitives, contracts unchanged: J1's preflight
  (projection re-derived from the window budget; the ceiling lowers as
  windows shrink) and rotate-chain (PR #297), J2's recovery doctrine
  (PR #296). Acceptance criteria for the implementing lane in the spec;
  the k1-boot-streaming bench (X5 harness extension) decides the knob
  defaults.

### Added - K2: the policy-simulate panel tab (X6 slice 2)

- The X6 surface named in the slice 1 follow-up now has its panel tab:
  `Policy simulate` sits in the trust group after Policies, truth class
  OSS LIVE, and makes the simulation demo visible in the panel - paste a
  candidate policy YAML (operator plane, `POST /api/policy/simulate`,
  window and input-store refs optional) or pick a preset tweak (the D10
  demo plane, the same real engine over the simulated served window).
- Bounded rendering, same content discipline as the existing tabs: what
  the candidate would have allowed and denied, the decisions that flip
  (tool, agent, both decisions, evidence depth, receipt hash), the
  verdict and chain depth, then candidate/window/receipt hashes and the
  signed EdDSA JWS as metadata. Never argument values, never denial
  reasons: the tab renders only what the simulate API emits, pinned by
  an ACC-999-class sweep over both response shapes
  (`tests/test_simulate_panel_tab.py`) plus a node render probe.
- Honest states throughout: the guided empty state names what to do; a
  404 renders the demo-mode notice; a 403 renders the auditor-role
  refusal (the demo key is auditor by design, and the paste path says
  so up front); FastAPI 422 validation rows render as named text;
  pasted policies over 256 KiB are refused client-side before any
  request leaves (the MCP manifest precedent); one run at a time.
  The tab applies nothing and never references the apply path.
- The tour gains the simulate steps (nav entry spotlight plus the result
  card, the DLP precedent split), slotted after the DLP pair in the
  buyer arc; the tour bound moves to 16 and no test was dropped.
- Render-contract tests follow the dlp/mcp precedents
  (`TestPolicySimulateTab`, the K2 block in
  `tests/test_admin_panel_js.py`); the evaluator guide and the X6 spec
  note the tab (`docs/deployment-demonstrator.md`,
  `docs/spec/x6-policy-simulate.md`).

### Added - J1: operator chain rotation and a boot memory preflight

- `raucle rotate-chain`: the receipted operator rotation of the gateway's
  boot stores (the audit chain and the receipt-store segments) - archives
  the current files with a .archived-DATE suffix (never deletes,
  idempotent-safe refusal when today's archive exists), mints a rotation
  receipt naming the archived digests, operator identity, reason and
  timestamps, and verifies the fresh stores boot.
- Boot memory preflight: the gateway states the projected boot memory
  before loading and refuses with a named error and the exact rotate
  command when the projection exceeds RAUCLE_BOOT_MEM_CEILING_MB - the
  OOM-killed-forever boot class (observed live on 18 November 2026:
  a 12.2 GB audit chain plus a 15 GB index ballooned to 23.4 GB resident
  on a 24 GB box) is refused before it can happen.
- Runbook: docs/ops/chain-rotation.md (worked example: the live incident).

### Fixed - J2: receipt index mid-migration crash recovery (OOM crash-loop)

- The receipt index migrate-on-open (`raucle/receipt_index.py`) ran as
  separate autocommitted statements, so a process killed between the
  rename and the copy left the file half-migrated
  (`receipts_prev_backup` beside a half-built live table) and every
  later boot re-entered the migration and died on "there is already
  another table or index with this name: receipts_prev_backup" - a
  permanent crash-loop under restart:always (the 18 Nov demo
  incident: three OOM kills at 23.4 GB RSS). The index is a rebuildable
  projection of the chain of record, so a boot must recover, never
  crash-loop.
- Open now inspects the schema BEFORE any ALTER runs and recovers each
  interrupted state deterministically, in the ordering that cannot lose
  projected data: the backup table is the authoritative pre-migration
  snapshot (the rename that created it was the migration's first
  durable step, and the half-built live table only ever held rows
  copied from the backup), so the backup is dropped only after its rows
  are re-copied, in the same transaction that stamps `user_version`.
  Every recovery branch logs the named line "receipt_index: recovered
  interrupted schema migration".
- The migration, its index definitions and the version stamp now run
  as ONE explicit transaction (probe-verified on SQLite 3.53.1: DDL
  and `PRAGMA user_version` are transactional), so a crash at any step
  rolls the file back to the pristine pre-migration state and the next
  open re-runs it; this code can no longer produce a half-migrated
  file. The schema version rows are the migration journal; their
  invariants, and the incident as the worked example, are documented
  in `docs/nfr/receipt-index-ops-v1.md` (operator runbook and honest
  residual register included).
- Red-first tests in `tests/test_receipt_index.py`
  (`TestMigrationCrashRecovery`): the observed production signature
  boots and recovers with the named log line and passes a full
  projection rebuild verification against the chain; a real SIGKILL
  replay of the old migration's durable rename recovers on the next
  boot; a SIGKILL inside the new one-transaction migration leaves no
  artifact and loses no rows.

### Fixed - I1: the agent_framework adapter carried the last agent_id placeholder on receipt surfaces

- `raucle/integrations/agent_framework.py` minted
  `agent_id=agent_id or "<unknown>"` into capability receipts,
  including deny receipts, so an unattributed call produced a
  fabricated identity on the audit chain. The receipt now carries the
  caller's `agent_id` verbatim when declared, or an honest null when it
  is not - the same honest-null contract the crewai and langgraph
  adapters already enforce (receipt-index v3: continuity is never
  fabricated). `CapabilityReceipt.agent_id` is now `str | None` and
  red-first pins in `tests/test_agent_framework_integration.py` hold
  both legs (an unattributed deny receipt carries `agent_id: null`).

### Added - P2a: framework adapters for the OpenAI Agents SDK, Pydantic AI and Google ADK

- Three new adapters carry the attribution-guard family (the crewai and
  langgraph shape) to the next three frameworks, investigation-first:
  `raucle/integrations/openai_agents.py` gains the capability guard
  (`guard_tool` / `guard_function`) beside the existing content
  guardrails; `raucle/integrations/pydantic_ai.py` and
  `raucle/integrations/google_adk.py` are new wrapping-function gates.
  Every adapter denies BEFORE any tool interaction (the wrapped body
  never runs on the deny path), preserves the tool's signature so the
  framework sees an identical tool, and enforces the B2 doctrine: a call
  with no attributable identity denies and the deny receipt carries an
  honest null `agent_id`, never a placeholder.
- Attribution surfaces, probed live per version (18 Nov 2026, CPython
  3.13): openai-agents carries the acting agent on the SDK's internal
  `ToolContext` (agent name or the run context's `agent_id`), pinned
  `agent_id` at guard time wins; pydantic-ai carries it on
  `RunContext.agent.name` (the registered `Agent`, nameable in the
  raucle scheme); google-adk carries it on the invocation context
  (`_invocation_context.agent.name`, an ADK identifier joined into the
  raucle `agent:` scheme because ADK refuses colons in names).
- Verified spans, each pinned in pyproject with the lift rule:
  openai-agents 0.19.1 / 0.21.0 / 0.23.1 / 0.25.0 (MIT, floor lifted
  from >= 0.1); pydantic-ai 1.107.10 / 2.59.0 / 2.65.0 / 2.70.0 (MIT);
  google-adk 1.39.1 / 2.7.0 / 2.11.0 / 2.14.1 (Apache-2.0). The last two
  cannot co-install with the crewai extra at these spans (crewai's pins
  downgrade both to pre-1.0 releases in joint resolution), so they ride
  a second CI slot, `Test (integration extras, P2a)`, and deployments
  install at most one family per environment.
- Tests: real-framework suites (offline `TestModel` end-to-end for
  pydantic-ai, the SDK's own invocation context for openai-agents, ADK's
  `FunctionTool` call shape for google-adk) plus attribution-doctrine
  legs in `tests/test_attribution_audit.py` and stand-in contract
  coverage in `tests/test_integrations_contract.py` (RuntimeError
  install hints, honest-null receipts, blocker-package import-survival
  subprocesses). Docs: matrix rows for the three adapters and a
  getting-started track each, every snippet showing `guard_tool` WITH
  `agent_id`.

### Added - H3: I1 counterfactual evidence and revocation-event receipt specifications (receipts v1.2)

- New public specification
  `docs/spec/provenance/v1.2/counterfactual-evidence.md`: an intent
  receipt MAY carry the not-taken decision under a named alternative
  ruleset, evaluated at decision time by the same deterministic
  machinery as the enforced decision. Bounded, fail-closed shape
  (version anchor, ruleset digest, decision, rule id and kind drawn
  from the shipped policy and session vocabularies, session-window
  evidence per the session rules spec, a decision-time bound on
  `evaluated_at`); no silent schema extension (a verifier that does not
  implement the block refuses with a named error); the spec states what
  a third party CAN and CANNOT conclude from counterfactual evidence:
  never enforcement, never whole-incident prevention, never model
  outputs, never a proof.
- New public specification
  `docs/spec/provenance/v1.2/revocation-receipts.md`: the
  revocation-event receipt kind. Mandatory chain linkage to the revoked
  object by hash, revoker identity, a closed reason-class vocabulary
  and a decision-time timestamp; no secret material, no capability
  replay content, no content. Verifiable offline like every receipt;
  revocation is a new link in the chain, never an edit; an unknown
  revocation-receipt version refuses with a named error, never silently
  ignored. The shipped 30 October emitter shape stays valid and is
  documented as such.
- `docs/spec/README.md` now indexes the receipts v1.2 additive-extension
  family, including the two new documents. Spec precedes
  implementation: no gateway, emission or verifier code changes in this
  PR; those legs land with the implementing Q lanes.

### Added - D5: the MCP scanner joins the buyer tour with payload-free findings

- The MCP Scanner tab is now labelled OSS LIVE and joins the enterprise
  walkthrough as the tool-poisoning story, one step before the honest
  close: the real `raucle.mcp_scanner` engine runs live over a seeded
  or pasted manifest. The scan is a stateless one-shot POST: it runs in
  memory, mutates nothing and persists nothing, and because a static
  scan is not a gate decision it mints no receipt and enters nothing
  into the receipt chain; the panel states that instead of implying a
  citation.
- Content absence, test-pinned: the scan response and the findings
  table carry severity, location and the evidence class (the scanner's
  category) only. The scanner's raw `evidence` excerpt is manifest
  payload and is dropped server-side, so poisoning phrases, planted
  keys and SSRF bait URLs never reach the response; the manifest text
  stays in the operator's own input box. The pasted textarea is also
  size-capped client-side at 256 KiB, mirroring the server's refusal of
  oversize bodies.
- The overview card is retitled "MCP tool scanner" with an OSS LIVE
  badge: the engine, the endpoints and the findings are real code
  running in the demo. The seeded manifests stay labelled simulated,
  and Agent Red tradecraft remains closed-core and out of this demo.

### Fixed - D1: crewai attribution guard regression (bearer mode was never closed)

- The B2 attribution audit (v0.23.3) recorded the CrewAI leg as shipped
  ("bearer mode is closed; unattributed attempts deny"), but the
  `raucle/integrations/crewai.py` change was lost in transit. No CI job
  installed the `crewai` extra, so `test_crewai_unattributed_call_denies`
  skipped silently and the red test hid behind `importorskip` until the
  D1 regression hunt reproduced it in an all-extras venv under crewai
  1.6.1.
- The failure: with a valid in-force token and no bound caller identity
  (`agent_id=None`), a guarded tool call RAN - receipted as ALLOW and
  attributed to the fabricated `"<unbound>"` placeholder - instead of
  denying per the B2 invariant (every ALLOWED execution carries a real
  acting identity; no receipt ever carries a placeholder).
- Version boundary, honestly: there is none. The deny never existed on
  any release. Reproduced identically under crewai 1.0.0, 1.5.0, 1.6.1
  and 1.15.41 (the 1.x `BaseTool` surface is stable across the span, and
  `CapabilityDenied` propagates out of `run()` on all four); the 1.6.1
  framing came from the discovery venv's resolution, not a crewai
  behaviour change.
- The fix is adapter-side and version-robust: in crewai the token
  check comes first (the pinned no-token reason is unchanged), then a
  fail-closed attribution deny ("no acting agent identity"), then the
  gate; the langgraph adapter runs the same two fail-closed checks in
  the opposite order (the agent_id deny before the token check). Both
  the sync `_run` and
  async `_arun`/`arun` paths enforce it, and deny receipts carry an
  honest null `agent_id` - the `"<unbound>"` placeholder is gone.
- Red-first evidence (recorded from the failing runs before the fix):
  `DID NOT RAISE CapabilityDenied` under crewai 1.15.41 for both the
  sync and the new async unattributed tests; the stub-backed contract
  variant failed identically in a crewai-free venv.
- CI can no longer hide extras regressions: a new
  `Test (integration extras)` job installs `.[dev,crewai,langgraph]` on
  Python 3.13 and runs the attribution audit, crewai integration and
  langgraph integration suites. The `[dev]` matrix jobs are unchanged.
- The `crewai` extra is bounded to `>=1.0,<1.16`, recording the last
  verified minor (1.15.41); lift it deliberately after the extras job
  re-verifies on a newer release. Demo, getting-started doc, and the
  real-crewai test fixture now bind the acting identity, which closed
  bearer mode makes mandatory.
- langgraph: `test_module_import_survives_without_langgraph_subprocess`
  failed under the extras venv because it assumed the pytest interpreter
  never has langgraph installed. Not an adapter bug: the test now puts a
  blocker package that raises `ImportError` first on the subprocess's
  `PYTHONPATH`, so the import-survival path executes under every install
  shape. The langgraph adapter itself needed no change.
- Also fixed while landing this: the stub-backed contract fixture
  restored a hardcoded `_HAS_CREWAI = False`, which in an extras venv
  poisons the real module state for every later crewai test in the same
  pytest process; it now restores the prior state truthfully.
- Follow-up (integration doc + langgraph leg, D1-adjacent): the three
  prose `guard_tools` examples were checked on a freshly fetched main
  and already bind `agent_id` with the fail-closed note (the crewai
  lane covered them; no doc change needed). The langgraph adapter
  still carried the placeholder family the crewai fix removed: deny
  emission defaulting a falsy `agent_id` to `"<unbound>"`. Unattributed
  deny receipts now carry an honest null `agent_id` (empty string and
  None both emit null; declared caller ids are untouched), matching the
  crewai contract. Pinned red-first in
  `tests/test_langgraph_integration.py::test_deny_receipt_agent_id_never_placeholder`
  (deny receipt's `agent_id` is declared-or-null, never a placeholder
  string) and by extending `test_empty_agent_id_denies_receipted`.

### Added - EE proxy runtime specification (EPIC Q lane Q-7b)

- New public specification `docs/spec/ee-proxy-runtime-v1.md`: the
  versioned design and wire contract for the enterprise LLM endpoint
  proxy (the closed EE runtime that carries content-plane DLP), built
  entirely over existing OSS gate surfaces: per-route policy profiles
  with fail-closed unknown routes, request/response DLP scan-and-redact
  with `x_dlp` receipts minted through `RaucleGateway.emit_dlp_finding`,
  session rules by declared session identity, response taint feeding the
  existing chain-taint rules, provenance headers, fail-closed failure
  postures per failure class, and the versioned `ee-proxy-routes/v1`
  configuration schema. The spec records the licence-split ruling
  explicitly: the runtime is EE; the spec, receipts and verifier stay
  OSS; no OSS code change is required. Spec index updated.

### Fixed - CI toolchain pinning

- The CI lint job installs ruff pinned to an exact version
  (`ruff==0.17.5`, the current released ruff) instead of unpinned, and the
  SonarCloud job's raucle install is pinned to `raucle==0.23.6`, matching
  the current distribution pin. Both previously drifted when a new release
  landed on the package index: CI and local venvs then linted (or analysed)
  with different tool versions and gates disagreed. Bump these pins
  deliberately, keeping the ruff pin in sync with what developers run
  locally.
