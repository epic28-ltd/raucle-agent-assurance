# Raucle proposals

Forward-looking design documents for the raucle project. Not yet implemented; intended as artefacts to share, gather feedback on, and use as the basis for follow-up papers and protocol-extension submissions.

| Proposal | Status | Target |
|---|---|---|
| [VCD-A2A: Capability Discipline for the Agent-to-Agent Protocol](vcd-a2a.md) | Draft 2026-05-18 | A2A protocol extension submission |
| [TEE-anchored VCD gate](tee-gate.md) | Draft 2026-05-18 | Q3 2026 commercial-product feature; paper §8 update for camera-ready |
| [VCD for the Microsoft Agent Framework](agent-framework-middleware.md) | Draft + skeleton 2026-05-27 · 6/6 tests passing | raucle v0.11.0 |
| [PDP plug-in contract for Microsoft Agent Governance Toolkit](agt-pdp-contract.md) | Draft 2026-05-27 | upstream PR to microsoft/agent-governance-toolkit; raucle v0.12.0 |
| ↳ [Upstream PR body](agt-pdp-contract.upstream-pr.md) + [shadow files](upstream-pr-files/) | Ready-to-submit 2026-05-27 · 10/10 contract tests passing | PR against microsoft/agent-governance-toolkit |
| [Foundry MCP AI Gateway sidecar pattern](foundry-mcp-gateway.md) | Draft 2026-05-27 | raucle v0.12.0 deployment recipe |
| [raucle as a PDP for NemoClaw's OpenShell](openshell-pdp-bridge.md) | Draft 2026-06-12 · doc-only (NemoClaw alpha) | design input to NemoClaw/OpenShell; P1 decision-log ask upstream |

Each proposal:
- States the threat-model addition (if any) over the base VCD primitives in the IEEE S&P 2027 paper draft.
- Specifies the on-wire / on-disk format extension.
- Lists backwards-compatibility constraints.
- Names a reference-implementation milestone schedule.

Feedback: open an issue on the repository or email `oss@raucle.com` for cross-organisation collaboration discussions.
