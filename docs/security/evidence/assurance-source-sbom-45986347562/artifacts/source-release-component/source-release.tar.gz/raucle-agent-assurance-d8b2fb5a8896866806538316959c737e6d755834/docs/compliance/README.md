# Compliance packs (evidence mappings)

The raucle-agent-assurance evidence plane ships framework packs: mappings of
its offline-verifiable evidence (signed gate receipts, the receipt chain,
custody coverage, red-run findings) to the frameworks enterprise checklists
name. Every pack is a mapping in the "mapped to" sense only: each row says
what repository evidence exists and how far it goes, with an honest
SUPPORTED / PARTIAL / UNSUPPORTED verdict per control. No pack claims
compliance, certification or conformance for the repository or for any
deployment.

- [EU AI Act pack v1](eu-ai-act-pack-v1.md) - logging, transparency, human
  oversight, robustness (Articles 12, 13, 14, 15, 19, 50).
- [HIPAA Security Rule pack v1](hipaa-security-rule-pack-v1.md) - technical
  safeguards (164.312 audit controls, integrity, access control, transmission
  security).
- [PCI DSS pack v1](pci-dss-pack-v1.md) - logging, identity, configuration
  and secure development (Requirements 2, 6, 8, 10).
- [ISO/IEC 42001 pack v1](iso-42001-pack-v1.md) - AI management system
  clauses 4 to 10 and the Annex A records and operation controls.
- [NIST AI RMF pack v1](nist-ai-rmf-pack-v1.md) - GOVERN, MAP, MEASURE and
  MANAGE core functions, with the existing OWASP LLM Top 10 crosswalk slice
  noted alongside.
- [SOC 2 Trust Services Criteria mapping v1](soc2-pack-v1.md) - Common Criteria CC1-CC9 and additional Availability, Confidentiality, Processing Integrity and Privacy criteria, with evidence-plane-only verdicts.
- [HITRUST AI Security Framework pack v1](hitrust-ai-pack-v1.md) - CSF v11
  AI control topics (inventory, change management, data protection,
  incident response), referenced by id and title only (HITRUST is
  licence-restricted; no control text is reproduced).

The machine-readable rows behind every pack live in the governance crosswalk
(`ops/assurance-profiles/crosswalk.json`); the deterministic, vendor-neutral
export is the `grc_evidence_graph/v1` document from
`tools/grc_export/export.py`. The ISO/IEC 42001, NIST AI RMF and EU AI Act
slices additionally carry per-row evidence-mapping metadata (disposition,
owner-pending Craig slots, evidence freshness, system and raucle v0.23.9
version scope, verification status) whose deterministic, digest-bound export
is the `regulatory_mapping_manifest/v1` document from
`tools/grc_export/mapping_manifest.py` (run as `--profile manifest`). Every
mapping here is an evidence mapping: it is not certification, regulatory
conformity or an independent audit, and EU AI Act applicability
determinations are legal review inputs, decided by qualified legal review
only. Pack-to-crosswalk consistency is enforced by
the tests in `tests/assurance/`, and packs are validated against governance
profiles by `ops/assurance-profiles/validator.py`.
