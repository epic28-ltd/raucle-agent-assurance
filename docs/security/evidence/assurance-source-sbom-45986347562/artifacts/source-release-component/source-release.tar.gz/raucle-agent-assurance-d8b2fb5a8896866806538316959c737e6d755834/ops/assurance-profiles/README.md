# OV-4 governance profiles and crosswalk

What a LASR auditor can now claim because this exists: release gating against
declared governance standards, with every framework mapping pointing at real,
offline-verifiable raucle evidence, or stating honestly that none exists.

## Files

- `profiles.yaml`: `basic` vs `regulated` governance profiles. Each declares
  required framework mapping slots and required crosswalk controls, plus
  outcome semantics (gap type -> release blocker `fail` or warned finding
  `warn`).
- `crosswalk.json`: framework controls (DORA, EU AI Act, ISO 42001, SOC 2,
  NCSC CAF, NIST AI RMF, OWASP LLM Top 10, AIUC-1, HIPAA, PCI DSS) mapped to
  the raucle evidence field
  (`evidence_field`, a dotted path into the assurance packet) and the repo
  artifact that backs it (`basis`). UNSUPPORTED rows state in `unsat_reason`
  why nothing in the current evidence plane satisfies the control. These are
  honest gaps, never padded green. The pack docs that read out framework
  slices live in `docs/compliance/`.
- Evidence-mapping metadata (crosswalk v2, ISO 42001 / NIST AI RMF / EU AI
  Act rows): `disposition` (mapped / gap / not-applicable), `owner`
  (`owner-pending Craig` - a named, unfilled pending slot),
  `evidence_freshness` (`verified_at` date plus the cited artifact's git
  commit at main), `system_version_scope` (the artifact's repository and the
  raucle release it ships in, raucle v0.23.9), `verification_status` (independent offline
  verification versus engineering-authored only), and - EU AI Act rows only -
  `applicability_status` ("not determined: legal review input"). The
  deterministic, digest-bound export of these rows is
  `tools/grc_export/mapping_manifest.py` (`--profile manifest`).
- `validator.py`: validate(packet, profile) -> PASS/PARTIAL/FAIL with a
  machine-readable diff (every unsatisfied check with expected/actual/note).

## Packet shape coded against

The validator codes against the versioned `agent_assurance_packet` shape
documented in OV-1 of `docs/roadmap/overnight-sprint-backlog.md`:
`schema_version`, `kind`, `agent`, `capability_chain`, `policy_proof_refs`,
`receipt_chain` (`total_count`, `verified_count`, `invalid_or_missing_count`),
`coverage` (`gate_covered_tools`, `unverified_tools`), `governance`
(mapping slots per framework, flat dict or list), `risk_annotations`.
Missing fields degrade to PARTIAL, never silently PASS; a packet naming a
wrong `kind` fails.

## Verdicts

- PASS: every check satisfied.
- PARTIAL: honest gaps only (missing packet evidence, crosswalk PARTIAL rows).
- FAIL: receipt-integrity failure, unverified tools (regulated), a packet
  claiming more than the crosswalk establishes (`tampered_claim`, every
  profile), an unknown status vocabulary, an invented control, or (regulated)
  any absent required framework or UNSUPPORTED required control.

Note: under `regulated` the shipped crosswalk currently tops out at PARTIAL
(DORA Art 5(1), EU AI Act Art 15(1), ISO 42001 A.5.3): a regulated release
today cannot honestly reach PASS. That is the intended, honest boundary until
those controls gain full packet evidence.

The repo's compliance-honest invariant applies: the validator never derives
legal or regulatory compliance from a PASS verdict; it only verifies declared
coverage against documented evidence.

## Use

```bash
.venv/bin/python ops/assurance-profiles/validator.py --packet packet.json --profile regulated
# exit code: 0 PASS / 1 PARTIAL / 2 FAIL / 3 profile-data defect (see stdout JSON)
```

## CI gate action (OV-5)

`.github/actions/assurance-gate` is a composite GitHub action wrapping the
validator (local-first: plain python + pyyaml, no paid deps), with a
reusable workflow at `.github/workflows/assurance-gate.yml`:

```yaml
- uses: ./.github/actions/assurance-gate
  with:
    packet: ops/assurance-profiles/fixtures/green.json
    profile: regulated
    fail-on-partial: false   # PARTIAL warns and continues; FAIL fails the job
```

Outputs `verdict` and writes a step summary. `.github/workflows/
assurance-gate-fixtures.yml` exercises the action end to end against
committed fixture packets in `ops/assurance-profiles/fixtures/`:
`green.json` (passes), `partial.json` (warns, job continues),
`failing.json` (invalid receipts and an unverified tool, job fails).

Tests: `tests/assurance/test_profiles_crosswalk.py`.
