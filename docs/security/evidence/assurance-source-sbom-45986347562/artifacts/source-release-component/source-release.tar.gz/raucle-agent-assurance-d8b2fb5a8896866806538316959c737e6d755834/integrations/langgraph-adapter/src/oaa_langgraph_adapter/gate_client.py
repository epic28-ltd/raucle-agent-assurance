# SPDX-License-Identifier: Apache-2.0
"""Gate clients: the enforcement boundary to Raucle Agent Trust.

The adapter CALLS the gate through one of these clients; it is never the gate
itself (monitoring never enforcement-authority). Every client returns the same
``GateDecision`` result so the middleware is transport-agnostic.

Both implementations are lazy: the installed ``raucle`` distribution and
``urllib``-level HTTP are only touched when the corresponding client is
actually constructed. Install the documented pinned distribution explicitly;
this adapter does not search developer home directories for a source checkout.
"""

from __future__ import annotations

import importlib
import json
import urllib.error
import urllib.request
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Protocol
from urllib.parse import urlsplit

#: Distro pin keyed by the raucle distribution, NOT ``raucle.__version__``
#: (which is stale) — see packages/raucle-adapter/evidence_plane.py.
RAUCLE_DISTRIBUTION_PIN = "raucle 0.23.6 (git 645f5de)"

_ALLOW = "allow"
_DENY = "deny"
_ESCALATE = "escalate"


@dataclass(frozen=True)
class GateDecision:
    """Normalised gate outcome.

    ``error`` is set when the gate itself failed (transport/exception). In
    that case ``decision`` mirrors the middleware's fail mode (``fail_closed``
    callers see ``deny``), and ``receipt_hash`` is always empty — no receipt
    means no verification state to attach.
    """

    decision: str  # "allow" | "deny" | "error"
    reason: str = ""
    receipt_hash: str | None = None
    latency_us: int = 0
    error: str | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


class GateClient(Protocol):
    """Anything the middleware can enforce against."""

    def check_tool_call(
        self,
        *,
        tool: str,
        args: dict[str, Any],
        call_id: str,
        trace_id: str,
        agent_id: str,
        source: str,
    ) -> GateDecision:
        """Gate one tool call. Must not retry; must return promptly."""
        ...  # pragma: no cover - protocol


def _ensure_raucle_importable() -> tuple[Any, Any, Any]:
    """Import the installed, pinned raucle distribution.

    The adapter intentionally has no developer-home/worktree fallback:
    runtime behaviour must be determined by the environment's declared
    package installation, not by whichever stale checkout happens to exist.
    Returns (raucle module, RaucleGateway, GatewayConfig) or raises ImportError.
    """
    raucle = importlib.import_module("raucle")
    importlib.import_module("raucle.gateway")
    return raucle, raucle.gateway.RaucleGateway, raucle.gateway.GatewayConfig


class InProcessRaucleGate:
    """Wrap a real ``RaucleGateway`` in-process (same interpreter as the agent).

    Enforcement authority stays entirely with the gateway: this wrapper is a
    transport shim, not a policy evaluator.
    """

    def __init__(
        self,
        gateway: Any | None = None,
        *,
        gateway_config: Any | None = None,
        agent_id: str = "",
        source: str = "langgraph",
    ) -> None:
        if gateway is None:
            _, gateway_cls, gateway_cfg = _ensure_raucle_importable()
            gateway = gateway_cls(gateway_config if gateway_config is not None else gateway_cfg)
        self._gateway = gateway
        self._agent_id = agent_id
        self._source = source

    def check_tool_call(
        self,
        *,
        tool: str,
        args: dict[str, Any],
        call_id: str,
        trace_id: str,
        agent_id: str,
        source: str,
    ) -> GateDecision:
        # Correlation: the caller's id travels as the gate's trace_id (call_id
        # as fallback), so the signed receipt is keyed by the call it covers.
        result = self._gateway.check_tool_call(
            tool,
            args,
            agent_id=agent_id or self._agent_id,
            source=source or self._source,
            trace_id=trace_id or call_id,
        )
        decision = str(result.get("decision", _DENY))
        if decision == _ALLOW:
            receipt_hash = result.get("receipt_id")
            return GateDecision(
                decision=_ALLOW,
                reason=str(result.get("reason", "")),
                receipt_hash=receipt_hash if receipt_hash else None,
                latency_us=int(result.get("latency_us", 0)),
                raw=result,
            )
        if decision == _ESCALATE:
            # Escalate is not authority to run. Until an approval workflow is
            # wired through the adapter, escalation resolves to deny.
            return GateDecision(
                decision=_DENY,
                reason=str(result.get("reason", "")) or "escalation unresolved",
                latency_us=int(result.get("latency_us", 0)),
                raw=result,
            )
        return GateDecision(
            decision=_DENY,
            reason=str(result.get("reason", "denied")),
            latency_us=int(result.get("latency_us", 0)),
            raw=result,
        )


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Refuse every redirect: the gate endpoint is pinned (threat model T2)."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[override]
        raise urllib.error.HTTPError(
            req.full_url, code, "gate endpoint redirected; refusing", headers, fp
        )


class HttpGateClient:
    """POST the gate request to a Raucle gateway HTTP endpoint as JSON.

    One request per call, no retries inside the enforcement path. ``timeout_s``
    defaults to 80 ms (the latency budget agreed in EPIC M).
    """

    def __init__(
        self,
        endpoint: str,
        *,
        timeout_s: float = 0.080,
        agent_id: str = "",
        source: str = "langgraph",
        fail_open: bool = False,
        allow_http: bool = False,
        extra_body: Mapping[str, Any] | None = None,
    ) -> None:
        # Security: urlopen follows redirects and historically permits file://
        # (bandit B310). Enforce https in production; plain http only for
        # explicit local development targeting loopback.
        try:
            parsed = urlsplit(endpoint)
            hostname = parsed.hostname
            # Accessing .port validates malformed port syntax as well.
            _ = parsed.port
        except ValueError as exc:
            raise ValueError(f"HttpGateClient invalid endpoint: {endpoint!r}") from exc
        if (
            parsed.scheme not in {"https", "http"}
            or not hostname
            or parsed.username is not None
            or parsed.password is not None
            or parsed.fragment
        ):
            raise ValueError(f"HttpGateClient invalid endpoint: {endpoint!r}")
        if parsed.scheme == "http" and hostname not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError(
                "HttpGateClient endpoint must use https:// (plain http is allowed "
                "only for exact loopback hosts: localhost, 127.0.0.1 or ::1)"
            )
        self._endpoint = endpoint
        self._timeout_s = timeout_s
        self._agent_id = agent_id
        self._source = source
        self._fail_open = fail_open
        self._extra_body = dict(extra_body or {})

    def check_tool_call(
        self,
        *,
        tool: str,
        args: dict[str, Any],
        call_id: str,
        trace_id: str,
        agent_id: str,
        source: str,
    ) -> GateDecision:
        # Optional extension fields must never override the identity or
        # request fields that define what the gate is being asked to authorise.
        body = {
            **self._extra_body,
            "tool": tool,
            "args": args,
            "call_id": call_id,
            "trace_id": trace_id or call_id,
            "agent_id": agent_id or self._agent_id,
            "source": source or self._source,
            "distribution_pin": RAUCLE_DISTRIBUTION_PIN,
        }
        req = urllib.request.Request(
            self._endpoint,
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            # No redirects: the gate endpoint is pinned; a redirect must never
            # escape the enforcement path to another host or scheme.
            opener = urllib.request.build_opener(_NoRedirectHandler())
            with opener.open(req, timeout=self._timeout_s) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except Exception as exc:  # gate failure — resolution is the caller's job
            return GateDecision(
                decision=_ALLOW if self._fail_open else _DENY,
                reason=f"gate unreachable: {exc}",
                error=str(exc),
                raw={},
            )
        decision = str(payload.get("decision", _DENY))
        return GateDecision(
            decision=_ALLOW if decision == _ALLOW else _DENY,
            reason=str(payload.get("reason", "")),
            receipt_hash=payload.get("receipt_hash"),
            latency_us=int(payload.get("latency_us", 0)),
            raw=payload,
        )
